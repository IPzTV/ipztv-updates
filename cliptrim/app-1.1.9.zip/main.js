const { app, BrowserWindow, ipcMain, dialog, shell, nativeImage} = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');

const U = () => global.cliptrimUpdater;

const VIDEO_EXT = ['mp4', 'mov', 'm4v', 'mkv', 'avi', 'webm', 'wmv', 'mpg', 'mpeg', 'ts'];

function describe(p) {
  return { path: p, url: pathToFileURL(p).href, name: path.basename(p) };
}

let win = null;
let current = null; // lopend ffmpeg-proces

function createWindow() {
  win = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 820,
    minHeight: 560,
    backgroundColor: '#1c1c1e',
    title: 'ClipTrim',
    icon: nativeImage.createFromPath(path.join(__dirname, 'icon.ico')),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.on('did-finish-load', () => {
    U().markGood();
    U().start((payload) => {
      if (win && !win.isDestroyed()) win.webContents.send('update-event', payload);
    });
    const arg = process.argv.slice(1).find((a) => VIDEO_EXT.includes(path.extname(a).slice(1).toLowerCase()));
    if (arg) win.webContents.send('open-file', describe(path.resolve(arg)));
  });
}

app.whenReady().then(() => {
  require('./proxy').clear();
  // de app laadt alleen lokale pagina's: een schermcache heeft geen nut en groeit anders
  try { const s = require('electron').session.defaultSession; s.clearCache().catch(() => {}); s.clearCodeCaches({}).catch(() => {}); } catch (_) {}
  createWindow();
});
app.on('will-quit', () => { try { require('./proxy').clear(); } catch (_) {} });
app.on('window-all-closed', () => app.quit());

ipcMain.handle('open-dialog', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Kies een video',
    properties: ['openFile'],
    filters: [{ name: 'Video', extensions: VIDEO_EXT }, { name: 'Alle bestanden', extensions: ['*'] }],
  });
  if (r.canceled || !r.filePaths[0]) return null;
  return describe(r.filePaths[0]);
});

ipcMain.handle('describe', (_e, p) => describe(p));

ipcMain.handle('save-dialog', async (_e, defaultPath) => {
  const r = await dialog.showSaveDialog(win, {
    title: 'Bewaar video',
    defaultPath,
    filters: [{ name: 'MP4-video', extensions: ['mp4'] }],
  });
  return r.canceled ? null : r.filePath;
});

ipcMain.handle('reveal', (_e, p) => shell.showItemInFolder(p));

ipcMain.handle('cancel-export', () => {
  if (current) {
    current.canceled = true;
    current.proc.kill();
  }
});

// o: { input, output, start, duration, crop:{x,y,w,h} (fracties 0..1) | null, fast, crf }
ipcMain.handle('export', (e, o) => {
  return new Promise((resolve) => {
    const args = ['-y', '-hide_banner', '-ss', String(o.start), '-i', o.input, '-t', String(o.duration),
      '-map', '0:v:0', '-map', '0:a:0?'];

    if (o.fast && !o.crop) {
      args.push('-c', 'copy', '-avoid_negative_ts', 'make_zero');
    } else {
      if (o.crop) {
        const c = o.crop;
        const f = (v) => Math.min(1, Math.max(0, v)).toFixed(6);
        // altijd even afmetingen (vereist voor H.264 / yuv420p)
        args.push('-vf',
          `crop=w=floor(iw*${f(c.w)}/2)*2:h=floor(ih*${f(c.h)}/2)*2:x=floor(iw*${f(c.x)}/2)*2:y=floor(ih*${f(c.y)}/2)*2`);
      } else {
        args.push('-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2');
      }
      args.push('-c:v', 'libx264', '-preset', 'medium', '-crf', String(o.crf || 18),
        '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k');
    }
    args.push('-movflags', '+faststart', '-progress', 'pipe:1', '-nostats', o.output);

    const proc = spawn(U().ffmpegPath(), args, { windowsHide: true });
    current = { proc, canceled: false };
    let errTail = '';
    let buf = '';

    proc.stdout.on('data', (d) => {
      buf += d.toString();
      const lines = buf.split(/\r?\n/);
      buf = lines.pop();
      for (const line of lines) {
        const m = /^out_time_(?:us|ms)=(\d+)/.exec(line);
        if (m && o.duration > 0) {
          const sec = Number(m[1]) / 1e6;
          e.sender.send('export-progress', Math.min(1, sec / o.duration));
        }
      }
    });
    proc.stderr.on('data', (d) => { errTail = (errTail + d.toString()).slice(-2000); });
    proc.on('error', (err) => { current = null; resolve({ ok: false, error: err.message }); });
    proc.on('close', (code) => {
      const canceled = current && current.canceled;
      current = null;
      if (canceled || code !== 0) { try { require('fs').rmSync(o.output, { force: true }); } catch (_) {} } // geen halve bestanden achterlaten
      if (canceled) return resolve({ ok: false, canceled: true });
      if (code === 0) return resolve({ ok: true, output: o.output });
      resolve({ ok: false, error: errTail || ('ffmpeg stopte met code ' + code) });
    });
  });
});

/* ---------- updates ---------- */
ipcMain.handle('versions', () => U().versions());
ipcMain.handle('update-check', async () => { await U().check(true); return true; });
ipcMain.handle('update-restart', () => { app.relaunch(); app.exit(0); });
ipcMain.handle('open-url', (_e, url) => {
  if (/^https:\/\//.test(String(url))) shell.openExternal(url);
});

/* ---------- voorbeeldkopie (proxy) voor video's die Chromium niet kan afspelen, bv. HEVC/4K ---------- */
const proxy = require('./proxy');
ipcMain.handle('make-proxy', (e, file) => proxy.makeProxy({
  ffmpeg: U().ffmpegPath(),
  file,
  send: (p) => { if (!e.sender.isDestroyed()) e.sender.send('proxy-progress', p); },
}));
ipcMain.handle('cancel-proxy', () => proxy.cancel());
