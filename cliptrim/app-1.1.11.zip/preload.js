const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  openDialog: () => ipcRenderer.invoke('open-dialog'),
  describe: (p) => ipcRenderer.invoke('describe', p),
  pathForFile: (file) => webUtils.getPathForFile(file),
  saveDialog: (def, ext) => ipcRenderer.invoke('save-dialog', def, ext),
  exportVideo: (opts) => ipcRenderer.invoke('export', opts),
  cancelExport: () => ipcRenderer.invoke('cancel-export'),
  reveal: (p) => ipcRenderer.invoke('reveal', p),
  onOpenFile: (cb) => ipcRenderer.on('open-file', (_e, f) => cb(f)),
  versions: () => ipcRenderer.invoke('versions'),
  checkUpdates: () => ipcRenderer.invoke('update-check'),
  restartNow: () => ipcRenderer.invoke('update-restart'),
  openUrl: (u) => ipcRenderer.invoke('open-url', u),
  onUpdate: (cb) => ipcRenderer.on('update-event', (_e, v) => cb(v)),
  makeProxy: (p) => ipcRenderer.invoke('make-proxy', p),
  cancelProxy: () => ipcRenderer.invoke('cancel-proxy'),
  onProxyProgress: (cb) => ipcRenderer.on('proxy-progress', (_e, v) => cb(v)),
  onProgress: (cb) => ipcRenderer.on('export-progress', (_e, v) => cb(v)),
});
