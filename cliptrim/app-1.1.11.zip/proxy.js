'use strict';
// Maakt een lichte voorbeeldkopie (proxy) van video's die Chromium niet kan afspelen (bv. HEVC/4K).
// Snel gemaakt door: in delen gesplitst en tegelijk verwerkt, tussenbeelden overslaan, kleine resolutie.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { pathToFileURL } = require('url');

let job = null;

function probe(ffmpeg, file) {
  return new Promise((resolve) => {
    const p = spawn(ffmpeg, ['-hide_banner', '-i', file], { windowsHide: true });
    let err = '';
    p.stderr.on('data', (d) => { err += d.toString(); });
    p.on('error', () => resolve(null));
    p.on('close', () => {
      const v = /Video:[^\r\n]*?,\s*(\d{2,5})x(\d{2,5})[\s,\[]/.exec(err);
      if (!v) return resolve(null);
      let width = Number(v[1]), height = Number(v[2]);
      const rot = /rotation of (-?\d+(?:\.\d+)?) degrees/.exec(err);
      if (rot && Math.round(Math.abs(Number(rot[1]))) % 180 === 90) [width, height] = [height, width];
      const d = /Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/.exec(err);
      const duration = d ? Number(d[1]) * 3600 + Number(d[2]) * 60 + Number(d[3]) : 0;
      resolve({ width, height, duration });
    });
  });
}

function runSeg(j, ffmpeg, file, out, ss, len, hw, onTime) {
  return new Promise((resolve) => {
    const args = ['-y', '-hide_banner'];
    if (hw) args.push('-hwaccel', 'auto');
    // decoder-opties (vóór -i): tussenbeelden en lusfilter overslaan = veel sneller uitpakken
    args.push('-skip_frame', 'noref', '-skip_loop_filter', 'all');
    if (ss > 0) args.push('-ss', String(ss));
    args.push('-i', file);
    if (len > 0) args.push('-t', String(len));
    args.push('-map', '0:v:0', '-map', '0:a:0?',
      '-vf', 'scale=-2:480', '-fps_mode', 'vfr',
      '-c:v', 'libx264', '-preset', 'ultrafast', '-tune', 'fastdecode', '-crf', '30', '-g', '30', '-pix_fmt', 'yuv420p',
      '-c:a', 'aac', '-b:a', '80k', '-ac', '2',
      '-movflags', '+faststart', '-progress', 'pipe:1', '-nostats', out);
    const proc = spawn(ffmpeg, args, { windowsHide: true });
    j.procs.add(proc);
    let buf = '', errTail = '';
    proc.stdout.on('data', (d) => {
      buf += d.toString();
      const lines = buf.split(/\r?\n/); buf = lines.pop();
      for (const line of lines) {
        const m = /^out_time_(?:us|ms)=(\d+)/.exec(line);
        if (m) onTime(Number(m[1]) / 1e6);
      }
    });
    proc.stderr.on('data', (d) => { errTail = (errTail + d.toString()).slice(-1500); });
    proc.on('error', (err) => { if (!j.error) j.error = err.message; resolve(false); });
    proc.on('close', (code) => {
      j.procs.delete(proc);
      if (j.canceled) return resolve(false);
      if (code !== 0) {
        if (!j.error) j.error = errTail || ('ffmpeg stopte met code ' + code);
        for (const p of j.procs) p.kill(); // de andere delen hebben geen zin meer
        return resolve(false);
      }
      resolve(true);
    });
  });
}

function run(ffmpeg, file, info, dir, key, K, hw, send) {
  const j = { procs: new Set(), canceled: false, error: null };
  job = j;
  const seglen = info.duration / K;
  const done = new Array(K).fill(0);
  const t0 = Date.now();
  const parts = [];
  const tasks = [];
  for (let i = 0; i < K; i++) {
    const out = path.join(dir, key + (K === 1 ? '.part.mp4' : '.seg' + i + '.mp4'));
    parts.push(out);
    const last = i === K - 1;
    tasks.push(runSeg(j, ffmpeg, file, out, i * seglen, last ? 0 : seglen, hw, (sec) => {
      done[i] = Math.min(sec, seglen);
      const frac = Math.min(1, done.reduce((a, b) => a + b, 0) / info.duration);
      const eta = frac > 0.01 ? ((Date.now() - t0) / 1000) * (1 - frac) / frac : null;
      send({ frac, eta });
    }));
  }
  return Promise.all(tasks).then(async (res) => {
    const cleanup = () => parts.forEach((p) => fs.rmSync(p, { force: true }));
    if (j.canceled) { cleanup(); return { ok: false, canceled: true }; }
    if (!res.every(Boolean)) { cleanup(); return { ok: false, error: j.error || 'Voorbeeld maken mislukt' }; }
    if (K === 1) return { ok: true, file: parts[0] };

    // delen aan elkaar plakken (zonder opnieuw te encoderen)
    const list = path.join(dir, key + '.list.txt');
    fs.writeFileSync(list, parts.map((p) => "file '" + p.replace(/\\/g, '/').replace(/'/g, "'\\''") + "'").join('\n'));
    const joined = path.join(dir, key + '.part.mp4');
    const ok = await new Promise((resolve) => {
      const p = spawn(ffmpeg, ['-y', '-hide_banner', '-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', '-movflags', '+faststart', joined],
        { windowsHide: true });
      let err = '';
      p.stderr.on('data', (d) => { err = (err + d.toString()).slice(-1500); });
      p.on('error', (e) => { err = e.message; resolve(false); });
      p.on('close', (code) => { if (code !== 0) j.error = err || 'Delen samenvoegen mislukt'; resolve(code === 0); });
    });
    fs.rmSync(list, { force: true });
    cleanup();
    return ok ? { ok: true, file: joined } : { ok: false, error: j.error };
  });
}

async function makeProxy({ ffmpeg, file, send }) {
  const info = await probe(ffmpeg, file);
  if (!info) return { ok: false, error: 'ffmpeg kon deze video niet lezen.' };
  const st = fs.statSync(file);
  const key = crypto.createHash('sha1').update(file + '|' + st.size + '|' + st.mtimeMs).digest('hex').slice(0, 16);
  const dir = path.join(os.tmpdir(), 'ClipTrim-proxy');
  fs.mkdirSync(dir, { recursive: true });
  try { // alleen de voorbeeldkopie van de huidige video bewaren; al het andere weg
    for (const f of fs.readdirSync(dir)) {
      if (f !== key + '.mp4') fs.rmSync(path.join(dir, f), { recursive: true, force: true });
    }
  } catch (_) {}

  const out = path.join(dir, key + '.mp4');
  const result = { ok: true, url: pathToFileURL(out).href, width: info.width, height: info.height };
  if (fs.existsSync(out)) return result;

  // lange video's in delen splitsen en tegelijk verwerken
  const K = info.duration > 180 ? Math.max(1, Math.min(6, Math.floor(os.cpus().length / 2))) : 1;
  let r = await run(ffmpeg, file, info, dir, key, K, true, send);
  if (!r.ok && !r.canceled) r = await run(ffmpeg, file, info, dir, key, K, false, send); // zonder videokaart
  if (!r.ok) return r;
  fs.renameSync(r.file, out);
  return result;
}

function cancel() {
  if (job) { job.canceled = true; for (const p of job.procs) p.kill(); }
}

module.exports = { makeProxy, cancel, probe };

// Voorbeeldkopieen zijn tijdelijk: bij opstarten en afsluiten wordt de hele map leeggemaakt.
function clear() {
  try { fs.rmSync(path.join(os.tmpdir(), 'ClipTrim-proxy'), { recursive: true, force: true }); } catch (_) {}
}
module.exports.clear = clear;
