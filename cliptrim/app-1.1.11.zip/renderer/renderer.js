'use strict';
const $ = (s) => document.querySelector(s);

const video = $('#video'), frame = $('#frame'), stage = $('#stage');
const cropEl = $('#crop'), cropLabel = $('#cropLabel');
const timeline = $('#timeline'), strip = $('#strip');
const trimEl = $('#trim'), dimL = $('#dimL'), dimR = $('#dimR'), playhead = $('#playhead');

const state = {
  path: null, name: '',
  duration: 0, vw: 0, vh: 0,
  start: 0, end: 0,
  cropOn: false,
  crop: null,          // {x,y,w,h} in video-pixels
  ratioKey: 'free',
  scale: 1,            // schermpixels per video-pixel
};

let usingProxy = false, proxyInfo = null, proxyBusy = false, busyKind = 'export';
const FRAME_STEP = 1 / 30;
const MIN_TRIM = 0.1;
const MIN_CROP = 16;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

function fmt(t) {
  t = Math.max(0, t);
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return m + ':' + s.toFixed(1).padStart(4, '0');
}

/* ======================= Bestand laden ======================= */

async function openDialog() {
  const f = await window.api.openDialog();
  if (f) loadFile(f);
}

function loadFile(f) {
  state.path = f.path;
  state.name = f.name;
  $('#fileName').textContent = f.name;
  usingProxy = false;
  proxyInfo = null;
  video.onerror = onVideoError;
  video.src = f.url;
}

video.addEventListener('loadedmetadata', () => {
  if (usingProxy) {
    overlay.classList.add('hidden');
    initVideo(proxyInfo.width || video.videoWidth, proxyInfo.height || video.videoHeight);
  } else {
    initVideo(video.videoWidth, video.videoHeight);
  }
});

// Video die Chromium niet kan afspelen (bv. HEVC/4K): maak een lichte voorbeeldkopie
async function onVideoError() {
  if (usingProxy || proxyBusy || !state.path) {
    if (usingProxy) alert('Deze video kan niet worden getoond.');
    return;
  }
  proxyBusy = true;
  busyKind = 'proxy';
  $('#barFill').style.width = '0%';
  showDialog('Voorbeeld maken…', 'Deze video kan niet direct worden getoond (bijv. HEVC/4K). Er wordt een lichte voorbeeldkopie gemaakt. De export gebruikt altijd het originele bestand.', 'busy');
  const r = await window.api.makeProxy(state.path);
  proxyBusy = false;
  if (r.canceled) { overlay.classList.add('hidden'); return; }
  if (!r.ok) { showDialog('Voorbeeld maken mislukt', r.error, 'error'); return; }
  proxyInfo = r;
  usingProxy = true;
  video.src = r.url;
}

window.api.onProxyProgress(({ frac, eta }) => {
  if (busyKind !== 'proxy') return;
  $('#barFill').style.width = Math.round(frac * 100) + '%';
  const left = eta == null ? '' : ' · nog ± ' + (eta > 90 ? Math.round(eta / 60) + ' min' : Math.round(eta) + ' sec');
  $('#dlgInfo').textContent = Math.round(frac * 100) + '%' + left;
});

function initVideo(vw, vh) {
  state.duration = video.duration;
  state.vw = vw;
  state.vh = vh;
  state.start = 0;
  state.end = state.duration;
  state.cropOn = true; // kader staat altijd klaar over de hele video
  state.crop = { x: 0, y: 0, w: state.vw, h: state.vh };
  state.ratioKey = 'free';
  $('#ratio').value = 'free';

  $('#empty').classList.add('hidden');
  frame.classList.remove('hidden');
  $('#bottom').classList.remove('hidden');
  $('#cropTools').classList.remove('hidden');
  $('#exportTools').classList.remove('hidden');
  updateCropUi();
  layout();
  video.currentTime = 0;
  updateTimes();
}

/* ======================= Layout ======================= */

function layout() {
  if (!state.vw) return;
  const availW = stage.clientWidth - 32;
  const availH = stage.clientHeight - 32;
  const s = Math.min(availW / state.vw, availH / state.vh);
  state.scale = s;
  frame.style.width = Math.floor(state.vw * s) + 'px';
  frame.style.height = Math.floor(state.vh * s) + 'px';
  renderCrop();
  updateTimes();
  scheduleStrip();
}
window.addEventListener('resize', layout);

/* ======================= Filmstrip ======================= */

let stripToken = 0, stripTimer = null;
function scheduleStrip() {
  clearTimeout(stripTimer);
  stripTimer = setTimeout(buildStrip, 250);
}

async function buildStrip() {
  if (!state.path) return;
  const token = ++stripToken;
  const W = strip.clientWidth, H = strip.clientHeight;
  if (!W || !H) return;
  const tw = H * (state.vw / state.vh);
  const n = Math.max(1, Math.ceil(W / tw));

  const tv = document.createElement('video');
  tv.muted = true;
  tv.preload = 'auto';
  tv.src = video.src;
  await new Promise((res) => { tv.onloadeddata = res; tv.onerror = res; });
  if (token !== stripToken) return;

  const canvases = [];
  const th = Math.round(H * (window.devicePixelRatio || 1));
  const tpw = Math.round(th * (state.vw / state.vh));
  for (let i = 0; i < n; i++) {
    const c = document.createElement('canvas');
    c.width = tpw; c.height = th;
    canvases.push(c);
  }
  strip.replaceChildren(...canvases);

  for (let i = 0; i < n; i++) {
    if (token !== stripToken) return;
    tv.currentTime = clamp(((i + 0.5) / n) * state.duration, 0, state.duration - 0.05);
    await new Promise((res) => { tv.onseeked = res; tv.onerror = res; });
    if (token !== stripToken) return;
    try { canvases[i].getContext('2d').drawImage(tv, 0, 0, tpw, th); } catch (_) {}
  }
}

/* ======================= Tijdlijn: trim + playhead ======================= */

function updateTimes() {
  if (!state.duration) return;
  const pct = (t) => (t / state.duration) * 100 + '%';
  trimEl.style.left = pct(state.start);
  trimEl.style.right = (100 - (state.end / state.duration) * 100) + '%';
  dimL.style.width = pct(state.start);
  dimR.style.width = (100 - (state.end / state.duration) * 100) + '%';
  playhead.style.left = pct(video.currentTime);
  $('#tStart').textContent = fmt(state.start);
  $('#tEnd').textContent = fmt(state.end);
  $('#tLen').textContent = fmt(state.end - state.start);
  $('#timeNow').textContent = fmt(video.currentTime - state.start);
}

function timeFromEvent(e) {
  const r = strip.getBoundingClientRect();
  return clamp((e.clientX - r.left) / r.width, 0, 1) * state.duration;
}

let tdrag = null;
function startDrag(kind, e) {
  e.preventDefault();
  video.pause();
  tdrag = kind;
  e.target.setPointerCapture?.(e.pointerId);
  moveDrag(e);
}
function moveDrag(e) {
  if (!tdrag) return;
  const t = timeFromEvent(e);
  if (tdrag === 'start') {
    state.start = clamp(t, 0, state.end - MIN_TRIM);
    video.currentTime = state.start;
  } else if (tdrag === 'end') {
    state.end = clamp(t, state.start + MIN_TRIM, state.duration);
    video.currentTime = Math.max(state.start, state.end - 0.05);
  } else {
    video.currentTime = clamp(t, state.start, state.end);
  }
  updateTimes();
}
function endDrag() { tdrag = null; }

$('#hL').addEventListener('pointerdown', (e) => startDrag('start', e));
$('#hR').addEventListener('pointerdown', (e) => startDrag('end', e));
timeline.addEventListener('pointerdown', (e) => {
  if (e.target.closest('.thandle')) return;
  startDrag('scrub', e);
});
window.addEventListener('pointermove', (e) => { moveDrag(e); moveCrop(e); });
window.addEventListener('pointerup', () => { endDrag(); endCrop(); });

/* ======================= Afspelen ======================= */

function togglePlay() {
  if (!state.duration) return;
  if (video.paused) {
    if (video.currentTime < state.start || video.currentTime >= state.end - 0.03) {
      video.currentTime = state.start;
    }
    video.play();
  } else {
    video.pause();
  }
}
$('#btnPlay').addEventListener('click', togglePlay);
video.addEventListener('click', togglePlay);
video.addEventListener('play', () => { $('#btnPlay').textContent = '❚❚'; });
video.addEventListener('pause', () => { $('#btnPlay').textContent = '▶'; });

function tick() {
  if (state.duration) {
    if (!video.paused && video.currentTime >= state.end) {
      video.pause();
      video.currentTime = state.start;
    }
    updateTimes();
  }
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);

window.addEventListener('keydown', (e) => {
  if (!state.duration || !$('#overlay').classList.contains('hidden')) return;
  if (e.target.tagName === 'SELECT') return;
  const step = e.shiftKey ? 1 : FRAME_STEP;
  switch (e.key) {
    case ' ': e.preventDefault(); togglePlay(); break;
    case 'ArrowLeft': e.preventDefault(); video.pause(); video.currentTime = clamp(video.currentTime - step, state.start, state.end); break;
    case 'ArrowRight': e.preventDefault(); video.pause(); video.currentTime = clamp(video.currentTime + step, state.start, state.end); break;
    case 'i': case 'I': state.start = clamp(video.currentTime, 0, state.end - MIN_TRIM); break;
    case 'o': case 'O': state.end = clamp(video.currentTime, state.start + MIN_TRIM, state.duration); break;
  }
  updateTimes();
});

/* ======================= Bijsnijden ======================= */

function ratioValue(key) {
  if (key === 'free') return null;
  if (key === 'orig') return state.vw / state.vh;
  const [a, b] = key.split(':').map(Number);
  return a / b;
}

function isFull() {
  const c = state.crop;
  return c.x < 1 && c.y < 1 && c.w > state.vw - 1 && c.h > state.vh - 1;
}

function updateCropUi() {
  cropEl.classList.toggle('hidden', !state.cropOn);
  $('#cropDim').classList.toggle('hidden', !state.cropOn);
  cropEl.classList.toggle('locked', state.ratioKey !== 'free');
  $('#fast').disabled = state.cropOn && !isFull();
  renderCrop();
}

function renderCrop() {
  if (!state.cropOn) return;
  const s = state.scale, c = state.crop;
  cropEl.style.left = c.x * s + 'px';
  cropEl.style.top = c.y * s + 'px';
  cropEl.style.width = c.w * s + 'px';
  cropEl.style.height = c.h * s + 'px';
  const set = (id, o) => Object.assign($(id).style, o);
  const px = (v) => v + 'px';
  set('#dT', { left: '0', right: '0', top: '0', height: px(c.y * s) });
  set('#dB', { left: '0', right: '0', bottom: '0', top: px((c.y + c.h) * s) });
  set('#dL', { left: '0', width: px(c.x * s), top: px(c.y * s), height: px(c.h * s) });
  set('#dR', { right: '0', left: px((c.x + c.w) * s), top: px(c.y * s), height: px(c.h * s) });
  const ew = Math.floor(c.w / 2) * 2, eh = Math.floor(c.h / 2) * 2;
  cropLabel.textContent = ew + ' × ' + eh;
  $('#fast').disabled = !isFull();
}

$('#btnResetCrop').addEventListener('click', () => {
  state.crop = { x: 0, y: 0, w: state.vw, h: state.vh };
  state.ratioKey = 'free';
  $('#ratio').value = 'free';
  updateCropUi();
});

$('#ratio').addEventListener('change', (e) => {
  state.ratioKey = e.target.value;
  applyRatio(state.ratioKey);
  updateCropUi();
});

function applyRatio(key) {
  const r = ratioValue(key);
  if (!r) return;
  const c = state.crop;
  const cx = c.x + c.w / 2, cy = c.y + c.h / 2;
  let w = Math.min(state.vw, state.vh * r), h = w / r;
  state.crop = {
    x: clamp(cx - w / 2, 0, state.vw - w),
    y: clamp(cy - h / 2, 0, state.vh - h),
    w, h,
  };
}

let cdrag = null;
cropEl.addEventListener('pointerdown', (e) => {
  const h = e.target.dataset.h;
  if (!h) return;
  e.preventDefault();
  e.stopPropagation();
  video.pause();
  const p = pointInVideo(e);
  cdrag = { h, start: { ...state.crop }, origin: p, moved: false, sx: e.clientX, sy: e.clientY };
  e.target.setPointerCapture?.(e.pointerId);
});

function pointInVideo(e) {
  const r = frame.getBoundingClientRect();
  return {
    x: clamp((e.clientX - r.left) / state.scale, 0, state.vw),
    y: clamp((e.clientY - r.top) / state.scale, 0, state.vh),
  };
}

function moveCrop(e) {
  if (!cdrag) return;
  if (Math.abs(e.clientX - cdrag.sx) + Math.abs(e.clientY - cdrag.sy) > 3) cdrag.moved = true;
  const p = pointInVideo(e);
  const { h, start: s } = cdrag;
  const vw = state.vw, vh = state.vh;
  const ratio = ratioValue(state.ratioKey);

  if (h === 'move') {
    state.crop = {
      x: clamp(s.x + (p.x - cdrag.origin.x), 0, vw - s.w),
      y: clamp(s.y + (p.y - cdrag.origin.y), 0, vh - s.h),
      w: s.w, h: s.h,
    };
  } else if (ratio && h.length === 2) {
    // hoek met vaste verhouding: tegenoverliggende hoek blijft staan
    const west = h.includes('w'), north = h.includes('n');
    const ax = west ? s.x + s.w : s.x;
    const ay = north ? s.y + s.h : s.y;
    const dx = west ? -1 : 1, dy = north ? -1 : 1;
    let w = Math.max(0, (p.x - ax) * dx);
    const hh = Math.max(0, (p.y - ay) * dy);
    w = Math.max(w, hh * ratio);
    const availW = dx > 0 ? vw - ax : ax;
    const availH = dy > 0 ? vh - ay : ay;
    w = Math.min(w, availW, availH * ratio);
    w = Math.max(w, MIN_CROP);
    const h2 = w / ratio;
    state.crop = {
      x: dx > 0 ? ax : ax - w,
      y: dy > 0 ? ay : ay - h2,
      w, h: h2,
    };
  } else if (!ratio) {
    let l = s.x, t = s.y, r = s.x + s.w, b = s.y + s.h;
    if (h.includes('w')) l = Math.min(p.x, r - MIN_CROP);
    if (h.includes('e')) r = Math.max(p.x, l + MIN_CROP);
    if (h.includes('n')) t = Math.min(p.y, b - MIN_CROP);
    if (h.includes('s')) b = Math.max(p.y, t + MIN_CROP);
    state.crop = { x: l, y: t, w: r - l, h: b - t };
  }
  renderCrop();
}
function endCrop() {
  // een klik (zonder slepen) in het kader werkt als klik op de video: afspelen/pauzeren
  if (cdrag && cdrag.h === 'move' && !cdrag.moved) togglePlay();
  cdrag = null;
}

/* ======================= Exporteren ======================= */

let exporting = false;
const overlay = $('#overlay');
function showDialog(title, info, mode) {
  $('#dlgTitle').textContent = title;
  $('#dlgInfo').textContent = info || '';
  $('#btnCancel').classList.toggle('hidden', mode !== 'busy');
  $('#btnReveal').classList.toggle('hidden', mode !== 'done');
  $('#btnClose').classList.toggle('hidden', mode === 'busy');
  overlay.classList.remove('hidden');
}

let lastOutput = null;
window.api.onProgress((v) => {
  if (busyKind !== 'export') return;
  $('#barFill').style.width = Math.round(v * 100) + '%';
  $('#dlgInfo').textContent = Math.round(v * 100) + '%';
});

// onthoud het gekozen bestandstype voor de volgende keer
try { const f = localStorage.getItem('cliptrim.format'); if (f === 'mp4' || f === 'mkv') $('#format').value = f; } catch (_) {}
$('#format').addEventListener('change', () => { try { localStorage.setItem('cliptrim.format', $('#format').value); } catch (_) {} });

$('#btnExport').addEventListener('click', async () => {
  if (!state.path) return;
  video.pause();
  const base = state.path.replace(/\.[^.\\/]+$/, '');
  const ext = $('#format').value === 'mkv' ? 'mkv' : 'mp4';
  let out = await window.api.saveDialog(base + ' (ingekort).' + ext, ext);
  if (!out) return;
  if (!out.toLowerCase().endsWith('.' + ext)) out += '.' + ext; // bestandstype volgt altijd je keuze
  exporting = true;

  const useCrop = state.cropOn && !isFull();
  const c = state.crop;
  const opts = {
    input: state.path,
    output: out,
    start: state.start,
    duration: state.end - state.start,
    crop: useCrop ? { x: c.x / state.vw, y: c.y / state.vh, w: c.w / state.vw, h: c.h / state.vh } : null,
    fast: $('#fast').checked && !useCrop,
    crf: Number($('#quality').value),
  };

  busyKind = 'export';
  $('#barFill').style.width = '0%';
  showDialog('Exporteren…', '0%', 'busy');
  const r = await window.api.exportVideo(opts);
  exporting = false;
  if (r.ok) {
    lastOutput = r.output;
    $('#barFill').style.width = '100%';
    showDialog('Klaar', out, 'done');
  } else if (r.canceled) {
    overlay.classList.add('hidden');
  } else {
    showDialog('Exporteren mislukt', r.error, 'error');
  }
});

$('#btnCancel').addEventListener('click', () => (busyKind === 'proxy' ? window.api.cancelProxy() : window.api.cancelExport()));
$('#btnClose').addEventListener('click', () => overlay.classList.add('hidden'));
$('#btnReveal').addEventListener('click', () => { if (lastOutput) window.api.reveal(lastOutput); });

/* ======================= Open / drag & drop ======================= */

$('#btnOpen').addEventListener('click', openDialog);

// slepen werkt overal in het venster, ook als er al een video open staat
['dragenter', 'dragover'].forEach((ev) => document.addEventListener(ev, (e) => {
  e.preventDefault(); stage.classList.add('drag');
}));
document.addEventListener('dragleave', (e) => {
  e.preventDefault();
  if (!e.relatedTarget) stage.classList.remove('drag');
});
document.addEventListener('drop', async (e) => {
  e.preventDefault(); stage.classList.remove('drag');
  const file = e.dataTransfer.files[0];
  if (!file) return;
  const p = window.api.pathForFile(file);
  if (p) loadFile(await window.api.describe(p));
});

// video meegegeven bij het starten (bv. "Openen met" of video op ClipTrim.exe slepen)
window.api.onOpenFile((f) => loadFile(f));


/* ======================= Updates ======================= */

const updBar = $('#updateBar'), updText = $('#updateText'), updAction = $('#updAction');
let updHideTimer = null;

function showBar(text, action, sticky) {
  clearTimeout(updHideTimer);
  updText.textContent = text;
  if (action) {
    updAction.textContent = action.label;
    updAction.onclick = action.run;
    updAction.classList.remove('hidden');
  } else {
    updAction.classList.add('hidden');
  }
  updBar.classList.remove('hidden');
  if (!sticky) updHideTimer = setTimeout(() => updBar.classList.add('hidden'), 6000);
}
$('#updClose').addEventListener('click', () => updBar.classList.add('hidden'));

async function showVersions() {
  try {
    const v = await window.api.versions();
    $('#verLabel').textContent = 'v' + v.shell + ' · onderdelen ' + v.app;
  } catch (_) {}
}
showVersions();

window.api.onUpdate((ev) => {
  const restart = ev.installed.find((i) => i.restart);
  if (restart) {
    showBar('Update ' + restart.version + ' is gedownload. Herstart ClipTrim om te vernieuwen.', {
      label: 'Nu herstarten',
      run: () => {
        if (exporting) { alert('Wacht tot de export klaar is en probeer het dan opnieuw.'); return; }
        window.api.restartNow();
      },
    }, true);
  } else if (ev.installed.length) {
    showBar('Videoverwerking (ffmpeg) is bijgewerkt naar ' + ev.installed[0].version + '.', null, false);
  } else if (ev.shell) {
    showBar('Nieuwe programmaversie ' + ev.shell.version + ' is beschikbaar.', {
      label: 'Downloaden', run: () => window.api.openUrl(ev.shell.url),
    }, true);
  } else if (ev.manual) {
    showBar(ev.error ? 'Updates controleren mislukt: ' + ev.error : 'Je gebruikt de nieuwste versie.', null, false);
  }
  showVersions();
});

$('#btnUpdate').addEventListener('click', () => {
  showBar('Controleren op updates…', null, true);
  window.api.checkUpdates();
});


/* ======================= Nieuw project ======================= */

function isEdited() {
  return state.duration > 0 && (state.start > 0.05 || state.end < state.duration - 0.05 ||
    (state.cropOn && state.crop && !isFull()));
}

function resetProject() {
  video.pause();
  video.removeAttribute('src');
  video.load();
  stripToken++;
  strip.replaceChildren();
  Object.assign(state, { path: null, name: '', duration: 0, vw: 0, vh: 0, start: 0, end: 0, cropOn: false, crop: null, ratioKey: 'free' });
  usingProxy = false;
  proxyInfo = null;
  $('#fileName').textContent = '';
  $('#ratio').value = 'free';
  $('#fast').checked = false;
  for (const id of ['#frame', '#bottom', '#cropTools', '#exportTools', '#crop', '#cropDim']) $(id).classList.add('hidden');
  $('#empty').classList.remove('hidden');
}

async function newProject() {
  if (exporting || proxyBusy) { alert('Wacht tot het exporteren of het voorbeeld maken klaar is.'); return; }
  if (isEdited() && !confirm('Je huidige inkorting en bijsnijding gaan verloren. Nieuw project starten?')) return;
  resetProject();
  openDialog();
}

$('#btnNew').addEventListener('click', newProject);
window.addEventListener('keydown', (e) => {
  if (e.ctrlKey && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 'n') { e.preventDefault(); newProject(); }
});
