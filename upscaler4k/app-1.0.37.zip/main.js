const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const https = require('https');
const { spawn, execFile } = require('child_process');

const AI_URL = 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip';
const DOELEN = {
  '1080': { b: 1920, h: 1080, naam: 'FullHD' },
  '1440': { b: 2560, h: 1440, naam: '2K' },
  '2160': { b: 3840, h: 2160, naam: '4K' }
};
function doelVan(opties) { return DOELEN[opties && opties.doel] || DOELEN['2160']; }
const SEGMENT_SECONDEN = 10;
const VOORBEELD_SECONDEN = 10;

let win = null;
let actief = null; // { geannuleerd, procs:Set }

// ---------- paden ----------
const U = () => global.upscalerUpdater;
function ffmpegPad() { return U().ffmpegPath(); }

// ---------- instellingen ----------
const STANDAARD_INSTELLINGEN = { doel: '2160', opslag: 'naast', opslagMap: '', autoUpdate: true, taal: 'auto' };
const TALEN = ['nl', 'en', 'es'];
function instellingenPad() { return path.join(app.getPath('userData'), 'settings.json'); }
function leesInstellingen() {
  try { return { ...STANDAARD_INSTELLINGEN, ...JSON.parse(fs.readFileSync(instellingenPad(), 'utf8')) }; }
  catch (e) { return { ...STANDAARD_INSTELLINGEN }; }
}
function schrijfInstellingen(s) {
  fs.mkdirSync(path.dirname(instellingenPad()), { recursive: true });
  fs.writeFileSync(instellingenPad(), JSON.stringify(s, null, 2));
}
// ---------- taal (Nederlands, Engels, Spaans) ----------
function taalActief() {
  const t = leesInstellingen().taal;
  if (TALEN.includes(t)) return t;
  const l = String(app.getLocale() || '').toLowerCase();
  if (l.startsWith('nl')) return 'nl';
  if (l.startsWith('es')) return 'es';
  return 'en';
}
const MT = {
  nl: {
    geenVideo: 'Geen videostream gevonden in dit bestand.', geenEncoder: 'Geen bruikbare video-encoder gevonden.',
    dlMislukt: 'Download mislukt: HTTP {c}', aiNietGevonden: 'realesrgan-ncnn-vulkan.exe niet gevonden na uitpakken.',
    aiNietGeinstalleerd: 'De AI-engine is nog niet geïnstalleerd.',
    geenGpu: 'Geen geschikte videokaart met Vulkan-ondersteuning gevonden. Werk je videokaartstuurprogramma bij, of kies de methode "Snel (ffmpeg)".',
    gpu: 'Videokaart: {n}', splitsen: 'Video in delen splitsen…', splitsMislukt: 'Splitsen van de video mislukt.',
    uitpakken: 'Deel {i}/{n}: frames uitpakken…', aiGestart: 'Deel {i}/{n}: AI-upscale gestart (0/{a}). Het eerste beeldje duurt even…',
    aiVoortgang: 'Deel {i}/{n}: AI-upscale ({k}/{a}) · {s}', snelheidPerS: '{x} beeldjes/s', snelheidSPer: '{x} s per beeldje',
    coderen: 'Deel {i}/{n}: coderen…', samenvoegen: 'Samenvoegen met geluid…', opschalen: 'Opschalen…',
    alGroot: 'Deze video is al {n} of groter.', bezig: 'Er loopt al een taak.', voorbeeldKnippen: 'Voorbeeldstuk knippen…', bewaren: 'Bewaren wat al klaar is…', fotoOpschalen: 'Foto {i} van {n} opschalen…', fotoAi: 'Foto {i} van {n}: AI-engine bezig…', fotoOpslaan: 'Foto {i} van {n} opslaan…', geenFotos: 'Geen foto om op te schalen: alles is al groot genoeg.', geenFoto: 'Geen herkenbare foto: {p}',
    start: 'Start ({e})…', klaar: 'Klaar', stopte: '{p} stopte met code {c}', kiesMap: "Kies de map voor opgeschaalde video's"
  },
  en: {
    geenVideo: 'No video stream found in this file.', geenEncoder: 'No usable video encoder found.',
    dlMislukt: 'Download failed: HTTP {c}', aiNietGevonden: 'realesrgan-ncnn-vulkan.exe not found after extracting.',
    aiNietGeinstalleerd: 'The AI engine is not installed yet.',
    geenGpu: 'No suitable graphics card with Vulkan support found. Update your graphics driver, or choose the "Fast (ffmpeg)" method.',
    gpu: 'Graphics card: {n}', splitsen: 'Splitting video into parts…', splitsMislukt: 'Splitting the video failed.',
    uitpakken: 'Part {i}/{n}: extracting frames…', aiGestart: 'Part {i}/{n}: AI upscale started (0/{a}). The first frame takes a moment…',
    aiVoortgang: 'Part {i}/{n}: AI upscale ({k}/{a}) · {s}', snelheidPerS: '{x} frames/s', snelheidSPer: '{x} s per frame',
    coderen: 'Part {i}/{n}: encoding…', samenvoegen: 'Merging with audio…', opschalen: 'Upscaling…',
    alGroot: 'This video is already {n} or larger.', bezig: 'A task is already running.', voorbeeldKnippen: 'Cutting preview clip…', bewaren: 'Saving what is already done…', fotoOpschalen: 'Upscaling photo {i} of {n}…', fotoAi: 'Photo {i} of {n}: AI engine working…', fotoOpslaan: 'Saving photo {i} of {n}…', geenFotos: 'No photo to upscale: everything is already large enough.', geenFoto: 'Not a recognisable photo: {p}',
    start: 'Starting ({e})…', klaar: 'Done', stopte: '{p} stopped with code {c}', kiesMap: 'Choose the folder for upscaled videos'
  },
  es: {
    geenVideo: 'No se encontró ninguna secuencia de vídeo en este archivo.', geenEncoder: 'No se encontró ningún codificador de vídeo utilizable.',
    dlMislukt: 'Error de descarga: HTTP {c}', aiNietGevonden: 'No se encontró realesrgan-ncnn-vulkan.exe tras la extracción.',
    aiNietGeinstalleerd: 'El motor de IA aún no está instalado.',
    geenGpu: 'No se encontró ninguna tarjeta gráfica compatible con Vulkan. Actualiza el controlador de tu tarjeta gráfica o elige el método «Rápido (ffmpeg)».',
    gpu: 'Tarjeta gráfica: {n}', splitsen: 'Dividiendo el vídeo en partes…', splitsMislukt: 'No se pudo dividir el vídeo.',
    uitpakken: 'Parte {i}/{n}: extrayendo fotogramas…', aiGestart: 'Parte {i}/{n}: escalado con IA iniciado (0/{a}). El primer fotograma tarda un poco…',
    aiVoortgang: 'Parte {i}/{n}: escalado con IA ({k}/{a}) · {s}', snelheidPerS: '{x} fotogramas/s', snelheidSPer: '{x} s por fotograma',
    coderen: 'Parte {i}/{n}: codificando…', samenvoegen: 'Uniendo con el audio…', opschalen: 'Escalando…',
    alGroot: 'Este vídeo ya es {n} o mayor.', bezig: 'Ya hay una tarea en curso.', voorbeeldKnippen: 'Cortando el fragmento de vista previa…', bewaren: 'Guardando lo que ya está listo…', fotoOpschalen: 'Escalando foto {i} de {n}…', fotoAi: 'Foto {i} de {n}: motor de IA trabajando…', fotoOpslaan: 'Guardando foto {i} de {n}…', geenFotos: 'Ninguna foto que escalar: todo es ya lo bastante grande.', geenFoto: 'No es una foto reconocible: {p}',
    start: 'Iniciando ({e})…', klaar: 'Listo', stopte: '{p} se detuvo con el código {c}', kiesMap: 'Elige la carpeta para los vídeos escalados'
  }
};
function T(sleutel, v) {
  const tekst = (MT[taalActief()] || MT.nl)[sleutel] || MT.nl[sleutel] || sleutel;
  return tekst.replace(/\{(\w+)\}/g, (_m, k) => (v && v[k] !== undefined ? v[k] : ''));
}

// Map waar het resultaat komt; valt terug op "naast het origineel" als de gekozen map niet bruikbaar is.
function resultaatMap(invoer) {
  const s = leesInstellingen();
  let map = null;
  if (s.opslag === 'downloads') map = app.getPath('downloads');
  else if (s.opslag === 'map' && s.opslagMap) map = s.opslagMap;
  if (map) {
    try { fs.mkdirSync(map, { recursive: true }); fs.accessSync(map, fs.constants.W_OK); return map; }
    catch (e) { /* terugvallen */ }
  }
  return invoer ? path.dirname(invoer) : app.getPath('downloads');
}
function aiMap() { return path.join(app.getPath('userData'), 'realesrgan'); }
function aiExe() {
  const map = aiMap();
  if (!fs.existsSync(map)) return null;
  const stack = [map];
  while (stack.length) {
    const d = stack.pop();
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const f = path.join(d, e.name);
      if (e.isDirectory()) stack.push(f);
      else if (e.name.toLowerCase() === 'realesrgan-ncnn-vulkan.exe') return f;
    }
  }
  return null;
}

// ---------- videokaart-detectie ----------
let gpuCache = null;

function scoreGpu(naam) {
  const n = naam.toLowerCase();
  if (/llvmpipe|swiftshader|lavapipe|microsoft|basic render|software|\bcpu\b/.test(n)) return -1;
  if (/nvidia|geforce|rtx|gtx|quadro|tesla/.test(n)) return 100;
  if (/radeon (rx|pro)|radeon vii|\barc\b|instinct/.test(n)) return 90;
  if (/radeon|\bamd\b/.test(n)) return 50; // meestal geïntegreerd
  if (/intel|iris|uhd|hd graphics/.test(n)) return 30;
  return 40;
}

function parseVulkanGpus(tekst) {
  const res = [];
  const gezien = new Set();
  for (const l of tekst.split(/\r?\n/)) {
    const m = /^\[(\d+)\s+(.+?)\]\s+queueC/.exec(l.trim());
    if (m && !gezien.has(m[1])) { gezien.add(m[1]); res.push({ index: +m[1], naam: m[2].trim() }); }
  }
  return res;
}

async function windowsGpus() {
  const r = await runCollect('powershell.exe', ['-NoProfile', '-Command',
    'Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }']);
  return r.stdout.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
}

async function detecteerGpu(opnieuw) {
  if (gpuCache && !opnieuw && (gpuCache.aiKlaar === !!aiExe())) return gpuCache;
  const windows = await windowsGpus();
  const exe = aiExe();
  if (!exe) {
    return (gpuCache = { windows, vulkan: [], gekozen: null, aiKlaar: false });
  }
  // Korte testrun op een klein plaatje: Real-ESRGAN meldt dan welke Vulkan-GPU's er zijn.
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'gpu_'));
  let vulkan = [];
  try {
    const inDir = path.join(tmp, 'in');
    const outDir = path.join(tmp, 'out');
    fs.mkdirSync(inDir); fs.mkdirSync(outDir);
    await runCollect(ffmpegPad(), ['-hide_banner', '-y', '-f', 'lavfi', '-i', 'testsrc=size=64x64:rate=1',
      '-frames:v', '1', path.join(inDir, 't.png')]);
    const r = await runCollect(exe, ['-i', inDir, '-o', outDir, '-n', 'realesr-animevideov3-x2', '-s', '2',
      '-m', path.join(path.dirname(exe), 'models')]);
    vulkan = parseVulkanGpus(r.stdout + '\n' + r.stderr);
  } finally {
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) { /* negeren */ }
  }
  let gekozen = null;
  for (const g of vulkan) {
    const s = scoreGpu(g.naam);
    if (s >= 0 && (!gekozen || s > gekozen.score)) gekozen = { ...g, score: s };
  }
  return (gpuCache = { windows, vulkan, gekozen, aiKlaar: true });
}

function stuur(kanaal, data) {
  if (win && !win.isDestroyed()) win.webContents.send(kanaal, data);
}

// ---------- hulpfuncties ----------
function runCollect(exe, args) {
  return new Promise((resolve) => {
    execFile(exe, args, { maxBuffer: 64 * 1024 * 1024, windowsHide: true }, (err, stdout, stderr) => {
      resolve({ err, stdout: String(stdout || ''), stderr: String(stderr || '') });
    });
  });
}

// ---------- logboek (voor het opsporen van problemen) ----------
function logPad() { return path.join(app.getPath('userData'), 'upscaler.log'); }
function log(tekst) {
  try {
    const p = logPad();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    try { if (fs.statSync(p).size > 1024 * 1024) fs.writeFileSync(p, ''); } catch (e) { /* nieuw bestand */ }
    fs.appendFileSync(p, new Date().toISOString() + '  ' + tekst + '\n');
  } catch (e) { /* negeren */ }
}

function spawnTracked(exe, args, onLine, jobCtx, opts = {}) {
  return new Promise((resolve, reject) => {
    if (jobCtx.geannuleerd) return reject(new Error('Geannuleerd'));
    const t0 = Date.now();
    log('START ' + path.basename(exe) + ' ' + args.map((a) => (/\s/.test(a) ? '"' + a + '"' : a)).join(' ').slice(0, 300));
    // stdin dicht: ffmpeg wacht dan nooit op toetsenbordinvoer
    const p = spawn(exe, args, { windowsHide: true, stdio: [opts.zacht ? 'pipe' : 'ignore', 'pipe', 'pipe'] });
    jobCtx.procs.add(p);
    if (opts.zacht) jobCtx.zacht = p;
    let staart = '';
    const verwerk = (buf) => {
      const tekst = buf.toString();
      staart = (staart + tekst).slice(-4000);
      if (onLine) tekst.split(/\r?\n|\r/).forEach((l) => l && onLine(l));
    };
    p.stdout.on('data', verwerk);
    p.stderr.on('data', verwerk);
    p.on('error', (e) => { jobCtx.procs.delete(p); reject(e); });
    p.on('close', (code) => {
      jobCtx.procs.delete(p);
      log('KLAAR ' + path.basename(exe) + ' code ' + code + ' na ' + ((Date.now() - t0) / 1000).toFixed(1) + ' s');
      if (jobCtx.geannuleerd) {
        if (opts.zacht && code === 0) return resolve(); // ffmpeg heeft het bestand netjes afgesloten
        return reject(new Error('Geannuleerd'));
      }
      if (code === 0) resolve();
      else reject(new Error(`${T('stopte', { p: path.basename(exe), c: code })}\n${staart}`));
    });
  });
}

function parseTijd(s) {
  const m = /(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(s);
  return m ? (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]) : 0;
}

async function videoInfo(pad) {
  const r = await runCollect(ffmpegPad(), ['-hide_banner', '-i', pad]);
  const t = r.stderr;
  const dur = /Duration:\s*([\d:.]+)/.exec(t);
  const vid = /Stream #.*Video:.*?(\d{2,5})x(\d{2,5})/.exec(t);
  const fps = /(\d+(?:\.\d+)?)\s*fps/.exec(t);
  const heeftAudio = /Stream #.*Audio:/.test(t);
  if (!vid) throw new Error(T('geenVideo'));
  return {
    pad,
    naam: path.basename(pad),
    duur: dur ? parseTijd(dur[1]) : 0,
    breedte: +vid[1],
    hoogte: +vid[2],
    fps: fps ? parseFloat(fps[1]) : 25,
    audio: heeftAudio
  };
}

// ---------- encoder-keuze ----------
async function kiesEncoder(codec) {
  // codec: 'hevc' | 'h264'
  const ff = ffmpegPad();
  const lijst = (await runCollect(ff, ['-hide_banner', '-encoders'])).stdout;
  const kandidaten = codec === 'hevc'
    ? [['hevc_nvenc', ['-preset', 'p5', '-rc', 'vbr', '-cq', '21', '-b:v', '0']],
       ['hevc_qsv', ['-global_quality', '21']],
       ['hevc_amf', ['-quality', 'quality', '-rc', 'cqp', '-qp_i', '21', '-qp_p', '21']],
       ['libx265', ['-preset', 'medium', '-crf', '20']]]
    : [['h264_nvenc', ['-preset', 'p5', '-rc', 'vbr', '-cq', '20', '-b:v', '0']],
       ['h264_qsv', ['-global_quality', '20']],
       ['h264_amf', ['-quality', 'quality', '-rc', 'cqp', '-qp_i', '20', '-qp_p', '20']],
       ['libx264', ['-preset', 'medium', '-crf', '18']]];
  for (const [naam, opts] of kandidaten) {
    if (!lijst.includes(naam)) continue;
    if (naam.startsWith('lib')) return { naam, opts };
    // hardware-encoder echt even testen
    const test = await runCollect(ff, ['-hide_banner', '-f', 'lavfi', '-i', 'testsrc=size=640x360:rate=25',
      '-frames:v', '3', '-pix_fmt', 'yuv420p', '-c:v', naam, '-f', 'null', '-']);
    if (!test.err) return { naam, opts };
  }
  throw new Error(T('geenEncoder'));
}

function schaalFilter(doel) {
  return `scale=${doel.b}:${doel.h}:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos`;
}

function codecExtra(enc) {
  const extra = ['-pix_fmt', 'yuv420p'];
  if (enc.naam.includes('hevc') || enc.naam === 'libx265') extra.push('-tag:v', 'hvc1');
  return extra;
}

// ---------- engine-status / AI installeren ----------
function downloadBestand(url, doel, voortgang, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 8) return reject(new Error('Te veel redirects'));
    https.get(url, { headers: { 'User-Agent': 'Upscaler4K' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        return resolve(downloadBestand(new URL(res.headers.location, url).toString(), doel, voortgang, redirects + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(T('dlMislukt', { c: res.statusCode }))); }
      const totaal = +res.headers['content-length'] || 0;
      let binnen = 0;
      const out = fs.createWriteStream(doel);
      res.on('data', (c) => { binnen += c.length; if (totaal) voortgang(binnen / totaal); });
      res.pipe(out);
      out.on('finish', () => out.close(resolve));
      out.on('error', reject);
      res.on('error', reject);
    }).on('error', reject);
  });
}

ipcMain.handle('engine-status', async () => {
  let gpu = null;
  try { gpu = await detecteerGpu(); } catch (e) { gpu = null; }
  return { ffmpeg: fs.existsSync(ffmpegPad()), ai: !!aiExe(), gpu };
});

ipcMain.handle('installeer-ai', async () => {
  try {
    fs.mkdirSync(aiMap(), { recursive: true });
    const zip = path.join(os.tmpdir(), 'realesrgan.zip');
    stuur('ai-installatie', { fase: 'download', fractie: 0 });
    await downloadBestand(AI_URL, zip, (f) => stuur('ai-installatie', { fase: 'download', fractie: f }));
    stuur('ai-installatie', { fase: 'uitpakken', fractie: 1 });
    const ctx = { geannuleerd: false, procs: new Set() };
    await spawnTracked('powershell.exe', ['-NoProfile', '-Command',
      `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${aiMap()}' -Force`], null, ctx);
    try { fs.unlinkSync(zip); } catch (e) { /* negeren */ }
    if (!aiExe()) throw new Error(T('aiNietGevonden'));
    return { ok: true };
  } catch (e) {
    return { ok: false, fout: e.message };
  }
});

// ---------- bestand kiezen ----------
ipcMain.handle('kies-bestand', async () => {
  const r = await dialog.showOpenDialog(win, {
    properties: ['openFile'],
    filters: [{ name: 'Video', extensions: ['mp4', 'mkv', 'mov', 'avi', 'webm', 'm4v', 'wmv', 'flv', 'ts', 'mpg', 'mpeg'] }]
  });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('video-info', async (_e, pad) => {
  try { return { ok: true, info: await videoInfo(pad) }; }
  catch (e) { return { ok: false, fout: e.message }; }
});

ipcMain.handle('toon-in-map', (_e, pad) => { shell.showItemInFolder(pad); });

// ---------- upscalen ----------
function uitvoerPad(invoer, doel, extensie = '.mp4') {
  const dir = resultaatMap(invoer);
  const basis = path.basename(invoer, path.extname(invoer));
  let n = 0;
  let kandidaat;
  do {
    kandidaat = path.join(dir, `${basis}_${doel.naam}${n ? '_' + n : ''}${extensie}`);
    n++;
  } while (fs.existsSync(kandidaat));
  return kandidaat;
}

async function upscaleSnel(info, opties, enc, ctx, uit) {
  await laadFilters();
  const args = ['-hide_banner', '-y', '-i', info.pad,
    '-map', '0:v:0', '-map', '0:a?',
    '-vf', snelFilter(schaalFilter(doelVan(opties)), opties),
    '-c:v', enc.naam, ...enc.opts, ...codecExtra(enc),
    '-c:a', 'aac', '-b:a', '192k',
    '-movflags', '+faststart',
    '-progress', 'pipe:1', '-nostats', uit];
  await spawnTracked(ffmpegPad(), args, (l) => {
    const m = /^out_time_ms=(\d+)/.exec(l);
    if (m) { ctx.deelDuur = +m[1] / 1e6; ctx.voorTijd = ctx.deelDuur; }
    if (m && info.duur) stuur('voortgang', { fractie: Math.min(0.99, (+m[1] / 1e6) / info.duur), tekst: T('opschalen') });
  }, ctx, { zacht: true });
}

function kiesModel(info, opties) {
  // kleinste factor (2-4) waarmee het resultaat de doelhoogte haalt, zodat het niet onnodig groot wordt
  const factor = Math.min(4, Math.max(2, Math.ceil(doelVan(opties).h / info.hoogte)));
  // 'natuurlijk' gebruikt hetzelfde model als 'realistisch', maar mengt het resultaat daarna met het origineel (zie deelArgs)
  if (opties.modelType === 'realistisch' || opties.modelType === 'natuurlijk') return { model: 'realesrgan-x4plus', schaal: 4 };
  return { model: `realesr-animevideov3-x${factor}`, schaal: factor };
}

// ---------- beeldfilters (afhankelijk van wat de meegeleverde ffmpeg kan) ----------
let FILTERS = null;
async function laadFilters() {
  if (FILTERS) return FILTERS;
  const r = await runCollect(ffmpegPad(), ['-hide_banner', '-filters']);
  FILTERS = new Set();
  r.stdout.split(/\r?\n/).forEach((l) => { const m = /^\s*[T.][S.][C.]\s+(\S+)\s/.exec(l); if (m) FILTERS.add(m[1]); });
  return FILTERS;
}
function heeft(...namen) { return !!FILTERS && namen.every((n) => FILTERS.has(n)); }
function getal(v, std, min, max) { const n = Number(v); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : std; }

// 'Echt: natuurlijk': het AI-beeld wordt alleen gebruikt waar echte randen zitten (ogen, haarlijnen, tekst). In vlakke en fijn
// gestructureerde delen (huid) blijft het gewoon opgeschaalde origineel staan, met wat detail teruggezet en filmkorrel.
//  aiAandeel 0-100: hoe sterk het AI-beeld op de randen meetelt. detail 0-100: hoeveel fijn detail en korrel erbij komt.
function natuurlijkFilter(sf, opties) {
  const aandeel = getal(opties.aiAandeel, 50, 0, 100);
  const detail = getal(opties.detail, 50, 0, 100);
  const hoger = Math.round(255 * aandeel / 100);
  const laag = Math.round(hoger * 0.2);
  const amt = (detail / 100 * 0.9).toFixed(2);
  const korrel = Math.round(detail / 100 * 6);
  const einde = korrel > 0 ? `,noise=alls=${korrel}:allf=t` : '';
  if (heeft('sobel', 'gblur', 'lutyuv', 'maskedmerge', 'unsharp')) {
    return `[0:v]${sf},format=yuv420p[a];[1:v]${sf},format=yuv420p,split=2[b][e];` +
      `[e]sobel=planes=1,gblur=sigma=4:planes=1,lutyuv=y='clip(${laag}+val*6,0,${hoger})'[m];` +
      `[b]unsharp=5:5:${amt}:5:5:0[bb];[bb][a][m]maskedmerge=planes=1${einde}[v]`;
  }
  // oudere ffmpeg zonder die filters: eenvoudige menging over het hele beeld
  const w = (aandeel / 100).toFixed(2);
  return `[0:v]${sf},format=yuv420p[a];[1:v]${sf},format=yuv420p[b];[a][b]blend=all_expr='A*${w}+B*${(1 - w).toFixed(2)}':shortest=1${einde}[v]`;
}

// 'Snel / zonder AI': opschalen met Lanczos, daarna contrastadaptief scherpmaken (cas) en een beetje korrel.
function snelFilter(sf, opties) {
  const scherpte = getal(opties.scherpte, 50, 0, 100);
  const korrel = Math.round(getal(opties.korrel, 50, 0, 100) / 100 * 6);
  const scherp = heeft('cas') ? `,cas=strength=${(scherpte / 100 * 0.8).toFixed(2)}`
    : `,unsharp=5:5:${(scherpte / 100 * 1.4).toFixed(2)}:5:5:0.0`;
  return sf + scherp + (korrel > 0 ? `,noise=alls=${korrel}:allf=t` : '');
}

// Argumenten om AI-beeldjes terug te coderen naar het doel.
function deelArgs(info, opties, beeldenPad, segPad, maxBeelden) {
  const sf = schaalFilter(doelVan(opties));
  const basis = ['-framerate', String(info.fps), '-i', beeldenPad];
  const lim = maxBeelden ? ['-frames:v', String(maxBeelden)] : [];
  if (opties.modelType === 'natuurlijk' && segPad) {
    return [...basis, '-i', segPad, ...lim, '-filter_complex', natuurlijkFilter(sf, opties), '-map', '[v]'];
  }
  return [...basis, ...lim, '-vf', sf + (opties.verscherpen ? ',unsharp=3:3:0.4:3:3:0.0' : '')];
}

async function upscaleAi(info, opties, enc, ctx, uit) {
  const exe = aiExe();
  if (!exe) throw new Error(T('aiNietGeinstalleerd'));
  await laadFilters();
  const gpu = await detecteerGpu();
  if (!gpu.gekozen) {
    throw new Error(T('geenGpu'));
  }
  stuur('voortgang', { fractie: 0, tekst: T('gpu', { n: gpu.gekozen.naam }) });
  const { model, schaal } = kiesModel(info, opties);
  const werk = fs.mkdtempSync(path.join(path.dirname(info.pad), '.upscale_tmp_'));
  ctx.werkmap = werk;
  const ff = ffmpegPad();

  const delen = [];
  let framesInDelen = 0;
  let huidigeOut = null;
  let huidigeSeg = null;
  try {
    // 1. video in segmenten knippen (zonder her-encoderen)
    stuur('voortgang', { fractie: 0, tekst: T('splitsen') });
    const segDir = path.join(werk, 'seg');
    fs.mkdirSync(segDir);
    await spawnTracked(ff, ['-hide_banner', '-y', '-i', info.pad, '-map', '0:v:0', '-c', 'copy',
      '-f', 'segment', '-segment_time', String(SEGMENT_SECONDEN), '-reset_timestamps', '1',
      path.join(segDir, 'seg_%05d.mkv')], null, ctx);
    const segmenten = fs.readdirSync(segDir).filter((f) => f.endsWith('.mkv')).sort();
    if (!segmenten.length) throw new Error(T('splitsMislukt'));

    let aiStart = 0;
    let totaalKlaar = 0;
    for (let i = 0; i < segmenten.length; i++) {
      // voortgang per deel naar de lengte van het deel (het laatste deel is meestal korter), zodat de balk en de resterende tijd evenredig lopen
      const heeftDuur = info.duur > 0;
      const basisFr = heeftDuur ? Math.min(1, i * SEGMENT_SECONDEN / info.duur) : i / segmenten.length;
      const span = heeftDuur ? Math.max(0.001, Math.min(SEGMENT_SECONDEN, info.duur - i * SEGMENT_SECONDEN) / info.duur) : 1 / segmenten.length;
      const seg = path.join(segDir, segmenten[i]);
      const inDir = path.join(werk, 'in');
      const outDir = path.join(werk, 'out');
      huidigeOut = outDir;
      huidigeSeg = seg;
      ctx.voorTijd = i * SEGMENT_SECONDEN;
      fs.mkdirSync(inDir, { recursive: true });
      fs.mkdirSync(outDir, { recursive: true });

      // 2. frames eruit
      stuur('voortgang', { fractie: basisFr, tekst: T('uitpakken', { i: i + 1, n: segmenten.length }) });
      await spawnTracked(ff, ['-hide_banner', '-y', '-i', seg, '-fps_mode', 'passthrough',
        path.join(inDir, 'f_%06d.png')], null, ctx);
      const aantal = fs.readdirSync(inDir).length;

      // 3. AI-upscale
      let klaar = 0;
      if (!aiStart) aiStart = Date.now();
      stuur('voortgang', { fractie: basisFr, tekst: T('aiGestart', { i: i + 1, n: segmenten.length, a: aantal }) });
      // Voortgang = aantal klaarstaande plaatjes in de uitvoermap. Dat is betrouwbaarder dan de tekst van Real-ESRGAN,
      // die per beeldje alleen met de verbose-schakelaar iets meldt.
      const peil = setInterval(() => {
        let n = 0;
        try { n = fs.readdirSync(outDir).length; } catch (e) { return; }
        n = Math.max(0, n - 1); // het laatste bestand kan nog worden geschreven
        if (n === klaar) return;
        totaalKlaar += n - klaar;
        klaar = n;
        ctx.voorTijd = i * SEGMENT_SECONDEN + klaar / (info.fps || 25);
        const snelheid = totaalKlaar / Math.max(1, (Date.now() - aiStart) / 1000);
        const snelTekst = snelheid >= 1 ? T('snelheidPerS', { x: snelheid.toFixed(1) }) : T('snelheidSPer', { x: (1 / snelheid).toFixed(1) });
        stuur('voortgang', {
          fractie: basisFr + span * 0.9 * Math.min(1, klaar / Math.max(1, aantal)),
          tekst: T('aiVoortgang', { i: i + 1, n: segmenten.length, k: klaar, a: aantal, s: snelTekst })
        });
      }, 1000);
      try {
        await spawnTracked(exe, ['-i', inDir, '-o', outDir, '-n', model, '-s', String(schaal), '-f', 'png', '-g', String(gpu.gekozen.index), '-j', '2:2:2', '-v',
          '-m', path.join(path.dirname(exe), 'models')], null, ctx);
      } finally {
        clearInterval(peil);
      }
      totaalKlaar += aantal - klaar; // eventuele laatste plaatjes die het peilen miste

      // 4. delen terug coderen naar 4K
      stuur('voortgang', { fractie: basisFr + span * 0.92, tekst: T('coderen', { i: i + 1, n: segmenten.length }) });
      const deel = path.join(werk, `deel_${String(i).padStart(5, '0')}.mp4`);
      await spawnTracked(ff, ['-hide_banner', '-y', ...deelArgs(info, opties, path.join(outDir, 'f_%06d.png'), seg),
        '-c:v', enc.naam, ...enc.opts, ...codecExtra(enc), '-an', deel], null, ctx);
      delen.push(deel);
      framesInDelen += aantal;
      huidigeOut = null;

      fs.rmSync(inDir, { recursive: true, force: true });
      fs.rmSync(outDir, { recursive: true, force: true });
      fs.rmSync(seg, { force: true });
    }

    // 5. delen aan elkaar plakken + originele audio erbij
    stuur('voortgang', { fractie: 0.97, tekst: T('samenvoegen') });
    const lijst = path.join(werk, 'lijst.txt');
    fs.writeFileSync(lijst, delen.map((d) => `file '${d.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'));
    await spawnTracked(ff, ['-hide_banner', '-y', '-f', 'concat', '-safe', '0', '-i', lijst, '-i', info.pad,
      '-map', '0:v:0', '-map', '1:a?', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k',
      '-movflags', '+faststart', '-shortest', uit], null, ctx);
  } catch (e) {
    // afgebroken: bewaar wat al klaar was, zodat er toch iets te zien is
    if (ctx.geannuleerd && ctx.uitDeel) {
      try {
        const eind = { geannuleerd: false, procs: new Set() }; // deze stappen mogen niet worden afgebroken
        const onderdelen = [...delen];
        let extra = 0;
        stuur('voortgang', { fractie: 0.97, tekst: T('bewaren'), onzeker: true });
        // Het onafgemaakte deel (met het zware natuurlijk-filter op 4K) kost veel tijd om te coderen. Zijn er al complete delen, dan laten we
        // het onafgemaakte deel vallen (hooguit 10 seconden werk), zodat het bewaren in seconden klaar is. Is er nog niets compleet, dan
        // coderen we het onafgemaakte deel met de snelle methode (alleen opschalen).
        if (!delen.length && huidigeOut && fs.existsSync(huidigeOut)) {
          let k = 0;
          while (fs.existsSync(path.join(huidigeOut, `f_${String(k + 1).padStart(6, '0')}.png`))) k++;
          k = Math.max(0, k - 1); // het laatste bestand kan half geschreven zijn
          if (k > 0) {
            const stuk = path.join(werk, 'deel_onaf.mp4');
            await spawnTracked(ff, ['-hide_banner', '-y', ...deelArgs(info, opties, path.join(huidigeOut, 'f_%06d.png'), null, k),
              '-c:v', enc.naam, ...enc.opts, ...codecExtra(enc), '-an', stuk], null, eind);
            onderdelen.push(stuk);
            extra = k;
          }
        }
        if (onderdelen.length) {
          const lijst = path.join(werk, 'lijst_deels.txt');
          fs.writeFileSync(lijst, onderdelen.map((d) => `file '${d.replace(/\\/g, '/').replace(/'/g, "'\\''")}'`).join('\n'));
          await spawnTracked(ff, ['-hide_banner', '-y', '-f', 'concat', '-safe', '0', '-i', lijst, '-i', info.pad,
            '-map', '0:v:0', '-map', '1:a?', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k',
            '-movflags', '+faststart', '-shortest', ctx.uitDeel], null, eind);
          ctx.deelOpgeslagen = true;
          ctx.deelDuur = (framesInDelen + extra) / (info.fps || 25);
          log(`Gedeeltelijk resultaat bewaard: ${ctx.uitDeel} (${ctx.deelDuur.toFixed(1)} s)`);
        }
      } catch (x) { log('Bewaren van het gedeelte mislukt: ' + x.message); }
    }
    throw e;
  } finally {
    // opruimen op de achtergrond: duizenden PNG's verwijderen kan lang duren en hoeft het resultaat niet op te houden
    fs.rm(werk, { recursive: true, force: true }, () => {});
  }
}

function uniekPad(pad) {
  if (!fs.existsSync(pad)) return pad;
  const ext = path.extname(pad), basis = pad.slice(0, -ext.length);
  let n = 1;
  while (fs.existsSync(`${basis}_${n}${ext}`)) n++;
  return `${basis}_${n}${ext}`;
}

// ---------- meekijkend beeld in de voortgang ----------
// Elke paar seconden halen we met één kleine ffmpeg-aanroep (1 draad, klein formaat) het beeld op de plek waar het opschalen nu is.
// Zo blijft de impact op de snelheid verwaarloosbaar. Modus 'uit' haalt helemaal geen beeld op; 'blur' vervaagt in het scherm zelf.
let beeldModus = 'zicht'; // 'zicht' | 'blur' | 'uit'
ipcMain.handle('beeld-modus', (_e, m) => { if (['zicht', 'blur', 'uit'].includes(m)) beeldModus = m; });

function startBeeldLus(ctx) {
  const tmp = path.join(os.tmpdir(), `upscaler4k_live_${process.pid}.jpg`);
  let bezig = false;
  let laatste = -1;
  ctx.beeldTmp = tmp;
  ctx.beeldTimer = setInterval(async () => {
    if (bezig || ctx.geannuleerd || beeldModus === 'uit' || !ctx.beeldBron) return;
    const t = Math.max(0, ctx.voorTijd || 0);
    if (Math.abs(t - laatste) < 0.2) return;
    bezig = true;
    try {
      const r = await runCollect(ffmpegPad(), ['-hide_banner', '-loglevel', 'error', '-y', '-threads', '1', '-ss', t.toFixed(2),
        '-i', ctx.beeldBron, '-frames:v', '1', '-vf', 'scale=640:-2:flags=bilinear', '-q:v', '6', tmp]);
      if (!r.err && !ctx.geannuleerd && beeldModus !== 'uit' && fs.existsSync(tmp)) {
        laatste = t;
        stuur('voortgang-beeld', { data: 'data:image/jpeg;base64,' + fs.readFileSync(tmp).toString('base64'), t, duur: ctx.beeldDuur || 0 });
      }
    } catch (e) { /* een gemist beeldje is niet erg */ }
    bezig = false;
  }, 2000);
}
function stopBeeldLus(ctx) {
  clearInterval(ctx.beeldTimer);
  ctx.beeldTimer = null;
  if (ctx.beeldTmp) try { fs.rmSync(ctx.beeldTmp, { force: true }); } catch (e) { /* negeren */ }
}



// ---------- analyse: welke engine past het best bij dit bestand? ----------
// Van een paar beeldjes (video: verspreid over de film, foto: de foto zelf) worden op de originele resolutie (uitsnede van het midden)
// scherpte, ruis, compressieblokken, vlakke kleurvlakken en aantal kleuren gemeten. Daaruit volgt een advies met uitleg.
const AN_B = 640, AN_H = 360;

function percentiel(arr, p) {
  if (!arr.length) return 0;
  const a = Float32Array.from(arr).sort();
  return a[Math.min(a.length - 1, Math.floor(p * a.length))];
}

function metriekVanBeeld(buf, w, h) {
  const n = w * h;
  const Y = new Float32Array(n);
  const bins = new Uint32Array(4096);
  for (let i = 0, j = 0; i < n; i++, j += 3) {
    const r = buf[j], g = buf[j + 1], b = buf[j + 2];
    Y[i] = 0.299 * r + 0.587 * g + 0.114 * b;
    bins[((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)]++;
  }
  // aantal kleurvakjes dat 90% van de pixels bevat (tekenfilm: weinig; foto: veel)
  const gesorteerd = Array.from(bins).sort((a, b) => b - a);
  let som = 0, kleuren = 0;
  while (kleuren < gesorteerd.length && som < 0.9 * n) som += gesorteerd[kleuren++];
  // scherpte (sterkste randen), vlakheid en blokrand-verhouding
  const hist = new Uint32Array(256);
  let vlak = 0, tel = 0, bdSom = 0, bdN = 0, odSom = 0, odN = 0;
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const gx = Y[i + 1] - Y[i - 1], gy = Y[i + w] - Y[i - w];
      const mag = (Math.abs(gx) + Math.abs(gy)) / 2;
      hist[Math.min(255, Math.round(mag))]++;
      tel++;
      if (mag < 2) vlak++;
      if (mag < 12) { // alleen in rustige gebieden: daar valt een blokrand op
        const d = Math.abs(Y[i] - Y[i - 1]);
        if (x % 8 === 0) { bdSom += d; bdN++; } else { odSom += d; odN++; }
      }
    }
  }
  let cum = 0, p995 = 0;
  for (let v = 0; v < 256; v++) { cum += hist[v]; if (cum >= 0.995 * tel) { p995 = v; break; } }
  // ruis (Immerkaer) per blok van 8x8; de rustigste blokken geven de ruis zonder dat beeldinhoud meetelt
  const sig = [];
  for (let by = 1; by + 9 < h; by += 8) {
    for (let bx = 1; bx + 9 < w; bx += 8) {
      let sm = 0;
      for (let y = by; y < by + 8; y++) {
        for (let x = bx; x < bx + 8; x++) {
          const i = y * w + x;
          sm += Math.abs(Y[i - w - 1] - 2 * Y[i - w] + Y[i - w + 1] - 2 * Y[i - 1] + 4 * Y[i] - 2 * Y[i + 1] + Y[i + w - 1] - 2 * Y[i + w] + Y[i + w + 1]);
        }
      }
      sig.push(Math.sqrt(Math.PI / 2) * sm / (6 * 64));
    }
  }
  return {
    scherp: p995,
    ruis: percentiel(sig, 0.2),
    blok: (bdSom / Math.max(1, bdN)) / ((odSom / Math.max(1, odN)) + 0.05),
    vlak: vlak / Math.max(1, tel),
    kleuren
  };
}

function mediaan(a) { return percentiel(a, 0.5); }

async function analyseerBron(pad, soortBron, info, naStap) {
  const ff = ffmpegPad();
  const W = info.breedte, H = info.hoogte;
  const cw = Math.max(16, Math.min(W, AN_B)) & ~1, ch = Math.max(16, Math.min(H, AN_H)) & ~1;
  const ox = Math.max(0, Math.floor((W - cw) / 2 / 16) * 16), oy = Math.max(0, Math.floor((H - ch) / 2 / 16) * 16);
  const tijden = soortBron === 'video' && info.duur > 4
    ? [0.1, 0.3, 0.5, 0.7, 0.9].map((f) => (info.duur * f).toFixed(2))
    : [null];
  const metingen = [];
  for (const tt of tijden) {
    const tmp = path.join(os.tmpdir(), `upscaler4k_an_${process.pid}_${Date.now()}.raw`);
    const args = ['-hide_banner', '-loglevel', 'error', '-y'];
    if (tt) args.push('-ss', tt);
    args.push('-i', pad, '-frames:v', '1', '-vf', `crop=${cw}:${ch}:${ox}:${oy},format=rgb24`, '-f', 'rawvideo', tmp);
    try {
      const r = await runCollect(ff, args);
      if (!r.err && fs.existsSync(tmp)) {
        const buf = fs.readFileSync(tmp);
        if (buf.length >= cw * 3 * 16 && buf.length % (cw * 3) === 0) metingen.push(metriekVanBeeld(buf, cw, buf.length / (cw * 3)));
      }
    } catch (e) { /* een beeldje overslaan */ }
    try { fs.rmSync(tmp, { force: true }); } catch (e) { /* negeren */ }
    if (naStap) naStap();
  }
  return metingen;
}

// Beslisregels. Drempels zijn bewust voorzichtig: bij twijfel blijft het de standaardkeuze "natuurlijk".
function adviesUitMetingen(m, factor, aiMogelijk) {
  const med = (k) => mediaan(m.map((x) => x[k]));
  const meet = { scherp: med('scherp'), ruis: med('ruis'), blok: med('blok'), vlak: med('vlak'), kleuren: med('kleuren') };
  let soort = 'natuurlijk', code = 'std', aiAandeel = 50, detail = 50;
  const tekenfilm = meet.vlak > 0.6 && meet.kleuren < 120 && meet.ruis < 2.5;
  if (!aiMogelijk) { soort = 'snel'; code = 'geenAi'; }
  else if (tekenfilm) { soort = 'animatie'; code = 'anim'; }
  else if (factor <= 1.6 && meet.scherp >= 45 && meet.ruis < 2.5 && meet.blok < 1.15) { soort = 'snel'; code = 'snel'; }
  else if (meet.ruis >= 3 || meet.blok >= 1.25) { soort = 'natuurlijk'; code = 'ruis'; aiAandeel = 40; detail = 35; }
  else if (meet.scherp < 35) { soort = 'echt'; code = 'zacht'; }
  else if (meet.scherp < 45) { soort = 'natuurlijk'; code = 'std'; aiAandeel = 65; detail = 55; }
  return { soort, code, aiAandeel, detail, meet };
}

ipcMain.handle('analyseer', async (_e, a) => {
  try {
    const foto = !!a.foto;
    const paden = (Array.isArray(a.paden) ? a.paden : []).slice(0, foto ? 5 : 1);
    const infos = a.infos || [];
    const dl = doelVan({ doel: a.doel });
    const alle = [];
    let factor = 99;
    // voortgang voor de balk in het scherm: één stap per beeldje dat wordt gemeten
    const aantal = (inf) => (!foto && inf.duur > 4 ? 5 : 1);
    const totaal = Math.max(1, paden.reduce((som, _p, i) => som + aantal(infos[i] || {}), 0));
    let gedaan = 0;
    stuur('analyse-voortgang', { fractie: 0 });
    for (let i = 0; i < paden.length; i++) {
      const inf = infos[i] || {};
      if (!inf.breedte || !inf.hoogte) continue;
      alle.push(...await analyseerBron(paden[i], foto ? 'foto' : 'video', inf, () => stuur('analyse-voortgang', { fractie: ++gedaan / totaal })));
      const f = foto ? dl.b / Math.max(inf.breedte, inf.hoogte) : dl.h / inf.hoogte;
      factor = Math.min(factor, f); // de kleinste bron bepaalt of er echt veel vergroot moet worden
    }
    if (!alle.length) return { ok: false };
    let aiMogelijk = !!aiExe();
    if (aiMogelijk) { try { aiMogelijk = !!(await detecteerGpu()).gekozen; } catch (e) { aiMogelijk = false; } }
    const r = adviesUitMetingen(alle, factor, aiMogelijk);
    log(`ANALYSE ${foto ? 'foto' : 'video'} · factor ${factor.toFixed(2)} · ${JSON.stringify(r.meet)} → ${r.soort} (${r.code})`);
    return { ok: true, soort: r.soort, code: r.code, aiAandeel: r.aiAandeel, detail: r.detail, factor, meet: r.meet };
  } catch (e) {
    log('FOUT analyse: ' + e.message);
    return { ok: false };
  }
});

// ---------- foto's ----------
const FOTO_EXT = ['jpg', 'jpeg', 'png', 'bmp', 'tif', 'tiff', 'webp'];
// Doel voor foto's: de lange zijde haalt de doelbreedte (3840 voor 4K), ook bij staande foto's of 4:3. Het vak is dus vierkant.
function fotoDoel(opties) {
  const dl = doelVan(opties);
  return { ...dl, b: dl.b, h: dl.b };
}
function fotoLang(f) { return Math.max(f.breedte, f.hoogte); }

async function fotoInfo(pad) {
  const r = await runCollect(ffmpegPad(), ['-hide_banner', '-i', pad]);
  const vid = /Stream #.*Video:.*?(\d{2,5})x(\d{2,5})/.exec(r.stderr);
  if (!vid) throw new Error(T('geenFoto', { p: path.basename(pad) }));
  // klein voorbeeldplaatje voor in het scherm
  let mini = '';
  let miniB = 0, miniH = 0;
  try {
    const tmp = path.join(os.tmpdir(), `upscaler4k_mini_${process.pid}_${Date.now()}.jpg`);
    const m = await runCollect(ffmpegPad(), ['-hide_banner', '-loglevel', 'error', '-y', '-i', pad, '-frames:v', '1',
      '-vf', 'scale=160:-2:flags=bilinear', '-q:v', '8', tmp]);
    if (!m.err && fs.existsSync(tmp)) {
      const buf = fs.readFileSync(tmp);
      mini = 'data:image/jpeg;base64,' + buf.toString('base64');
      fs.rmSync(tmp, { force: true });
      // De afmetingen van het plaatje (ffmpeg draait foto's met een EXIF-draaiing zelf) zijn leidend voor liggend of staand.
      for (let p = 2; p + 9 < buf.length;) {
        if (buf[p] !== 0xff) break;
        const mk = buf[p + 1];
        if (mk >= 0xc0 && mk <= 0xcf && mk !== 0xc4 && mk !== 0xc8 && mk !== 0xcc) { miniH = buf.readUInt16BE(p + 5); miniB = buf.readUInt16BE(p + 7); break; }
        p += 2 + buf.readUInt16BE(p + 2);
      }
    }
  } catch (e) { /* zonder plaatje */ }
  let breedte = +vid[1], hoogte = +vid[2];
  // staande foto's staan vaak liggend opgeslagen met een draaiing (EXIF); ffmpeg draait ze vanzelf, dus de afmetingen draaien mee
  const rot = /rotation of (-?\d+(?:\.\d+)?) degrees/.exec(r.stderr);
  if (rot && Math.abs(Math.round(+rot[1] / 90)) % 2 === 1) [breedte, hoogte] = [hoogte, breedte];
  if (miniB && miniH && breedte !== hoogte && (miniB > miniH) !== (breedte > hoogte)) [breedte, hoogte] = [hoogte, breedte];
  return { pad, naam: path.basename(pad), breedte, hoogte, mini };
}

ipcMain.handle('kies-fotos', async () => {
  const r = await dialog.showOpenDialog(win, {
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Foto', extensions: FOTO_EXT }]
  });
  return r.canceled ? [] : r.filePaths;
});

ipcMain.handle('foto-info', async (_e, paden) => {
  const lijst = [];
  const fouten = [];
  for (const p of (Array.isArray(paden) ? paden : []).slice(0, 500)) {
    if (!FOTO_EXT.includes(path.extname(p).slice(1).toLowerCase())) continue;
    try { lijst.push(await fotoInfo(p)); } catch (e) { fouten.push(e.message); }
  }
  return { ok: lijst.length > 0, fotos: lijst, fout: fouten[0] || '' };
});

async function stuurFotoBeeld(pad, nr, totaal) {
  if (beeldModus === 'uit') return;
  const tmp = path.join(os.tmpdir(), `upscaler4k_live_${process.pid}.jpg`);
  try {
    const r = await runCollect(ffmpegPad(), ['-hide_banner', '-loglevel', 'error', '-y', '-threads', '1', '-i', pad,
      '-frames:v', '1', '-vf', 'scale=640:-2:flags=bilinear', '-q:v', '6', tmp]);
    if (!r.err && fs.existsSync(tmp)) {
      stuur('voortgang-beeld', { data: 'data:image/jpeg;base64,' + fs.readFileSync(tmp).toString('base64'), t: nr, duur: totaal, foto: true });
    }
  } catch (e) { /* een gemist plaatje is niet erg */ }
  try { fs.rmSync(tmp, { force: true }); } catch (e) { /* negeren */ }
}

async function voerFotosUit(opties, voorbeeld) {
  if (actief) return { ok: false, fout: T('bezig') };
  const ctx = { geannuleerd: false, procs: new Set() };
  actief = ctx;
  const werk = fs.mkdtempSync(path.join(os.tmpdir(), 'upscaler4k_foto_'));
  const klaar = [];
  const fouten = [];
  let overgeslagen = 0;
  let huidigeUit = null;
  const t0 = Date.now();
  try {
    await laadFilters();
    if (['zicht', 'blur', 'uit'].includes(opties.beeldModus)) beeldModus = opties.beeldModus;
    const ff = ffmpegPad();
    // ffmpeg draaien en bij een fout de laatste regels uitleg meegeven (alleen de exitcode zegt niets)
    const ffRun = async (args) => {
      const staart = [];
      try {
        await spawnTracked(ff, args, (l) => { if (String(l).trim()) { staart.push(String(l).trim()); if (staart.length > 4) staart.shift(); } }, ctx);
      } catch (e) {
        throw new Error(e.message + (staart.length ? ' — ' + staart.slice(-2).join(' | ') : ''));
      }
    };
    const png = opties.formaat === 'png';
    const ext = png ? '.png' : '.jpg';
    let paden = (Array.isArray(opties.paden) ? opties.paden : []).filter((p) => FOTO_EXT.includes(path.extname(p).slice(1).toLowerCase()));
    if (voorbeeld) paden = paden.slice(0, 1);
    const infos = [];
    for (const p of paden) {
      try {
        const f = await fotoInfo(p);
        const d = fotoDoel(opties);
        if (fotoLang(f) >= d.b) { overgeslagen++; continue; } // al groot genoeg
        infos.push(f);
      } catch (e) { fouten.push(e.message); }
    }
    if (!infos.length) throw new Error(fouten[0] || T('geenFotos'));

    let exe = null, gpu = null;
    if (opties.methode === 'ai') {
      exe = aiExe();
      if (!exe) throw new Error(T('aiNietGeinstalleerd'));
      gpu = await detecteerGpu();
      if (!gpu.gekozen) throw new Error(T('geenGpu'));
    }
    log(`TAAK foto's ${voorbeeld ? 'voorbeeld' : 'volledig'} · ${opties.methode} · ${opties.doel} · ${opties.modelType} · ${opties.formaat} · ${infos.length} foto('s)`);
    const n = infos.length;

    for (let i = 0; i < n; i++) {
      if (ctx.geannuleerd) break;
      const f = infos[i];
      const basis = i / n;
      const span = 1 / n;
      const d = fotoDoel(opties);
      const sf = schaalFilter(d);
      const naam = path.basename(f.pad, path.extname(f.pad));
      let uit;
      if (voorbeeld) {
        uit = uniekPad(path.join(resultaatMap(f.pad), `${naam}_voorbeeld_${d.naam}${ext}`));
      } else {
        uit = uitvoerPad(f.pad, d, ext);
      }
      huidigeUit = uit;
      stuurFotoBeeld(f.pad, i + 1, n);
      try {
        const uitArgs = png ? ['-compression_level', '6'] : ['-q:v', '2', '-pix_fmt', 'yuvj420p'];
        if (opties.methode === 'ai') {
          stuur('voortgang', { fractie: basis, tekst: T('fotoAi', { i: i + 1, n }) });
          const { model, schaal } = kiesModel({ hoogte: Math.max(1, fotoLang(f) * doelVan(opties).h / doelVan(opties).b) }, opties);
          const aiUit = path.join(werk, `ai_${i}.png`);
          // Eerst een gedraaide kopie maken zoals ffmpeg de foto ziet (staande foto's met EXIF-draaiing): de AI-engine negeert die draaiing,
          // en het natuurlijk-filter zou anders twee beelden van verschillende afmetingen proberen samen te voegen.
          const bron = path.join(werk, `bron_${i}.png`);
          await ffRun(['-hide_banner', '-y', '-i', f.pad, '-frames:v', '1', bron]);
          // Real-ESRGAN meldt per tegel een percentage; zonder melding (kleine foto, één tegel) kruipt de balk rustig mee op een schatting.
          let echt = -1;
          const aiStart = Date.now();
          const meld = () => {
            const schat = 1 - Math.exp(-(Date.now() - aiStart) / 1000 / 25); // nadert 100% zonder het te halen
            const p = echt >= 0 ? echt : schat * 0.9;
            // 'onzeker': de balk beweegt dan alleen op een schatting, dus er kan geen betrouwbare resterende tijd van worden gemaakt
            stuur('voortgang', { fractie: basis + span * 0.93 * Math.min(0.99, p), tekst: T('fotoAi', { i: i + 1, n }), onzeker: echt < 0 });
          };
          const peil = setInterval(meld, 700);
          try {
            await spawnTracked(exe, ['-i', bron, '-o', aiUit, '-n', model, '-s', String(schaal), '-f', 'png', '-g', String(gpu.gekozen.index), '-j', '1:2:2',
              '-m', path.join(path.dirname(exe), 'models')], (l) => {
              const m = /(\d+(?:[.,]\d+)?)\s*%/.exec(l);
              if (m) echt = Math.max(echt, Math.min(1, parseFloat(m[1].replace(',', '.')) / 100));
            }, ctx);
          } finally { clearInterval(peil); }
          stuur('voortgang', { fractie: basis + span * 0.93, tekst: T('fotoOpslaan', { i: i + 1, n }) });
          if (opties.modelType === 'natuurlijk') {
            await ffRun(['-hide_banner', '-y', '-i', bron, '-i', aiUit, '-filter_complex', natuurlijkFilter(sf, opties), '-map', '[v]',
              '-frames:v', '1', ...uitArgs, uit]);
          } else {
            await ffRun(['-hide_banner', '-y', '-i', aiUit, '-vf', sf + (opties.verscherpen ? ',unsharp=3:3:0.4:3:3:0.0' : ''),
              '-frames:v', '1', ...uitArgs, uit]);
          }
          try { fs.rmSync(aiUit, { force: true }); fs.rmSync(bron, { force: true }); } catch (e) { /* negeren */ }
        } else {
          stuur('voortgang', { fractie: basis, tekst: T('fotoOpschalen', { i: i + 1, n }) });
          await ffRun(['-hide_banner', '-y', '-i', f.pad, '-vf', snelFilter(sf, opties), '-frames:v', '1', ...uitArgs, uit]);
        }
        klaar.push(uit);
        huidigeUit = null;
        stuur('voortgang', { fractie: basis + span, tekst: T('fotoOpslaan', { i: i + 1, n }) });
        stuurFotoBeeld(uit, i + 1, n);
      } catch (e) {
        if (huidigeUit) try { fs.rmSync(huidigeUit, { force: true }); } catch (x) { /* negeren */ }
        huidigeUit = null;
        if (ctx.geannuleerd) break;
        log('FOUT foto ' + f.naam + ': ' + e.message);
        fouten.push(`${f.naam}: ${String(e.message).split('\n')[0]}`);
      }
    }
    const seconden = Math.round((Date.now() - t0) / 1000);
    if (ctx.geannuleerd) {
      if (klaar.length) return { ok: true, foto: true, geannuleerd: true, uit: klaar, aantal: klaar.length, totaal: infos.length, overgeslagen, fouten, seconden, voorbeeld: !!voorbeeld };
      throw new Error('Geannuleerd');
    }
    if (!klaar.length) throw new Error(fouten[0] || T('geenFotos'));
    stuur('voortgang', { fractie: 1, tekst: T('klaar') });
    return { ok: true, foto: true, uit: klaar, aantal: klaar.length, totaal: infos.length, overgeslagen, fouten, seconden, voorbeeld: !!voorbeeld };
  } catch (e) {
    if (huidigeUit) try { fs.rmSync(huidigeUit, { force: true }); } catch (x) { /* negeren */ }
    log('FOUT ' + (ctx.geannuleerd ? 'geannuleerd' : e.message));
    return { ok: false, fout: ctx.geannuleerd ? 'Geannuleerd' : e.message };
  } finally {
    try { fs.rmSync(werk, { recursive: true, force: true }); } catch (x) { /* negeren */ }
    actief = null;
  }
}

ipcMain.handle('start-fotos', (_e, opties) => voerFotosUit(opties, false));
ipcMain.handle('start-foto-voorbeeld', (_e, opties) => voerFotosUit(opties, true));

async function voerUit(opties, voorbeeld) {
  if (actief) return { ok: false, fout: T('bezig') };
  const ctx = { geannuleerd: false, procs: new Set() };
  actief = ctx;
  let uit = null;
  let fragmentMap = null;
  let fragmentDuur = 0;
  try {
    let info = await videoInfo(opties.pad);
    const doel = doelVan(opties);
    if (info.hoogte >= doel.h) throw new Error(T('alGroot', { n: doel.naam }));
    const enc = await kiesEncoder(opties.codec === 'h264' ? 'h264' : 'hevc');
    const t0 = Date.now();
    log(`TAAK ${voorbeeld ? 'voorbeeld' : 'volledig'} · ${opties.methode} · ${opties.doel} · ${opties.modelType} · ${opties.codec} · ${info.breedte}x${info.hoogte} ${info.fps}fps ${Math.round(info.duur)}s · encoder ${enc.naam}`);

    if (voorbeeld) {
      // Stuk van 10 seconden uit het eerste deel van de video, nauwkeurig geknipt.
      const start = info.duur > 20 ? Math.floor(info.duur * 0.4) : 0;
      const duur = Math.min(VOORBEELD_SECONDEN, Math.max(1, info.duur - start));
      fragmentMap = fs.mkdtempSync(path.join(os.tmpdir(), 'upscaler4k_'));
      const fragment = path.join(fragmentMap, 'fragment.mkv');
      stuur('voortgang', { fractie: 0, tekst: T('voorbeeldKnippen') });
      await spawnTracked(ffmpegPad(), ['-hide_banner', '-y', '-ss', String(start), '-i', info.pad, '-t', String(duur),
        '-map', '0:v:0', '-map', '0:a?', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '10', '-pix_fmt', 'yuv420p',
        '-c:a', 'aac', '-b:a', '192k', fragment], null, ctx);
      // voorbeeld komt in dezelfde map als het eindresultaat (Downloads of gekozen map), zodat je het bestand kunt terugvinden
      const uitMap = resultaatMap(info.pad);
      uit = path.join(uitMap, path.basename(info.pad, path.extname(info.pad)) + `_voorbeeld_${doel.naam}.mp4`);
      info = { ...info, pad: fragment, duur };
      fragmentDuur = duur;
    } else {
      uit = uitvoerPad(info.pad, doel);
    }

    if (['zicht', 'blur', 'uit'].includes(opties.beeldModus)) beeldModus = opties.beeldModus;
    ctx.beeldBron = info.pad;
    ctx.beeldDuur = info.duur;
    ctx.voorTijd = 0;
    startBeeldLus(ctx);
    ctx.uitDeel = uniekPad(uit.replace(/\.mp4$/i, '') + '_gedeeltelijk.mp4');
    stuur('voortgang', { fractie: 0, tekst: T('start', { e: enc.naam }) });
    if (opties.methode === 'ai') await upscaleAi(info, opties, enc, ctx, uit);
    else await upscaleSnel(info, opties, enc, ctx, uit);
    if (ctx.geannuleerd) {
      // snelle methode: ffmpeg heeft het bestand netjes afgesloten tot waar het kwam
      if (fs.existsSync(uit) && fs.statSync(uit).size > 1000) {
        fs.renameSync(uit, ctx.uitDeel);
        ctx.deelOpgeslagen = true;
        log(`Gedeeltelijk resultaat bewaard: ${ctx.uitDeel} (${(ctx.deelDuur || 0).toFixed(1)} s)`);
      }
      throw new Error('Geannuleerd');
    }
    stuur('voortgang', { fractie: 1, tekst: T('klaar') });
    return { ok: true, uit, voorbeeld: !!voorbeeld, fragmentDuur, seconden: Math.round((Date.now() - t0) / 1000), encoder: enc.naam };
  } catch (e) {
    if (uit) try { fs.rmSync(uit, { force: true }); } catch (x) { /* negeren */ }
    log('FOUT ' + (ctx.geannuleerd ? 'geannuleerd' : e.message));
    if (ctx.geannuleerd && ctx.deelOpgeslagen) {
      return { ok: true, gedeeltelijk: true, uit: ctx.uitDeel, deelDuur: ctx.deelDuur || 0, voorbeeld: !!voorbeeld, fragmentDuur, seconden: 0, encoder: '' };
    }
    return { ok: false, fout: ctx.geannuleerd ? 'Geannuleerd' : e.message };
  } finally {
    stopBeeldLus(ctx);
    if (fragmentMap) try { fs.rmSync(fragmentMap, { recursive: true, force: true }); } catch (x) { /* negeren */ }
    actief = null;
  }
}

ipcMain.handle('start-upscale', (_e, opties) => voerUit(opties, false));
ipcMain.handle('start-voorbeeld', (_e, opties) => voerUit(opties, true));
ipcMain.handle('open-bestand', (_e, pad) => shell.openPath(pad));

ipcMain.handle('stop-upscale', () => {
  if (!actief) return;
  actief.geannuleerd = true;
  for (const p of actief.procs) {
    if (p === actief.zacht && p.stdin && !p.stdin.destroyed) {
      // 'q' laat ffmpeg het bestand netjes afsluiten; lukt dat niet binnen 15 s, dan stoppen we hem alsnog
      try { p.stdin.write('q'); } catch (e) { /* negeren */ }
      setTimeout(() => { try { p.kill(); } catch (e) { /* negeren */ } }, 15000).unref();
    } else {
      try { p.kill(); } catch (e) { /* negeren */ }
    }
  }
});

// ---------- venster ----------
function payloadVersie() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'payload.json'), 'utf8')).version || ''; }
  catch (e) { return ''; }
}

function maakVenster() {
  win = new BrowserWindow({
    width: 980, height: 660, minWidth: 860, minHeight: 600,
    backgroundColor: '#1c1c1e',
    title: 'Upscaler4K V.' + payloadVersie(),
    // eigen titelbalk (met de videokaart in het midden); de knoppen van Windows blijven rechts staan
    titleBarStyle: 'hidden',
    titleBarOverlay: { color: '#1c1c1e', symbolColor: '#f2f2f7', height: 36 },
    icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.on('did-finish-load', () => {
    // was dit de eerste start na een update? (de status staat nog op 'proefstart', vóór markGood die bevestigt)
    let bijgewerkt = null;
    try {
      const st = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'updates', 'state.json'), 'utf8'));
      if (st.app && st.app.trial) bijgewerkt = st.app.version;
    } catch (e) { /* geen status = geen update */ }
    U().markGood();
    U().start((payload) => stuur('update-event', payload), leesInstellingen().autoUpdate);
    if (bijgewerkt) stuur('update-event', { type: 'result', bijgewerkt, installed: [], shell: null, manual: false });
  });
}

// ---------- instellingen: IPC ----------
ipcMain.handle('instellingen-get', () => ({
  ...leesInstellingen(),
  taalActief: taalActief(),
  downloadsMap: app.getPath('downloads')
}));
ipcMain.handle('instellingen-set', (_e, deel) => {
  const huidig = leesInstellingen();
  const nieuw = { ...huidig };
  if (deel && ['1080', '1440', '2160'].includes(deel.doel)) nieuw.doel = deel.doel;
  if (deel && ['naast', 'downloads', 'map'].includes(deel.opslag)) nieuw.opslag = deel.opslag;
  if (deel && typeof deel.opslagMap === 'string') nieuw.opslagMap = deel.opslagMap;
  if (deel && typeof deel.autoUpdate === 'boolean') nieuw.autoUpdate = deel.autoUpdate;
  if (deel && (TALEN.includes(deel.taal) || deel.taal === 'auto')) nieuw.taal = deel.taal;
  schrijfInstellingen(nieuw);
  if (nieuw.autoUpdate !== huidig.autoUpdate) U().setAuto(nieuw.autoUpdate);
  return { ...nieuw, taalActief: taalActief(), downloadsMap: app.getPath('downloads') };
});
ipcMain.handle('kies-map', async () => {
  const s = leesInstellingen();
  const r = await dialog.showOpenDialog(win, {
    title: T('kiesMap'),
    properties: ['openDirectory', 'createDirectory'],
    defaultPath: s.opslagMap || app.getPath('downloads')
  });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('open-logboek', () => { log('Logboek geopend'); shell.openPath(logPad()); });
ipcMain.handle('open-resultaatmap', (_e, invoer) => {
  const dir = resultaatMap(invoer);
  try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { /* negeren */ }
  return shell.openPath(dir);
});
ipcMain.handle('open-map', (_e, pad) => { if (pad) shell.openPath(pad); });
ipcMain.handle('open-licenties', (_e, welke) => {
  let pad = path.dirname(process.execPath);
  if (welke === 'ffmpeg') {
    const p = path.join(process.resourcesPath || '', 'app.asar.unpacked', 'node_modules', 'ffmpeg-static');
    if (fs.existsSync(p)) pad = p;
  }
  shell.openPath(pad);
});

// ---------- updates: IPC ----------
ipcMain.handle('versions', () => U().versions());
ipcMain.handle('update-check', async () => { await U().check(true); return true; });
ipcMain.handle('update-restart', () => {
  if (actief) return false;
  app.relaunch(); app.exit(0); return true;
});
ipcMain.handle('open-url', (_e, url) => {
  if (/^https:\/\//.test(String(url))) shell.openExternal(url);
});

app.whenReady().then(maakVenster);
app.on('window-all-closed', () => { app.quit(); });
