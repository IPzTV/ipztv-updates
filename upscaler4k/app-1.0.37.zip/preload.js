const { contextBridge, ipcRenderer, webUtils, webFrame } = require('electron');

contextBridge.exposeInMainWorld('api', {
  zoom: (f) => { try { webFrame.setZoomFactor(f); } catch (e) { /* negeren */ } },
  pathForFile: (file) => webUtils.getPathForFile(file),
  kiesBestand: () => ipcRenderer.invoke('kies-bestand'),
  info: (pad) => ipcRenderer.invoke('video-info', pad),
  status: () => ipcRenderer.invoke('engine-status'),
  installeerAi: () => ipcRenderer.invoke('installeer-ai'),
  analyseer: (a) => ipcRenderer.invoke('analyseer', a),
  kiesFotos: () => ipcRenderer.invoke('kies-fotos'),
  fotoInfo: (paden) => ipcRenderer.invoke('foto-info', paden),
  startFotos: (opties) => ipcRenderer.invoke('start-fotos', opties),
  fotoVoorbeeld: (opties) => ipcRenderer.invoke('start-foto-voorbeeld', opties),
  start: (opties) => ipcRenderer.invoke('start-upscale', opties),
  voorbeeld: (opties) => ipcRenderer.invoke('start-voorbeeld', opties),
  open: (pad) => ipcRenderer.invoke('open-bestand', pad),
  stop: () => ipcRenderer.invoke('stop-upscale'),
  zetBeeldModus: (m) => ipcRenderer.invoke('beeld-modus', m),
  instellingen: () => ipcRenderer.invoke('instellingen-get'),
  bewaarInstellingen: (deel) => ipcRenderer.invoke('instellingen-set', deel),
  kiesMap: () => ipcRenderer.invoke('kies-map'),
  openResultaatMap: (invoer) => ipcRenderer.invoke('open-resultaatmap', invoer),
  openMap: (pad) => ipcRenderer.invoke('open-map', pad),
  openLogboek: () => ipcRenderer.invoke('open-logboek'),
  openLicenties: (welke) => ipcRenderer.invoke('open-licenties', welke),
  versions: () => ipcRenderer.invoke('versions'),
  checkUpdates: () => ipcRenderer.invoke('update-check'),
  restartNow: () => ipcRenderer.invoke('update-restart'),
  openUrl: (u) => ipcRenderer.invoke('open-url', u),
  toon: (pad) => ipcRenderer.invoke('toon-in-map', pad),
  op: (kanaal, fn) => {
    const h = (_e, data) => fn(data);
    ipcRenderer.on(kanaal, h);
    return () => ipcRenderer.removeListener(kanaal, h);
  }
});
