const $ = (id) => document.getElementById(id);
const DOELEN = {
  '1080': { b: 1920, h: 1080, naam: 'Full HD', bestand: 'FullHD' },
  '1440': { b: 2560, h: 1440, naam: '2K', bestand: '2K' },
  '2160': { b: 3840, h: 2160, naam: '4K', bestand: '4K' }
};

let video = null;
let bezig = false;
let aiAanwezig = false;
let gpuInfo = null;
let installeert = false;
let laatsteUit = null;
let bezigVoorbeeld = false;
let inst = null; // opgeslagen instellingen
let taakStart = 0;
let totaalGeschat = 0;
const keuze = { doel: '2160', methode: 'ai', soort: 'echt', codec: 'hevc' };

// ---------- hulpjes ----------
function fmtTijd(s) {
  s = Math.round(s);
  const u = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
  return (u ? u + ':' + String(m).padStart(2, '0') : m) + ':' + String(r).padStart(2, '0');
}
function fmtRest(s) {
  s = Math.max(0, Math.round(s));
  if (s < 10) return t('rest.lt10');
  if (s < 60) return t('rest.sec', { n: Math.round(s / 5) * 5 });
  const m = Math.round(s / 60);
  if (m < 60) return t(m === 1 ? 'rest.min1' : 'rest.min', { n: m });
  const u = Math.floor(m / 60), r = m % 60;
  return r ? t('rest.hrmin', { u, m: r }) : t('rest.hr', { u });
}
function opslagTekst() {
  if (inst && inst.opslag === 'downloads') return t('store.dl');
  if (inst && inst.opslag === 'map' && inst.opslagMap) {
    const naam = inst.opslagMap.split(/[\\/]/).filter(Boolean).pop() || inst.opslagMap;
    return t('store.map', { n: naam });
  }
  return t('store.naast');
}
function even(n) { return Math.round(n / 2) * 2; }
function doelAfmeting(v) {
  const dl = DOELEN[keuze.doel];
  const f = Math.min(dl.b / v.breedte, dl.h / v.hoogte);
  return { b: even(v.breedte * f), h: even(v.hoogte * f) };
}
function gpuOk() { return !!(gpuInfo && gpuInfo.gekozen); }

// ---------- scherm bijwerken ----------
function update() {
  const heeft = !!video;
  $('empty').classList.toggle('hidden', heeft);
  $('summary').classList.toggle('hidden', !heeft);
  $('bottom').classList.toggle('hidden', !heeft);

  // videokaart bovenin
  // videokaart in het midden van de werkbalk; de bestandsnaam staat in de titelbalk van het venster
  // videokaart in het midden van de titelbalk van het venster
  let gpuNaam = '';
  if (gpuOk()) gpuNaam = gpuInfo.gekozen.naam;
  else if (gpuInfo && gpuInfo.windows && gpuInfo.windows.length) gpuNaam = gpuInfo.windows.join(', ');
  $('gpuLabel').textContent = gpuNaam ? t('tb.gpu', { n: gpuNaam }) : '';
  document.title = heeft ? 'Upscaler4K  —  ' + video.naam : 'Upscaler4K';
  $('titleLeft').textContent = heeft ? video.naam : 'Upscaler4K';

  if (!heeft) return;

  // samenvatting
  const dl = DOELEN[keuze.doel];
  const al4k = video.hoogte >= dl.h; // video is al even groot als het doel
  const d = doelAfmeting(video);
  $('resFrom').textContent = `${video.breedte}×${video.hoogte}`;
  $('resTo').textContent = `${d.b}×${d.h}`;
  $('resLabel').textContent = dl.naam;
  $('meta').textContent = t('meta', { d: fmtTijd(video.duur), f: video.fps });
  let advies;
  if (al4k) advies = t('adv.big', { n: dl.naam });
  else if (video.hoogte <= 480) advies = t('adv.low');
  else if (video.hoogte <= 720) advies = t('adv.mid');
  else advies = t('adv.high');
  $('advice').textContent = advies;

  // knoppen
  const ai = keuze.methode === 'ai';
  document.querySelectorAll('#segDoel .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.doel));
  document.querySelectorAll('#segMethode .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.methode));
  document.querySelectorAll('#segSoort .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.soort));
  document.querySelectorAll('#segCodec .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.codec));

  $('colSoort').classList.toggle('hidden', !ai);
  $('nrBestand').textContent = ai ? '4' : '3';
  $('descDoel').textContent = t('goal.' + keuze.doel);

  $('descMethode').textContent = t(ai ? 'desc.ai' : 'desc.fast');
  $('descSoort').textContent = t(keuze.soort === 'echt' ? 'desc.real' : 'desc.anim');
  $('descCodec').textContent = t(keuze.codec === 'hevc' ? 'desc.hevc' : 'desc.h264');

  // AI-engine / videokaart-melding
  const setup = $('setup');
  setup.classList.remove('warn');
  $('btnInstall').classList.add('hidden');
  let klaar = true;
  if (ai && !aiAanwezig) {
    klaar = false;
    setup.classList.remove('hidden');
    $('setupText').textContent = t(installeert ? 'setup.dling' : 'setup.need');
    if (!installeert) $('btnInstall').classList.remove('hidden');
  } else if (ai && !gpuOk()) {
    klaar = false;
    setup.classList.remove('hidden');
    setup.classList.add('warn');
    $('setupText').textContent = t('setup.nogpu');
  } else {
    setup.classList.add('hidden');
  }

  $('btnStart').disabled = !(klaar && !al4k && !bezig);
  $('btnPreview').disabled = !(klaar && !al4k && !bezig);
  $('startHint').textContent = al4k ? '' : t('hint', { d: `${d.b}×${d.h}`, b: dl.bestand, o: opslagTekst() });
}

// ---------- video laden ----------
async function laadVideo(pad) {
  const r = await window.api.info(pad);
  if (!r.ok) { toonDialoog(t('dlg.openFail'), r.fout, 'fout'); return; }
  video = r.info;
  // slimme standaardkeuze
  keuze.methode = (aiAanwezig && gpuOk()) ? 'ai' : 'snel';
  update();
}
async function kiesBestand() {
  if (bezig) return;
  const p = await window.api.kiesBestand();
  if (p) laadVideo(p);
}
function nieuw() {
  if (bezig) return;
  video = null;
  update();
}

$('btnNew').addEventListener('click', () => { nieuw(); kiesBestand(); });
window.addEventListener('keydown', (e) => {
  if (!e.ctrlKey) return;
  const k = e.key.toLowerCase();
  if (k === 'o') { e.preventDefault(); kiesBestand(); }
  if (k === 'n') { e.preventDefault(); nieuw(); kiesBestand(); }
});

// slepen
const stage = $('stage');
window.addEventListener('dragover', (e) => { e.preventDefault(); if (!bezig) stage.classList.add('drag'); });
window.addEventListener('dragleave', (e) => { if (e.target === document.documentElement || !e.relatedTarget) stage.classList.remove('drag'); });
window.addEventListener('drop', (e) => {
  e.preventDefault();
  stage.classList.remove('drag');
  if (bezig) return;
  const f = e.dataTransfer.files[0];
  if (f) laadVideo(window.api.pathForFile(f));
});

// ---------- keuzes ----------
function koppelSeg(id, sleutel) {
  document.querySelectorAll(`#${id} .btn`).forEach((b) => b.addEventListener('click', () => {
    keuze[sleutel] = b.dataset.v;
    update();
  }));
}
koppelSeg('segDoel', 'doel');
koppelSeg('segMethode', 'methode');
koppelSeg('segSoort', 'soort');
koppelSeg('segCodec', 'codec');

// ---------- AI installeren ----------
$('btnInstall').addEventListener('click', async () => {
  installeert = true;
  update();
  const r = await window.api.installeerAi();
  installeert = false;
  if (r.ok) {
    aiAanwezig = true;
    $('setupText').textContent = t('setup.check');
    const s = await window.api.status();
    gpuInfo = s.gpu;
  } else {
    toonDialoog(t('dlg.dlFail'), r.fout, 'fout');
  }
  update();
});
window.api.op('ai-installatie', (d) => {
  $('setupText').textContent = d.fase === 'download'
    ? t('setup.dl', { p: Math.round(d.fractie * 100) }) : t('setup.unzip');
});

// ---------- dialoog ----------
function toonDialoog(titel, info, stand) {
  $('overlay').classList.remove('hidden');
  $('dlgTitle').textContent = titel;
  $('dlgInfo').textContent = info || '';
  $('barFill').className = stand || '';
  $('barFill').style.width = stand ? '100%' : '0%';
  $('btnCancel').classList.add('hidden');
  $('btnReveal').classList.toggle('hidden', stand !== 'ok' || bezigVoorbeeld);
  $('btnPlay').classList.toggle('hidden', stand !== 'ok' || !bezigVoorbeeld);
  $('btnClose').classList.remove('hidden');
}

// ---------- starten ----------
async function draai(voorbeeld) {
  if (!video || bezig) return;
  bezig = true;
  bezigVoorbeeld = voorbeeld;
  laatsteUit = null;
  taakStart = Date.now();
  totaalGeschat = 0;
  update();
  $('overlay').classList.remove('hidden');
  $('dlgTitle').textContent = voorbeeld ? t('dlg.prevTitle') : t('dlg.upTitle', { n: DOELEN[keuze.doel].naam });
  $('barFill').className = '';
  $('barFill').style.width = '0%';
  $('dlgInfo').textContent = t('dlg.starting');
  $('btnCancel').classList.remove('hidden');
  $('btnReveal').classList.add('hidden');
  $('btnPlay').classList.add('hidden');
  $('btnClose').classList.add('hidden');

  const opties = {
    pad: video.pad,
    doel: keuze.doel,
    methode: keuze.methode,
    modelType: keuze.soort === 'echt' ? 'realistisch' : 'algemeen',
    codec: keuze.codec,
    verscherpen: true
  };
  const r = voorbeeld ? await window.api.voorbeeld(opties) : await window.api.start(opties);

  bezig = false;
  if (r.ok && r.gedeeltelijk) {
    laatsteUit = r.uit;
    toonDialoog(t('dlg.partTitle'), t('dlg.partInfo', { a: fmtTijd(r.deelDuur), b: fmtTijd(video.duur), p: r.uit }), 'ok');
  } else if (r.ok) {
    laatsteUit = r.uit;
    if (voorbeeld) {
      // schatting voor de hele video op basis van de gemeten tijd van het voorbeeld
      const factor = r.fragmentDuur > 0 ? video.duur / r.fragmentDuur : 0;
      const schatting = factor > 1.5 ? t('dlg.prevEst', { d: fmtTijd(video.duur), e: fmtRest(r.seconden * factor) }) : '';
      toonDialoog(t('dlg.prevDone'), t('dlg.prevInfo', { t: fmtTijd(r.seconden), s: schatting }), 'ok');
    } else {
      toonDialoog(t('dlg.done'), t('dlg.doneInfo', { t: fmtTijd(r.seconden), p: r.uit }), 'ok');
    }
  } else if (r.fout === 'Geannuleerd') {
    toonDialoog(t('dlg.cancelled'), t('dlg.cancelledInfo'), 'fout');
  } else {
    toonDialoog(t('dlg.failed'), r.fout, 'fout');
  }
  update();
}

$('btnStart').addEventListener('click', () => draai(false));
$('btnPreview').addEventListener('click', () => draai(true));
$('btnPlay').addEventListener('click', () => { if (laatsteUit) window.api.open(laatsteUit); });

$('btnCancel').addEventListener('click', () => {
  $('dlgInfo').textContent = t('dlg.stopping');
  window.api.stop();
});
$('btnClose').addEventListener('click', () => $('overlay').classList.add('hidden'));
$('btnMapBoven').addEventListener('click', () => window.api.openResultaatMap(video ? video.pad : null));
$('btnMap').addEventListener('click', () => { if (video) window.api.openResultaatMap(video.pad); });
$('btnReveal').addEventListener('click', () => { if (laatsteUit) window.api.toon(laatsteUit); });

window.api.op('voortgang', (d) => {
  const f = d.fractie;
  $('barFill').style.width = Math.round(f * 100) + '%';
  let regel2 = '';
  if (bezig && taakStart && f < 1) {
    const verstreken = (Date.now() - taakStart) / 1000;
    if (f >= 0.005 && verstreken >= 8) {
      // totale duur schatten uit de voortgang tot nu toe, afgevlakt zodat het getal niet springt
      const nieuw = verstreken / f;
      totaalGeschat = totaalGeschat ? totaalGeschat * 0.8 + nieuw * 0.2 : nieuw;
      const rest = Math.max(0, totaalGeschat - verstreken);
      const klaar = new Date(Date.now() + rest * 1000).toLocaleTimeString(i18n.locale(), { hour: '2-digit', minute: '2-digit' });
      regel2 = t('dlg.left', { r: fmtRest(rest), k: klaar });
    } else {
      regel2 = t('dlg.calc');
    }
  }
  $('dlgInfo').textContent = `${Math.round(f * 100)}% · ${d.tekst}${regel2}`;
});

// ---------- opstart ----------
(async () => {
  toonVersies();
  inst = await window.api.instellingen();
  i18n.zetTaal(inst.taalActief);
  keuze.doel = inst.doel;
  const s = await window.api.status();
  aiAanwezig = s.ai;
  gpuInfo = s.gpu;
  keuze.methode = (aiAanwezig && gpuOk()) ? 'ai' : 'snel';
  update();
  toonVersies();
})();

/* ======================= Instellingen ======================= */

function toonInstellingen() {
  if (!inst) return;
  document.querySelectorAll('#setDoel .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === inst.doel));
  document.querySelectorAll('input[name="opslag"]').forEach((r) => { r.checked = r.value === inst.opslag; });
  $('dlPad').textContent = inst.downloadsMap ? '(' + inst.downloadsMap + ')' : '';
  $('mapPad').textContent = inst.opslag === 'map'
    ? (inst.opslagMap || t('set.dir.geen'))
    : (inst.opslagMap ? t('set.dir.gekozen', { p: inst.opslagMap }) : '');
  $('btnKiesMap').classList.toggle('hidden', inst.opslag !== 'map');
  $('btnOpenMap').classList.toggle('hidden', !(inst.opslag === 'map' && inst.opslagMap));
  $('autoUpdate').checked = !!inst.autoUpdate;
  document.querySelectorAll('#setTaal .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === i18n.taal()));
}
async function bewaar(deel) {
  inst = await window.api.bewaarInstellingen(deel);
  toonInstellingen();
  update();
}
// pagina: 'inst' (instellingen), 'info' (info en juridisch) of null (terug naar het hoofdscherm)
function toonPagina(naam) {
  const app = $('app');
  app.classList.remove('inst', 'info');
  $('settings').classList.add('hidden');
  $('info').classList.add('hidden');
  if (naam === 'inst') { app.classList.add('inst'); $('settings').classList.remove('hidden'); toonInstellingen(); toonVersies(); }
  if (naam === 'info') { app.classList.add('info'); $('info').classList.remove('hidden'); $('info').scrollTop = 0; toonVersies(); }
  update();
}
function huidigePagina() {
  return $('app').classList.contains('inst') ? 'inst' : ($('app').classList.contains('info') ? 'info' : null);
}
$('btnSettings').addEventListener('click', () => { if (bezig) return; toonPagina(huidigePagina() === 'inst' ? null : 'inst'); });
$('btnInfo').addEventListener('click', () => { if (bezig) return; toonPagina(huidigePagina() === 'info' ? null : 'info'); });
$('btnBack').addEventListener('click', () => toonPagina(null));
$('btnInfoTerug').addEventListener('click', () => toonPagina(null));
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && huidigePagina()) toonPagina(null); });

// links en licentiebestanden op de infopagina
document.querySelectorAll('#info [data-url]').forEach((b) => b.addEventListener('click', () => window.api.openUrl(b.dataset.url)));
document.querySelectorAll('#info [data-lic]').forEach((b) => b.addEventListener('click', () => window.api.openLicenties(b.dataset.lic)));

document.querySelectorAll('#setDoel .btn').forEach((b) => b.addEventListener('click', async () => {
  await bewaar({ doel: b.dataset.v });
  if (!bezig) { keuze.doel = b.dataset.v; update(); }
}));
document.querySelectorAll('input[name="opslag"]').forEach((r) => r.addEventListener('change', async () => {
  if (r.value === 'map' && !inst.opslagMap) {
    const p = await window.api.kiesMap();
    if (!p) { toonInstellingen(); return; }
    await bewaar({ opslag: 'map', opslagMap: p });
  } else {
    await bewaar({ opslag: r.value });
  }
}));
$('btnKiesMap').addEventListener('click', async () => {
  const p = await window.api.kiesMap();
  if (p) await bewaar({ opslag: 'map', opslagMap: p });
});
$('btnOpenMap').addEventListener('click', () => { if (inst && inst.opslagMap) window.api.openMap(inst.opslagMap); });
document.querySelectorAll('#setTaal .btn').forEach((b) => b.addEventListener('click', async () => {
  await bewaar({ taal: b.dataset.v });
  i18n.zetTaal(b.dataset.v);
  // dynamische teksten opnieuw opbouwen
  toonInstellingen();
  toonVersies();
  update();
}));
$('autoUpdate').addEventListener('change', () => bewaar({ autoUpdate: $('autoUpdate').checked }));

/* ======================= Updates ======================= */

const updBar = $('updateBar'), updText = $('updateText'), updAction = $('updAction');
let updHideTimer = null;

function toonBalk(tekst, actie, blijft) {
  clearTimeout(updHideTimer);
  updText.textContent = tekst;
  if (actie) {
    updAction.textContent = actie.label;
    updAction.onclick = actie.run;
    updAction.classList.remove('hidden');
  } else {
    updAction.classList.add('hidden');
  }
  updBar.classList.remove('hidden');
  if (!blijft) updHideTimer = setTimeout(() => updBar.classList.add('hidden'), 10000);
}
$('updClose').addEventListener('click', () => updBar.classList.add('hidden'));

async function toonVersies() {
  try {
    const v = await window.api.versions();
    $('buildBadge').textContent = 'V.' + v.app;
    $('buildBadge').title = t('tb.build', { a: v.app, s: v.shell });
    $('versieInfo').textContent = t('ver', { s: v.shell, a: v.app, f: v.ffmpeg === 'ingebouwd' ? t('ver.bundled') : v.ffmpeg });
    $('infoVersie').textContent = t('info.version', { s: v.shell, a: v.app });
  } catch (e) { /* negeren */ }
}

// blauw bolletje bij Instellingen en Nu controleren als er een update klaarstaat
let wachtOpHerstart = null;
// foutmeldingen van de updater (vast onderdeel, alleen Nederlands) vertalen
function vertaalUpdateFout(e) {
  const m = /updateserver gaf een fout \((\d+)\)/.exec(e);
  if (m) return t('upd.e.server', { c: m[1] });
  if (/Geen verbinding met de updateserver/.test(e)) return t('upd.e.conn');
  return e;
}
function zetUpdateBolletje(aan, titel) {
  wachtOpHerstart = aan ? titel : null;
  for (const id of ['btnSettings', 'btnUpdate']) {
    $(id).classList.toggle('melding', aan);
  }
  $('btnSettings').title = aan ? titel : t('tb.set.title');
}

window.api.op('update-event', (ev) => {
  if (ev.bijgewerkt) {
    const tekst = t('upd.done', { v: ev.bijgewerkt });
    toonBalk('✓ ' + tekst, null, false);
    $('updStatus').textContent = tekst;
    toonVersies();
    return;
  }
  const herstart = ev.installed.find((i) => i.restart);
  let status;
  if (herstart) {
    zetUpdateBolletje(true, t('upd.ready.tip', { v: herstart.version }));
    status = t('upd.dled', { v: herstart.version });
    toonBalk(t('upd.dled.bar', { v: herstart.version }), {
      label: t('upd.restart'),
      run: async () => {
        const ok = await window.api.restartNow();
        if (ok === false) alert(t('upd.wait'));
      }
    }, true);
  } else if (ev.installed.length) {
    status = t('upd.ff', { v: ev.installed[0].version });
    toonBalk(status, null, false);
  } else if (ev.shell) {
    zetUpdateBolletje(true, t('upd.shell.tip'));
    status = t('upd.shell', { v: ev.shell.version });
    toonBalk(status, { label: t('upd.download'), run: () => window.api.openUrl(ev.shell.url) }, true);
  } else if (ev.manual) {
    status = ev.error ? t('upd.fail', { e: vertaalUpdateFout(ev.error) })
      : (wachtOpHerstart || t('upd.latest'));
    toonBalk(status, null, false);
  }
  if (status) $('updStatus').textContent = status;
  toonVersies();
});

$('btnUpdate').addEventListener('click', () => {
  $('updStatus').textContent = t('upd.checking');
  window.api.checkUpdates();
});

$('btnLog').addEventListener('click', () => window.api.openLogboek());
