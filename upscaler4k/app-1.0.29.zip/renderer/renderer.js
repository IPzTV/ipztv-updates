const $ = (id) => document.getElementById(id);
const DOELEN = {
  '1080': { b: 1920, h: 1080, naam: 'Full HD', bestand: 'FullHD' },
  '1440': { b: 2560, h: 1440, naam: '2K', bestand: '2K' },
  '2160': { b: 3840, h: 2160, naam: '4K', bestand: '4K' }
};

let video = null;

// Venster groter (bijv. volledig scherm) -> alles, ook het lettertype, schaalt mee. Basis is 980x660.
// outerWidth/outerHeight veranderen niet door de zoom zelf, dus er ontstaat geen terugkoppeling.
let zoomNu = 0;
function pasZoomToe() {
  if (!window.api || !window.api.zoom) return;
  const f = Math.round(Math.min(Math.max(1, Math.min(window.outerWidth / 980, window.outerHeight / 660)), 2) * 20) / 20;
  if (f === zoomNu) return;
  zoomNu = f;
  window.api.zoom(f);
  document.documentElement.style.setProperty('--z', String(f)); // de titelbalk blijft zo even hoog als de knoppen van Windows
}
window.addEventListener('resize', pasZoomToe);
pasZoomToe();
let bezig = false;
let aiAanwezig = false;
let gpuInfo = null;
let installeert = false;
let laatsteUit = null;
let bezigVoorbeeld = false;
let inst = null; // opgeslagen instellingen
let taakStart = 0;
let totaalGeschat = 0;
const keuze = { doel: '2160', methode: 'ai', soort: 'natuurlijk', codec: 'hevc' };

// De vier engines. m = indicatie [scherp, natuurlijk, snelheid] van 0-5; sliders worden onder de kaarten getoond.
const ENGINES = {
  natuurlijk: { ai: true, model: 'natuurlijk', naam: 'seg.natural', tag: 'tag.rec', desc: 'desc.natural', m: [4, 5, 1],
    sliders: [
      { k: 'aiAandeel', cap: 'cap.ai', n: 'sl.ai', lo: 'sl.orig', hi: 'sl.aiw', std: 50 },
      { k: 'detail', cap: 'cap.detail', n: 'sl.detail', lo: 'sl.smooth', hi: 'sl.lots', std: 50 }] },
  echt: { ai: true, model: 'realistisch', naam: 'seg.real', tag: 'tag.max', desc: 'desc.real', m: [5, 2, 1], sliders: [] },
  animatie: { ai: true, model: 'algemeen', naam: 'seg.anim', tag: 'tag.anim', desc: 'desc.anim', m: [5, 3, 2], sliders: [] },
  snel: { ai: false, model: 'algemeen', naam: 'eng.fast', tag: 'tag.nogpu', desc: 'desc.fast', m: [2, 4, 5],
    sliders: [
      { k: 'scherpte', cap: 'cap.sharp', n: 'sl.sharp', lo: 'sl.soft', hi: 'sl.sharp2', std: 50 },
      { k: 'korrel', cap: 'cap.grain', n: 'sl.grain', lo: 'sl.none', hi: 'sl.lots', std: 50 }] }
};
const waarden = { aiAandeel: 50, detail: 50, scherpte: 50, korrel: 50 }; // alle schuifjes beginnen in het midden
let autoSnel = false;
try {
  const o = JSON.parse(localStorage.getItem('upscaler4k.keuze2') || '{}');
  if (ENGINES[o.soort]) keuze.soort = o.soort;
  ['aiAandeel', 'detail', 'scherpte', 'korrel'].forEach((k) => { if (Number.isFinite(o[k])) waarden[k] = Math.min(100, Math.max(0, o[k])); });
} catch (e) { /* geen bewaarde keuze */ }
function bewaarKeuze() {
  try { localStorage.setItem('upscaler4k.keuze2', JSON.stringify({ soort: keuze.soort, ...waarden })); } catch (e) { /* negeren */ }
}
// zonder AI-engine of videokaart kan alleen "Snel"; zodra het wel kan, gaat de keuze terug naar de aanbevolen engine
function zetStandaard() {
  const kan = aiAanwezig && gpuOk();
  if (!kan && ENGINES[keuze.soort].ai) { keuze.soort = 'snel'; autoSnel = true; }
  else if (kan && autoSnel && keuze.soort === 'snel') { keuze.soort = 'natuurlijk'; autoSnel = false; }
}

// kaarten en schuifjes opbouwen (eenmalig); de teksten worden in update() ververst
function bouwEngines() {
  const wrap = $('engines');
  Object.entries(ENGINES).forEach(([sleutel, e]) => {
    const b = document.createElement('button');
    b.className = 'eng';
    b.dataset.v = sleutel;
    b.innerHTML = `<span class="eng-naam"></span><span class="eng-tag"></span><span class="meters">` +
      ['m.sharp', 'm.nat', 'm.speed'].map((k, i) => `<span class="meter" data-k="${k}"><i></i><b></b></span>`).join('') +
      '</span>';
    b.querySelectorAll('.meter b').forEach((m, i) => { m.style.width = (e.m[i] * 20) + '%'; }); // via script: de CSP staat geen inline style in de HTML toe
    b.addEventListener('click', () => { if (bezig) return; keuze.soort = sleutel; autoSnel = false; bewaarKeuze(); update(); });
    wrap.appendChild(b);
  });
}
// Korte uitleg bij de stand van een schuifje: wat dit voor de verhouding betekent.
function sliderUitleg(s) {
  const v = waarden[s.k];
  const laag = s.k === 'aiAandeel' && v === 0 ? '0' : (v <= 25 ? 'lo' : (v <= 70 ? 'mid' : 'hi'));
  return t(`${s.cap}.${laag}`, { a: v, o: 100 - v });
}
function bouwSliders() {
  const wrap = $('sliders');
  wrap.innerHTML = '';
  const lijst = ENGINES[keuze.soort].sliders;
  const cap = document.createElement('span');
  cap.className = 'sl-uitleg';
  let actief = lijst[0];
  // voorop komt de naam van het schuifje, zodat duidelijk is waar de zin over gaat (bewust zonder tooltip)
  const toonUitleg = () => {
    if (!actief) return;
    cap.textContent = '';
    const kop = document.createElement('b');
    kop.textContent = t(actief.n) + ': ';
    cap.appendChild(kop);
    cap.appendChild(document.createTextNode(sliderUitleg(actief)));
  };
  lijst.forEach((s) => {
    const rij = document.createElement('label');
    rij.className = 'sl';
    rij.innerHTML = `<span class="sl-n"></span><span class="sl-lo muted"></span><input type="range" min="0" max="100" step="5"><span class="sl-hi muted"></span><span class="sl-v"></span>`;
    const inp = rij.querySelector('input');
    inp.value = waarden[s.k];
    const toon = () => { rij.querySelector('.sl-v').textContent = waarden[s.k] + '%'; };
    inp.addEventListener('input', () => { waarden[s.k] = +inp.value; toon(); actief = s; toonUitleg(); });
    inp.addEventListener('focus', () => { actief = s; toonUitleg(); });
    inp.addEventListener('change', bewaarKeuze);
    toon();
    rij.querySelector('.sl-n').textContent = t(s.n);
    rij.querySelector('.sl-lo').textContent = t(s.lo);
    rij.querySelector('.sl-hi').textContent = t(s.hi);
    wrap.appendChild(rij);
  });
  if (lijst.length) {
    wrap.appendChild(cap);
    toonUitleg();
  }
  // knop "Standaard" staat naast de kop; hij zet de schuifjes van de gekozen engine terug naar het midden
  const reset = $('slReset');
  reset.classList.toggle('hidden', !lijst.length);
  reset.onclick = () => {
    lijst.forEach((s) => { waarden[s.k] = s.std; });
    bewaarKeuze();
    bouwSliders();
  };
  wrap.dataset.soort = keuze.soort;
  wrap.dataset.taal = i18n.taal();
}

// ---------- hulpjes ----------
function fmtTijd(s) {
  s = Math.round(s);
  const u = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
  return (u ? u + ':' + String(m).padStart(2, '0') : m) + ':' + String(r).padStart(2, '0');
}
function fmtRest(s) {
  s = Math.max(0, Math.round(s));
  if (s < 10) return t('rest.lt10');
  if (s < 60) return t('rest.sec', { n: Math.round(s / 5) * 5 });
  const m = Math.round(s / 60);
  if (m < 60) return t(m === 1 ? 'rest.min1' : 'rest.min', { n: m });
  const u = Math.floor(m / 60), r = m % 60;
  return r ? t('rest.hrmin', { u, m: r }) : t('rest.hr', { u });
}
function opslagTekst() {
  if (inst && inst.opslag === 'downloads') return t('store.dl');
  if (inst && inst.opslag === 'map' && inst.opslagMap) {
    const naam = inst.opslagMap.split(/[\\/]/).filter(Boolean).pop() || inst.opslagMap;
    return t('store.map', { n: naam });
  }
  return t('store.naast');
}
function even(n) { return Math.round(n / 2) * 2; }
function doelAfmeting(v) {
  const dl = DOELEN[keuze.doel];
  const f = Math.min(dl.b / v.breedte, dl.h / v.hoogte);
  return { b: even(v.breedte * f), h: even(v.hoogte * f) };
}
function gpuOk() { return !!(gpuInfo && gpuInfo.gekozen); }

// ---------- scherm bijwerken ----------
function update() {
  const heeft = !!video;
  $('empty').classList.toggle('hidden', heeft);
  $('summary').classList.toggle('hidden', !heeft);
  $('bottom').classList.toggle('hidden', !heeft);

  // videokaart bovenin
  // videokaart in het midden van de werkbalk; de bestandsnaam staat in de titelbalk van het venster
  // videokaart in het midden van de titelbalk van het venster
  let gpuNaam = '';
  if (gpuOk()) gpuNaam = gpuInfo.gekozen.naam;
  else if (gpuInfo && gpuInfo.windows && gpuInfo.windows.length) gpuNaam = gpuInfo.windows.join(', ');
  $('gpuLabel').textContent = gpuNaam ? t('tb.gpu', { n: gpuNaam }) : '';
  document.title = heeft ? 'Upscaler4K  —  ' + video.naam : 'Upscaler4K';
  $('titleLeft').textContent = heeft ? video.naam : 'Upscaler4K';

  if (!heeft) return;

  // samenvatting
  const dl = DOELEN[keuze.doel];
  const al4k = video.hoogte >= dl.h; // video is al even groot als het doel
  const d = doelAfmeting(video);
  $('resFrom').textContent = `${video.breedte}×${video.hoogte}`;
  $('resTo').textContent = `${d.b}×${d.h}`;
  $('resLabel').textContent = dl.naam;
  $('meta').textContent = t('meta', { d: fmtTijd(video.duur), f: video.fps });
  let advies;
  if (al4k) advies = t('adv.big', { n: dl.naam });
  else if (video.hoogte <= 480) advies = t('adv.low');
  else if (video.hoogte <= 720) advies = t('adv.mid');
  else advies = t('adv.high');
  $('advice').textContent = advies;

  // knoppen
  keuze.methode = ENGINES[keuze.soort].ai ? 'ai' : 'snel';
  const ai = keuze.methode === 'ai';
  document.querySelectorAll('#segDoel .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.doel));
  document.querySelectorAll('#segCodec .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.codec));
  $('descDoel').textContent = t('goal.' + keuze.doel);
  $('descCodec').textContent = t(keuze.codec === 'hevc' ? 'desc.hevc' : 'desc.h264');

  // engine-kaarten
  const kan = aiAanwezig && gpuOk();
  document.querySelectorAll('#engines .eng').forEach((b) => {
    const e = ENGINES[b.dataset.v];
    b.classList.toggle('on', b.dataset.v === keuze.soort);
    b.classList.toggle('uit', e.ai && !kan && aiAanwezig); // AI-engines zonder geschikte videokaart
    b.querySelector('.eng-naam').textContent = t(e.naam);
    b.querySelector('.eng-tag').textContent = t(e.tag);
    b.querySelectorAll('.meter').forEach((m) => { m.querySelector('i').textContent = t(m.dataset.k); });
  });
  $('descEngine').textContent = t(ENGINES[keuze.soort].desc);
  const sl = $('sliders');
  if (sl.dataset.soort !== keuze.soort || sl.dataset.taal !== i18n.taal()) bouwSliders();
  $('sliders').classList.toggle('leeg', !ENGINES[keuze.soort].sliders.length);

  // AI-engine / videokaart-melding
  const setup = $('setup');
  setup.classList.remove('warn');
  $('btnInstall').classList.add('hidden');
  let klaar = true;
  if (ai && !aiAanwezig) {
    klaar = false;
    setup.classList.remove('hidden');
    $('setupText').textContent = t(installeert ? 'setup.dling' : 'setup.need');
    if (!installeert) $('btnInstall').classList.remove('hidden');
  } else if (ai && !gpuOk()) {
    klaar = false;
    setup.classList.remove('hidden');
    setup.classList.add('warn');
    $('setupText').textContent = t('setup.nogpu');
  } else {
    setup.classList.add('hidden');
  }

  $('btnStart').disabled = !(klaar && !al4k && !bezig);
  $('btnPreview').disabled = !(klaar && !al4k && !bezig);
  $('startHint').textContent = al4k ? '' : t('hint', { d: `${d.b}×${d.h}`, b: dl.bestand, o: opslagTekst() });
}

// ---------- video laden ----------
async function laadVideo(pad) {
  const r = await window.api.info(pad);
  if (!r.ok) { toonDialoog(t('dlg.openFail'), r.fout, 'fout'); return; }
  video = r.info;
  // slimme standaardkeuze
  zetStandaard();
  update();
}
async function kiesBestand() {
  if (bezig) return;
  const p = await window.api.kiesBestand();
  if (p) laadVideo(p);
}
function nieuw() {
  if (bezig) return;
  video = null;
  update();
}

$('btnNew').addEventListener('click', () => { nieuw(); kiesBestand(); });
window.addEventListener('keydown', (e) => {
  if (!e.ctrlKey) return;
  const k = e.key.toLowerCase();
  if (k === 'o') { e.preventDefault(); kiesBestand(); }
  if (k === 'n') { e.preventDefault(); nieuw(); kiesBestand(); }
});

// slepen
const stage = $('stage');
window.addEventListener('dragover', (e) => { e.preventDefault(); if (!bezig) stage.classList.add('drag'); });
window.addEventListener('dragleave', (e) => { if (e.target === document.documentElement || !e.relatedTarget) stage.classList.remove('drag'); });
window.addEventListener('drop', (e) => {
  e.preventDefault();
  stage.classList.remove('drag');
  if (bezig) return;
  const f = e.dataTransfer.files[0];
  if (f) laadVideo(window.api.pathForFile(f));
});

// ---------- keuzes ----------
function koppelSeg(id, sleutel) {
  document.querySelectorAll(`#${id} .btn`).forEach((b) => b.addEventListener('click', () => {
    keuze[sleutel] = b.dataset.v;
    update();
  }));
}
koppelSeg('segDoel', 'doel');
koppelSeg('segCodec', 'codec');

// ---------- AI installeren ----------
$('btnInstall').addEventListener('click', async () => {
  installeert = true;
  update();
  const r = await window.api.installeerAi();
  installeert = false;
  if (r.ok) {
    aiAanwezig = true;
    $('setupText').textContent = t('setup.check');
    const s = await window.api.status();
    gpuInfo = s.gpu;
    zetStandaard();
  } else {
    toonDialoog(t('dlg.dlFail'), r.fout, 'fout');
  }
  update();
});
window.api.op('ai-installatie', (d) => {
  $('setupText').textContent = d.fase === 'download'
    ? t('setup.dl', { p: Math.round(d.fractie * 100) }) : t('setup.unzip');
});

// ---------- leuke animatie tijdens het opschalen ----------
const FUN_AANTAL = 12;
let funTimer = null, funNr = 0;
// Tekeningen (160x90). Elke tekening wordt eerst blokkerig getoond en dan scherp onthuld.
const FUN_TEKENINGEN = [
  // 1. berglandschap met 4K
  '<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4aa3ff"/><stop offset="1" stop-color="#ffe9a8"/></linearGradient></defs>'
  + '<rect width="160" height="90" fill="url(#g)"/><circle cx="124" cy="26" r="13" fill="#ffd60a"/>'
  + '<ellipse cx="40" cy="22" rx="16" ry="5" fill="#fff" opacity=".9"/><ellipse cx="52" cy="18" rx="10" ry="5" fill="#fff" opacity=".9"/>'
  + '<polygon points="0,70 36,36 62,62 92,30 130,66 160,50 160,90 0,90" fill="#2c4a7a"/>'
  + '<path d="M0 78 Q40 62 80 76 T160 72 V90 H0Z" fill="#30a14e"/>'
  + '<text x="12" y="62" font-family="Segoe UI, Arial, sans-serif" font-size="26" font-weight="800" fill="#fff" stroke="#0a3c8a" stroke-width="1.2">4K</text>',
  // 2. kat
  '<rect width="160" height="90" fill="#ffd9a0"/><rect y="70" width="160" height="20" fill="#e8b878"/>'
  + '<polygon points="48,34 56,8 76,26" fill="#f08a2e"/><polygon points="112,34 104,8 84,26" fill="#f08a2e"/>'
  + '<polygon points="54,28 57,16 66,25" fill="#ffb7c5"/><polygon points="106,28 103,16 94,25" fill="#ffb7c5"/>'
  + '<ellipse cx="80" cy="52" rx="38" ry="30" fill="#f6a03c"/>'
  + '<ellipse cx="66" cy="46" rx="6" ry="8" fill="#fff"/><ellipse cx="94" cy="46" rx="6" ry="8" fill="#fff"/>'
  + '<ellipse cx="67" cy="47" rx="3" ry="6" fill="#1a1a1a"/><ellipse cx="93" cy="47" rx="3" ry="6" fill="#1a1a1a"/>'
  + '<polygon points="76,56 84,56 80,61" fill="#e0607e"/><path d="M80 61 Q74 68 68 64 M80 61 Q86 68 92 64" stroke="#7a3b10" stroke-width="1.4" fill="none"/>'
  + '<path d="M44 56 L64 59 M44 64 L64 62 M116 56 L96 59 M116 64 L96 62" stroke="#7a3b10" stroke-width="1" fill="none"/>',
  // 3. raket in de ruimte
  '<rect width="160" height="90" fill="#0b1a3a"/>'
  + '<g fill="#fff"><circle cx="14" cy="14" r="1.2"/><circle cx="40" cy="70" r="1"/><circle cx="70" cy="12" r="1.3"/><circle cx="104" cy="22" r="1"/><circle cx="148" cy="12" r="1.4"/><circle cx="150" cy="74" r="1"/><circle cx="24" cy="46" r="1"/><circle cx="126" cy="50" r="1.2"/></g>'
  + '<circle cx="128" cy="66" r="16" fill="#e0723c"/><ellipse cx="128" cy="66" rx="26" ry="5" fill="none" stroke="#f5c08a" stroke-width="2"/>'
  + '<g transform="rotate(35 70 46)"><path d="M70 8 Q86 28 82 62 H58 Q54 28 70 8Z" fill="#f2f2f2"/><path d="M70 8 Q78 16 80 24 H60 Q62 16 70 8Z" fill="#e53935"/>'
  + '<circle cx="70" cy="38" r="7" fill="#5ab0ff" stroke="#2c4a7a" stroke-width="2"/><polygon points="58,50 46,66 58,62" fill="#e53935"/><polygon points="82,50 94,66 82,62" fill="#e53935"/>'
  + '<path d="M62 62 H78 L70 84Z" fill="#ffb300"/><path d="M65 62 H75 L70 76Z" fill="#fff3a0"/></g>',
  // 4. stad bij zonsondergang
  '<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4b2a8a"/><stop offset=".6" stop-color="#ff6f61"/><stop offset="1" stop-color="#ffc857"/></linearGradient></defs>'
  + '<rect width="160" height="90" fill="url(#s)"/><circle cx="80" cy="56" r="20" fill="#ffe27a"/>'
  + '<g fill="#1d1536"><rect x="6" y="46" width="20" height="44"/><rect x="28" y="34" width="16" height="56"/><rect x="46" y="52" width="22" height="38"/><rect x="92" y="40" width="18" height="50"/><rect x="112" y="28" width="16" height="62"/><rect x="130" y="50" width="26" height="40"/></g>'
  + '<g fill="#ffd54f"><rect x="10" y="52" width="3" height="3"/><rect x="17" y="60" width="3" height="3"/><rect x="32" y="42" width="3" height="3"/><rect x="36" y="56" width="3" height="3"/><rect x="52" y="60" width="3" height="3"/><rect x="96" y="48" width="3" height="3"/><rect x="102" y="60" width="3" height="3"/><rect x="116" y="36" width="3" height="3"/><rect x="120" y="50" width="3" height="3"/><rect x="136" y="58" width="3" height="3"/><rect x="146" y="66" width="3" height="3"/></g>',
  // 5. zeilboot
  '<rect width="160" height="90" fill="#8fd3ff"/><circle cx="30" cy="22" r="11" fill="#fff3a0"/><ellipse cx="116" cy="20" rx="18" ry="5" fill="#fff"/>'
  + '<rect y="56" width="160" height="34" fill="#1f78c8"/><path d="M0 62 Q10 57 20 62 T40 62 T60 62 T80 62 T100 62 T120 62 T140 62 T160 62" stroke="#a8dcff" stroke-width="2" fill="none"/>'
  + '<path d="M0 74 Q10 69 20 74 T40 74 T60 74 T80 74 T100 74 T120 74 T140 74 T160 74" stroke="#5fb0ee" stroke-width="2" fill="none"/>'
  + '<polygon points="82,12 82,50 52,50" fill="#fff"/><polygon points="86,20 86,50 112,50" fill="#ff6b6b"/><rect x="81" y="10" width="2" height="42" fill="#5a3b1c"/>'
  + '<path d="M44 52 H120 L110 64 H54Z" fill="#7a4a22"/>',
  // 6. bloem
  '<rect width="160" height="90" fill="#b8e6ff"/><rect y="70" width="160" height="20" fill="#5cb85c"/>'
  + '<rect x="78" y="42" width="4" height="40" fill="#2e8b3a"/><ellipse cx="68" cy="66" rx="10" ry="4" fill="#3da24a" transform="rotate(-25 68 66)"/>'
  + '<g fill="#ff7fb0"><circle cx="80" cy="22" r="11"/><circle cx="80" cy="50" r="11"/><circle cx="66" cy="36" r="11"/><circle cx="94" cy="36" r="11"/><circle cx="70" cy="26" r="9"/><circle cx="90" cy="26" r="9"/><circle cx="70" cy="46" r="9"/><circle cx="90" cy="46" r="9"/></g>'
  + '<circle cx="80" cy="36" r="9" fill="#ffd60a"/><circle cx="130" cy="20" r="9" fill="#ffe27a"/>'
  + '<g transform="translate(120 52)"><ellipse cx="0" cy="0" rx="6" ry="4.5" fill="#ffd60a"/><rect x="-3" y="-4" width="2" height="8" fill="#222"/><rect x="1" y="-4" width="2" height="8" fill="#222"/><ellipse cx="-3" cy="-6" rx="4" ry="2.5" fill="#fff" opacity=".8"/></g>',
  // 7. robot
  '<rect width="160" height="90" fill="#1f2a44"/><rect x="77" y="4" width="6" height="14" fill="#9aa8c7"/><circle cx="80" cy="6" r="5" fill="#ff5d73"/>'
  + '<rect x="40" y="18" width="80" height="60" rx="12" fill="#c9d4ea"/><rect x="48" y="26" width="64" height="30" rx="8" fill="#0d1526"/>'
  + '<circle cx="66" cy="41" r="9" fill="#38e1ff"/><circle cx="94" cy="41" r="9" fill="#38e1ff"/><circle cx="68" cy="39" r="3" fill="#fff"/><circle cx="96" cy="39" r="3" fill="#fff"/>'
  + '<path d="M62 66 Q80 76 98 66" stroke="#2c4a7a" stroke-width="3" fill="none" stroke-linecap="round"/>'
  + '<rect x="28" y="36" width="10" height="20" rx="4" fill="#9aa8c7"/><rect x="122" y="36" width="10" height="20" rx="4" fill="#9aa8c7"/>'
  + '<text x="80" y="87" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="9" font-weight="700" fill="#38e1ff">AI</text>'
];
const funScherp = [], funPixels = [];
let funKlaar = false, funScene = 0, funIter = 0;
function funToon(n) {
  funScene = n % FUN_TEKENINGEN.length;
  if (funScherp[funScene]) $('funSharp').src = funScherp[funScene];
  if (funPixels[funScene]) $('funPix').src = funPixels[funScene];
}
function funBouw() {
  if (funKlaar) return;
  funKlaar = true;
  // één keer: elke tekening als scherpe SVG en als blokkerige versie van 24x14 pixels (scherm toont die vergroot)
  FUN_TEKENINGEN.forEach((inhoud, n) => {
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 90">' + inhoud + '</svg>';
    const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    funScherp[n] = url;
    const img = new Image();
    img.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = 24; c.height = 14;
        const x = c.getContext('2d');
        x.imageSmoothingEnabled = true;
        x.drawImage(img, 0, 0, 24, 14);
        funPixels[n] = c.toDataURL();
        if (n === funScene) $('funPix').src = funPixels[n];
      } catch (e) { /* zonder blokkerige versie blijft alleen de scherpe tekening over */ }
    };
    img.src = url;
  });
  // na elke volledige heen-en-terug-beweging (scherpe versie weg) komt de volgende tekening
  document.querySelector('.fun-reveal').addEventListener('animationiteration', (e) => {
    if (e.target !== e.currentTarget) return;
    funIter++;
    if (funIter % 2 === 0) funToon(funScene + 1);
  });
  funToon(Math.floor(Math.random() * FUN_TEKENINGEN.length));
}
// Elke grappige tekst krijgt een andere kleur en een ander vrolijk lettertype (alleen lettertypen die al op Windows staan;
// ontbreekt er een, dan pakt het systeem het volgende in de rij).
const FUN_KLEUREN = ['#ffd60a', '#ff9f0a', '#ff6b8b', '#c77dff', '#64d2ff', '#30d158', '#ff7a59', '#5eead4'];
const FUN_LETTERS = [
  { f: '"Comic Sans MS", "Comic Neue", "Chalkboard SE", cursive', s: 17, w: 700 },
  { f: '"Ink Free", "Segoe Print", "Bradley Hand", cursive', s: 19, w: 700 },
  { f: '"Segoe Print", "Ink Free", cursive', s: 16, w: 700 },
  { f: '"Trebuchet MS", "Segoe UI", sans-serif', s: 17, w: 700, i: true },
  { f: '"Segoe Script", "Lucida Handwriting", cursive', s: 16, w: 600 },
  { f: '"Gabriola", "Palatino Linotype", Georgia, serif', s: 21, w: 700, i: true },
  { f: '"Candara", "Segoe UI", sans-serif', s: 18, w: 700 }
];
let funKleurNr = -1;
let funLetterNr = -1;
function funStijl(el) {
  // nooit twee keer achter elkaar dezelfde kleur of hetzelfde lettertype
  do { funKleurNr = Math.floor(Math.random() * FUN_KLEUREN.length); } while (FUN_KLEUREN[funKleurNr] === el.dataset.kleur);
  do { funLetterNr = Math.floor(Math.random() * FUN_LETTERS.length); } while (String(funLetterNr) === el.dataset.letter);
  const l = FUN_LETTERS[funLetterNr];
  el.dataset.kleur = FUN_KLEUREN[funKleurNr];
  el.dataset.letter = String(funLetterNr);
  el.style.color = FUN_KLEUREN[funKleurNr];
  el.style.fontFamily = l.f;
  el.style.fontSize = l.s + 'px';
  el.style.fontWeight = String(l.w);
  el.style.fontStyle = l.i ? 'italic' : 'normal';
}
function funTekst() {
  funNr = (funNr % FUN_AANTAL) + 1;
  const el = $('funText');
  funStijl(el);
  el.textContent = t('fun.' + funNr);
  el.style.animation = 'none'; void el.offsetHeight; el.style.animation = '';
}
function funStart() {
  funBouw();
  funNr = Math.floor(Math.random() * FUN_AANTAL);
  $('fun').classList.remove('hidden');
  funTekst();
  clearInterval(funTimer);
  funTimer = setInterval(funTekst, 6000);
}
function funStop() {
  clearInterval(funTimer);
  funTimer = null;
  $('fun').classList.add('hidden');
}
document.addEventListener('visibilitychange', () => document.body.classList.toggle('verborgen', document.hidden));

// ---------- meekijkend beeld ----------
let beeldModus = 'zicht';
try { const m = localStorage.getItem('upscaler4k.beeld'); if (['zicht', 'blur', 'uit'].includes(m)) beeldModus = m; } catch (e) { /* standaard */ }
function toonBeeldModus() {
  const live = $('live');
  live.classList.toggle('blur', beeldModus === 'blur');
  live.classList.toggle('uit', beeldModus === 'uit');
  document.querySelectorAll('#segBeeld .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === beeldModus));
  $('fun').classList.toggle('zonderscene', !live.classList.contains('hidden') && beeldModus !== 'uit'); // met beeld: geen aparte animatie eronder
  // 'Verbergen': de grappige animatie komt in hetzelfde kader te staan, zodat alles op dezelfde plek blijft
  const scene = document.querySelector('.fun-scene');
  if (beeldModus === 'uit' && !live.classList.contains('hidden')) { $('liveKader').appendChild(scene); $('liveKader').classList.add('metscene'); }
  else { $('liveKader').classList.remove('metscene'); if (scene.parentNode !== $('fun')) $('fun').insertBefore(scene, $('funText')); }
  $('liveNoot').textContent = beeldModus === 'uit' ? t('live.hidden') : t('live.note');
  $('liveLeeg').textContent = t('live.wait');
  if (beeldModus === 'uit') { $('liveImg').removeAttribute('src'); $('liveTijd').classList.add('hidden'); }
}
function beeldStart() {
  $('liveImg').removeAttribute('src');
  $('liveTijd').classList.add('hidden');
  $('live').classList.remove('hidden');
  $('dialoog').classList.add('breed');
  toonBeeldModus();
}
function beeldStop() {
  $('live').classList.add('hidden');
  $('dialoog').classList.remove('breed');
  $('liveImg').removeAttribute('src'); // het beeld niet laten staan als het klaar is
  $('fun').classList.remove('zonderscene');
  toonBeeldModus();
}
document.querySelectorAll('#segBeeld .btn').forEach((b) => b.addEventListener('click', () => {
  beeldModus = b.dataset.v;
  try { localStorage.setItem('upscaler4k.beeld', beeldModus); } catch (e) { /* negeren */ }
  window.api.zetBeeldModus(beeldModus);
  toonBeeldModus();
}));
window.api.op('voortgang-beeld', (d) => {
  if (!bezig || beeldModus === 'uit') return;
  $('liveImg').src = d.data;
  const tijd = $('liveTijd');
  tijd.textContent = fmtTijd(d.t) + (d.duur ? ' / ' + fmtTijd(d.duur) : '');
  tijd.classList.remove('hidden');
});

// ---------- dialoog ----------
function toonDialoog(titel, info, stand) {
  funStop();
  beeldStop();
  $('overlay').classList.remove('hidden');
  $('dlgTitle').textContent = titel;
  $('dlgInfo').textContent = info || '';
  $('barFill').className = stand || '';
  $('barFill').style.width = stand ? '100%' : '0%';
  $('btnCancel').classList.add('hidden');
  $('btnReveal').classList.toggle('hidden', stand !== 'ok' || bezigVoorbeeld);
  $('btnPlay').classList.toggle('hidden', stand !== 'ok' || !bezigVoorbeeld);
  $('btnClose').classList.remove('hidden');
}

// ---------- starten ----------
async function draai(voorbeeld) {
  if (!video || bezig) return;
  bezig = true;
  bezigVoorbeeld = voorbeeld;
  laatsteUit = null;
  taakStart = Date.now();
  totaalGeschat = 0;
  update();
  $('overlay').classList.remove('hidden');
  $('dlgTitle').textContent = voorbeeld ? t('dlg.prevTitle') : t('dlg.upTitle', { n: DOELEN[keuze.doel].naam });
  $('barFill').className = '';
  $('barFill').style.width = '0%';
  $('dlgInfo').textContent = t('dlg.starting');
  $('btnCancel').classList.remove('hidden');
  $('btnReveal').classList.add('hidden');
  $('btnPlay').classList.add('hidden');
  $('btnClose').classList.add('hidden');
  beeldStart();
  funStart();

  const opties = {
    pad: video.pad,
    doel: keuze.doel,
    methode: keuze.methode,
    modelType: ENGINES[keuze.soort].model,
    aiAandeel: waarden.aiAandeel,
    detail: waarden.detail,
    scherpte: waarden.scherpte,
    korrel: waarden.korrel,
    beeldModus,
    codec: keuze.codec,
    verscherpen: true
  };
  const r = voorbeeld ? await window.api.voorbeeld(opties) : await window.api.start(opties);

  bezig = false;
  if (r.ok && r.gedeeltelijk) {
    laatsteUit = r.uit;
    toonDialoog(t('dlg.partTitle'), t('dlg.partInfo', { a: fmtTijd(r.deelDuur), b: fmtTijd(video.duur), p: r.uit }), 'ok');
  } else if (r.ok) {
    laatsteUit = r.uit;
    if (voorbeeld) {
      // schatting voor de hele video op basis van de gemeten tijd van het voorbeeld
      const factor = r.fragmentDuur > 0 ? video.duur / r.fragmentDuur : 0;
      const schatting = factor > 1.5 ? t('dlg.prevEst', { d: fmtTijd(video.duur), e: fmtRest(r.seconden * factor) }) : '';
      toonDialoog(t('dlg.prevDone'), t('dlg.prevInfo', { t: fmtTijd(r.seconden), s: schatting }), 'ok');
    } else {
      toonDialoog(t('dlg.done'), t('dlg.doneInfo', { t: fmtTijd(r.seconden), p: r.uit }), 'ok');
    }
  } else if (r.fout === 'Geannuleerd') {
    toonDialoog(t('dlg.cancelled'), t('dlg.cancelledInfo'), 'fout');
  } else {
    toonDialoog(t('dlg.failed'), r.fout, 'fout');
  }
  update();
}

$('btnStart').addEventListener('click', () => draai(false));
$('btnPreview').addEventListener('click', () => draai(true));
$('btnPlay').addEventListener('click', () => { if (laatsteUit) window.api.open(laatsteUit); });

$('btnCancel').addEventListener('click', () => {
  $('dlgInfo').textContent = t('dlg.stopping');
  window.api.stop();
});
$('btnClose').addEventListener('click', () => $('overlay').classList.add('hidden'));
$('btnMapBoven').addEventListener('click', () => window.api.openResultaatMap(video ? video.pad : null));
$('btnMap').addEventListener('click', () => { if (video) window.api.openResultaatMap(video.pad); });
$('btnReveal').addEventListener('click', () => { if (laatsteUit) window.api.toon(laatsteUit); });

window.api.op('voortgang', (d) => {
  const f = d.fractie;
  $('barFill').style.width = Math.round(f * 100) + '%';
  let regel2 = '';
  if (bezig && taakStart && f < 1) {
    const verstreken = (Date.now() - taakStart) / 1000;
    if (f >= 0.005 && verstreken >= 8) {
      // totale duur schatten uit de voortgang tot nu toe, afgevlakt zodat het getal niet springt
      const nieuw = verstreken / f;
      totaalGeschat = totaalGeschat ? totaalGeschat * 0.8 + nieuw * 0.2 : nieuw;
      const rest = Math.max(0, totaalGeschat - verstreken);
      const klaar = new Date(Date.now() + rest * 1000).toLocaleTimeString(i18n.locale(), { hour: '2-digit', minute: '2-digit' });
      regel2 = t('dlg.left', { r: fmtRest(rest), k: klaar });
    } else {
      regel2 = t('dlg.calc');
    }
  }
  $('dlgInfo').textContent = `${Math.round(f * 100)}% · ${d.tekst}${regel2}`;
});

// ---------- opstart ----------
(async () => {
  toonVersies();
  inst = await window.api.instellingen();
  i18n.zetTaal(inst.taalActief);
  keuze.doel = inst.doel;
  const s = await window.api.status();
  aiAanwezig = s.ai;
  gpuInfo = s.gpu;
  bouwEngines();
  zetStandaard();
  update();
  toonVersies();
})();

/* ======================= Instellingen ======================= */

function toonInstellingen() {
  if (!inst) return;
  document.querySelectorAll('#setDoel .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === inst.doel));
  document.querySelectorAll('input[name="opslag"]').forEach((r) => { r.checked = r.value === inst.opslag; });
  $('dlPad').textContent = inst.downloadsMap ? '(' + inst.downloadsMap + ')' : '';
  $('mapPad').textContent = inst.opslag === 'map'
    ? (inst.opslagMap || t('set.dir.geen'))
    : (inst.opslagMap ? t('set.dir.gekozen', { p: inst.opslagMap }) : '');
  $('btnKiesMap').classList.toggle('hidden', inst.opslag !== 'map');
  $('btnOpenMap').classList.toggle('hidden', !(inst.opslag === 'map' && inst.opslagMap));
  $('autoUpdate').checked = !!inst.autoUpdate;
  document.querySelectorAll('#setTaal .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === i18n.taal()));
}
async function bewaar(deel) {
  inst = await window.api.bewaarInstellingen(deel);
  toonInstellingen();
  update();
}
// pagina: 'inst' (instellingen), 'info' (info en juridisch) of null (terug naar het hoofdscherm)
function toonPagina(naam) {
  const app = $('app');
  app.classList.remove('inst', 'info');
  $('settings').classList.add('hidden');
  $('info').classList.add('hidden');
  if (naam === 'inst') { app.classList.add('inst'); $('settings').classList.remove('hidden'); toonInstellingen(); toonVersies(); }
  if (naam === 'info') { app.classList.add('info'); $('info').classList.remove('hidden'); $('info').scrollTop = 0; toonVersies(); }
  update();
}
function huidigePagina() {
  return $('app').classList.contains('inst') ? 'inst' : ($('app').classList.contains('info') ? 'info' : null);
}
$('btnSettings').addEventListener('click', () => { if (bezig) return; toonPagina(huidigePagina() === 'inst' ? null : 'inst'); });
$('btnInfo').addEventListener('click', () => { if (bezig) return; toonPagina(huidigePagina() === 'info' ? null : 'info'); });
$('btnBack').addEventListener('click', () => toonPagina(null));
$('btnInfoTerug').addEventListener('click', () => toonPagina(null));
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && huidigePagina()) toonPagina(null); });

// links en licentiebestanden op de infopagina
document.querySelectorAll('#info [data-url]').forEach((b) => b.addEventListener('click', () => window.api.openUrl(b.dataset.url)));
document.querySelectorAll('#info [data-lic]').forEach((b) => b.addEventListener('click', () => window.api.openLicenties(b.dataset.lic)));

document.querySelectorAll('#setDoel .btn').forEach((b) => b.addEventListener('click', async () => {
  await bewaar({ doel: b.dataset.v });
  if (!bezig) { keuze.doel = b.dataset.v; update(); }
}));
document.querySelectorAll('input[name="opslag"]').forEach((r) => r.addEventListener('change', async () => {
  if (r.value === 'map' && !inst.opslagMap) {
    const p = await window.api.kiesMap();
    if (!p) { toonInstellingen(); return; }
    await bewaar({ opslag: 'map', opslagMap: p });
  } else {
    await bewaar({ opslag: r.value });
  }
}));
$('btnKiesMap').addEventListener('click', async () => {
  const p = await window.api.kiesMap();
  if (p) await bewaar({ opslag: 'map', opslagMap: p });
});
$('btnOpenMap').addEventListener('click', () => { if (inst && inst.opslagMap) window.api.openMap(inst.opslagMap); });
document.querySelectorAll('#setTaal .btn').forEach((b) => b.addEventListener('click', async () => {
  await bewaar({ taal: b.dataset.v });
  i18n.zetTaal(b.dataset.v);
  // dynamische teksten opnieuw opbouwen
  toonInstellingen();
  toonVersies();
  update();
}));
$('autoUpdate').addEventListener('change', () => bewaar({ autoUpdate: $('autoUpdate').checked }));

/* ======================= Updates ======================= */

const updBar = $('updateBar'), updText = $('updateText'), updAction = $('updAction');
let updHideTimer = null;

function toonBalk(tekst, actie, blijft) {
  clearTimeout(updHideTimer);
  updText.textContent = tekst;
  if (actie) {
    updAction.textContent = actie.label;
    updAction.onclick = actie.run;
    updAction.classList.remove('hidden');
  } else {
    updAction.classList.add('hidden');
  }
  updBar.classList.remove('hidden');
  if (!blijft) updHideTimer = setTimeout(() => updBar.classList.add('hidden'), 10000);
}
$('updClose').addEventListener('click', () => updBar.classList.add('hidden'));

async function toonVersies() {
  try {
    const v = await window.api.versions();
    $('buildBadge').textContent = 'V.' + v.app;
    $('versieInfo').textContent = t('ver', { s: v.shell, a: v.app, f: v.ffmpeg === 'ingebouwd' ? t('ver.bundled') : v.ffmpeg });
    $('infoVersie').textContent = t('info.version', { s: v.shell, a: v.app });
  } catch (e) { /* negeren */ }
}

// blauw bolletje bij Instellingen en Nu controleren als er een update klaarstaat
let wachtOpHerstart = null;
// foutmeldingen van de updater (vast onderdeel, alleen Nederlands) vertalen
function vertaalUpdateFout(e) {
  const m = /updateserver gaf een fout \((\d+)\)/.exec(e);
  if (m) return t('upd.e.server', { c: m[1] });
  if (/Geen verbinding met de updateserver/.test(e)) return t('upd.e.conn');
  return e;
}
function zetUpdateBolletje(aan, titel) {
  wachtOpHerstart = aan ? titel : null;
  for (const id of ['btnSettings', 'btnUpdate']) {
    $(id).classList.toggle('melding', aan);
  }
}

window.api.op('update-event', (ev) => {
  if (ev.bijgewerkt) {
    const tekst = t('upd.done', { v: ev.bijgewerkt });
    toonBalk('✓ ' + tekst, null, false);
    $('updStatus').textContent = tekst;
    toonVersies();
    return;
  }
  const herstart = ev.installed.find((i) => i.restart);
  let status;
  if (herstart) {
    zetUpdateBolletje(true, t('upd.ready.tip', { v: herstart.version }));
    status = t('upd.dled', { v: herstart.version });
    toonBalk(t('upd.dled.bar', { v: herstart.version }), {
      label: t('upd.restart'),
      run: async () => {
        const ok = await window.api.restartNow();
        if (ok === false) alert(t('upd.wait'));
      }
    }, true);
  } else if (ev.installed.length) {
    status = t('upd.ff', { v: ev.installed[0].version });
    toonBalk(status, null, false);
  } else if (ev.shell) {
    zetUpdateBolletje(true, t('upd.shell.tip'));
    status = t('upd.shell', { v: ev.shell.version });
    toonBalk(status, { label: t('upd.download'), run: () => window.api.openUrl(ev.shell.url) }, true);
  } else if (ev.manual) {
    status = ev.error ? t('upd.fail', { e: vertaalUpdateFout(ev.error) })
      : (wachtOpHerstart || t('upd.latest'));
    toonBalk(status, null, false);
  }
  if (status) $('updStatus').textContent = status;
  toonVersies();
});

$('btnUpdate').addEventListener('click', () => {
  $('updStatus').textContent = t('upd.checking');
  window.api.checkUpdates();
});

$('btnLog').addEventListener('click', () => window.api.openLogboek());
