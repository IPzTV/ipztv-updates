const $ = (id) => document.getElementById(id);
const DOELEN = {
  '1080': { b: 1920, h: 1080, naam: 'Full HD', bestand: 'FullHD', uitleg: 'Past op elke tv en telefoon. Kleinste bestand en snelst klaar.' },
  '1440': { b: 2560, h: 1440, naam: '2K', bestand: '2K', uitleg: 'Scherper dan Full HD, bestand blijft redelijk klein.' },
  '2160': { b: 3840, h: 2160, naam: '4K', bestand: '4K', uitleg: 'Hoogste resolutie, voor een 4K-tv. Groot bestand en duurt het langst.' }
};

let video = null;
let bezig = false;
let aiAanwezig = false;
let gpuInfo = null;
let installeert = false;
let laatsteUit = null;
let bezigVoorbeeld = false;
let inst = null; // opgeslagen instellingen
let taakStart = 0;
let totaalGeschat = 0;
const keuze = { doel: '2160', methode: 'ai', soort: 'echt', codec: 'hevc' };

// ---------- hulpjes ----------
function fmtTijd(s) {
  s = Math.round(s);
  const u = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
  return (u ? u + ':' + String(m).padStart(2, '0') : m) + ':' + String(r).padStart(2, '0');
}
function fmtRest(s) {
  s = Math.max(0, Math.round(s));
  if (s < 10) return 'minder dan 10 seconden';
  if (s < 60) return Math.round(s / 5) * 5 + ' seconden';
  const m = Math.round(s / 60);
  if (m < 60) return m + (m === 1 ? ' minuut' : ' minuten');
  const u = Math.floor(m / 60), r = m % 60;
  return u + ' uur' + (r ? ' ' + r + ' min' : '');
}
function opslagTekst() {
  if (inst && inst.opslag === 'downloads') return 'in je Downloads-map';
  if (inst && inst.opslag === 'map' && inst.opslagMap) {
    const naam = inst.opslagMap.split(/[\\/]/).filter(Boolean).pop() || inst.opslagMap;
    return `in de map “${naam}”`;
  }
  return 'naast het origineel';
}
function even(n) { return Math.round(n / 2) * 2; }
function doelAfmeting(v) {
  const t = DOELEN[keuze.doel];
  const f = Math.min(t.b / v.breedte, t.h / v.hoogte);
  return { b: even(v.breedte * f), h: even(v.hoogte * f) };
}
function gpuOk() { return !!(gpuInfo && gpuInfo.gekozen); }

// ---------- scherm bijwerken ----------
function update() {
  const heeft = !!video;
  $('empty').classList.toggle('hidden', heeft);
  $('summary').classList.toggle('hidden', !heeft);
  $('bottom').classList.toggle('hidden', !heeft);
  $('fileName').textContent = heeft ? video.naam : '';

  // videokaart bovenin
  if (gpuOk()) $('gpuLabel').textContent = 'Videokaart: ' + gpuInfo.gekozen.naam;
  else if (gpuInfo && gpuInfo.windows && gpuInfo.windows.length) $('gpuLabel').textContent = 'Videokaart: ' + gpuInfo.windows.join(', ');
  else $('gpuLabel').textContent = '';

  if (!heeft) return;

  // samenvatting
  const t = DOELEN[keuze.doel];
  const al4k = video.hoogte >= t.h; // video is al even groot als het doel
  const d = doelAfmeting(video);
  $('resFrom').textContent = `${video.breedte}×${video.hoogte}`;
  $('resTo').textContent = `${d.b}×${d.h}`;
  $('resLabel').textContent = t.naam;
  $('meta').textContent = `${fmtTijd(video.duur)} · ${video.fps} beelden per seconde`;
  let advies;
  if (al4k) advies = `Deze video is al ${t.naam} of groter. Kies een hogere resolutie.`;
  else if (video.hoogte <= 480) advies = 'Erg lage resolutie: de AI-methode maakt hier het grootste verschil.';
  else if (video.hoogte <= 720) advies = 'Aanbevolen: Beste kwaliteit (AI).';
  else advies = 'Dit is al redelijk scherp: Snel is meestal genoeg, AI voegt wat extra detail toe.';
  $('advice').textContent = advies;

  // knoppen
  const ai = keuze.methode === 'ai';
  document.querySelectorAll('#segDoel .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.doel));
  document.querySelectorAll('#segMethode .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.methode));
  document.querySelectorAll('#segSoort .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.soort));
  document.querySelectorAll('#segCodec .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === keuze.codec));

  $('colSoort').classList.toggle('hidden', !ai);
  $('nrBestand').textContent = ai ? '4' : '3';
  $('descDoel').textContent = t.uitleg;

  $('descMethode').textContent = ai
    ? 'Een AI bouwt de details opnieuw op met je videokaart. Mooiste resultaat, maar duurt een stuk langer dan de video zelf.'
    : 'Vergroot het beeld met een nette ffmpeg-filter. Binnen enkele minuten klaar, maar zonder extra detail.';
  $('descSoort').textContent = keuze.soort === 'echt'
    ? 'Film, camerabeelden, schermopnames. Meer detail, maar trager.'
    : 'Tekenfilm, anime, game-beelden met egale vlakken. Sneller.';
  $('descCodec').textContent = keuze.codec === 'hevc'
    ? 'H.265: ongeveer de helft kleiner. Nodig voor 4K op de meeste tv’s.'
    : 'H.264: speelt op vrijwel alles, maar het bestand wordt groter.';

  // AI-engine / videokaart-melding
  const setup = $('setup');
  setup.classList.remove('warn');
  $('btnInstall').classList.add('hidden');
  let klaar = true;
  if (ai && !aiAanwezig) {
    klaar = false;
    setup.classList.remove('hidden');
    $('setupText').textContent = installeert ? 'AI-engine wordt gedownload…' : 'Voor de AI-methode is eenmalig een extra onderdeel nodig.';
    if (!installeert) $('btnInstall').classList.remove('hidden');
  } else if (ai && !gpuOk()) {
    klaar = false;
    setup.classList.remove('hidden');
    setup.classList.add('warn');
    $('setupText').textContent = 'Geen videokaart met Vulkan-ondersteuning gevonden. Werk het stuurprogramma van je videokaart bij of kies Snel.';
  } else {
    setup.classList.add('hidden');
  }

  $('btnStart').disabled = !(klaar && !al4k && !bezig);
  $('btnPreview').disabled = !(klaar && !al4k && !bezig);
  $('startHint').textContent = al4k ? '' : `Tip: kijk eerst een voorbeeld van 10 seconden. Resultaat: ${d.b}×${d.h}, als “… _${t.bestand}.mp4” ${opslagTekst()}.`;
}

// ---------- video laden ----------
async function laadVideo(pad) {
  const r = await window.api.info(pad);
  if (!r.ok) { toonDialoog('Kan video niet openen', r.fout, 'fout'); return; }
  video = r.info;
  // slimme standaardkeuze
  keuze.methode = (aiAanwezig && gpuOk()) ? 'ai' : 'snel';
  update();
}
async function kiesBestand() {
  if (bezig) return;
  const p = await window.api.kiesBestand();
  if (p) laadVideo(p);
}
function nieuw() {
  if (bezig) return;
  video = null;
  update();
}

$('btnNew').addEventListener('click', () => { nieuw(); kiesBestand(); });
window.addEventListener('keydown', (e) => {
  if (!e.ctrlKey) return;
  const k = e.key.toLowerCase();
  if (k === 'o') { e.preventDefault(); kiesBestand(); }
  if (k === 'n') { e.preventDefault(); nieuw(); kiesBestand(); }
});

// slepen
const stage = $('stage');
window.addEventListener('dragover', (e) => { e.preventDefault(); if (!bezig) stage.classList.add('drag'); });
window.addEventListener('dragleave', (e) => { if (e.target === document.documentElement || !e.relatedTarget) stage.classList.remove('drag'); });
window.addEventListener('drop', (e) => {
  e.preventDefault();
  stage.classList.remove('drag');
  if (bezig) return;
  const f = e.dataTransfer.files[0];
  if (f) laadVideo(window.api.pathForFile(f));
});

// ---------- keuzes ----------
function koppelSeg(id, sleutel) {
  document.querySelectorAll(`#${id} .btn`).forEach((b) => b.addEventListener('click', () => {
    keuze[sleutel] = b.dataset.v;
    update();
  }));
}
koppelSeg('segDoel', 'doel');
koppelSeg('segMethode', 'methode');
koppelSeg('segSoort', 'soort');
koppelSeg('segCodec', 'codec');

// ---------- AI installeren ----------
$('btnInstall').addEventListener('click', async () => {
  installeert = true;
  update();
  const r = await window.api.installeerAi();
  installeert = false;
  if (r.ok) {
    aiAanwezig = true;
    $('setupText').textContent = 'Videokaart controleren…';
    const s = await window.api.status();
    gpuInfo = s.gpu;
  } else {
    toonDialoog('Downloaden mislukt', r.fout, 'fout');
  }
  update();
});
window.api.op('ai-installatie', (d) => {
  $('setupText').textContent = d.fase === 'download'
    ? `AI-engine downloaden… ${Math.round(d.fractie * 100)}%` : 'AI-engine uitpakken…';
});

// ---------- dialoog ----------
function toonDialoog(titel, info, stand) {
  $('overlay').classList.remove('hidden');
  $('dlgTitle').textContent = titel;
  $('dlgInfo').textContent = info || '';
  $('barFill').className = stand || '';
  $('barFill').style.width = stand ? '100%' : '0%';
  $('btnCancel').classList.add('hidden');
  $('btnReveal').classList.toggle('hidden', stand !== 'ok' || bezigVoorbeeld);
  $('btnPlay').classList.toggle('hidden', stand !== 'ok' || !bezigVoorbeeld);
  $('btnClose').classList.remove('hidden');
}

// ---------- starten ----------
async function draai(voorbeeld) {
  if (!video || bezig) return;
  bezig = true;
  bezigVoorbeeld = voorbeeld;
  laatsteUit = null;
  taakStart = Date.now();
  totaalGeschat = 0;
  update();
  $('overlay').classList.remove('hidden');
  $('dlgTitle').textContent = voorbeeld ? 'Voorbeeld maken (10 seconden)…' : `Opschalen naar ${DOELEN[keuze.doel].naam}…`;
  $('barFill').className = '';
  $('barFill').style.width = '0%';
  $('dlgInfo').textContent = 'Starten…';
  $('btnCancel').classList.remove('hidden');
  $('btnReveal').classList.add('hidden');
  $('btnPlay').classList.add('hidden');
  $('btnClose').classList.add('hidden');

  const opties = {
    pad: video.pad,
    doel: keuze.doel,
    methode: keuze.methode,
    modelType: keuze.soort === 'echt' ? 'realistisch' : 'algemeen',
    codec: keuze.codec,
    verscherpen: true
  };
  const r = voorbeeld ? await window.api.voorbeeld(opties) : await window.api.start(opties);

  bezig = false;
  if (r.ok && r.gedeeltelijk) {
    laatsteUit = r.uit;
    toonDialoog('Afgebroken: gedeelte bewaard', `Het deel dat al klaar was (ongeveer ${fmtTijd(r.deelDuur)} van ${fmtTijd(video.duur)}) is bewaard in:\n${r.uit}`, 'ok');
  } else if (r.ok) {
    laatsteUit = r.uit;
    if (voorbeeld) {
      // schatting voor de hele video op basis van de gemeten tijd van het voorbeeld
      const factor = r.fragmentDuur > 0 ? video.duur / r.fragmentDuur : 0;
      const schatting = factor > 1.5 ? `\nDe hele video (${fmtTijd(video.duur)}) duurt dan naar schatting ongeveer ${fmtRest(r.seconden * factor)}.` : '';
      toonDialoog('Voorbeeld klaar', `Gemaakt in ${fmtTijd(r.seconden)}. Speel het af en kijk of je tevreden bent.${schatting}\nZo niet: pas de keuzes aan en maak een nieuw voorbeeld.`, 'ok');
    } else {
      toonDialoog('Klaar', `Klaar in ${fmtTijd(r.seconden)}.\n${r.uit}`, 'ok');
    }
  } else if (r.fout === 'Geannuleerd') {
    toonDialoog('Afgebroken', 'Er was nog niets klaar om te bewaren. In de opslagmap staat dus geen nieuw bestand.', 'fout');
  } else {
    toonDialoog('Mislukt', r.fout, 'fout');
  }
  update();
}

$('btnStart').addEventListener('click', () => draai(false));
$('btnPreview').addEventListener('click', () => draai(true));
$('btnPlay').addEventListener('click', () => { if (laatsteUit) window.api.open(laatsteUit); });

$('btnCancel').addEventListener('click', () => {
  $('dlgInfo').textContent = 'Stoppen… wat al klaar is wordt bewaard.';
  window.api.stop();
});
$('btnClose').addEventListener('click', () => $('overlay').classList.add('hidden'));
$('btnMap').addEventListener('click', () => { if (video) window.api.openResultaatMap(video.pad); });
$('btnReveal').addEventListener('click', () => { if (laatsteUit) window.api.toon(laatsteUit); });

window.api.op('voortgang', (d) => {
  const f = d.fractie;
  $('barFill').style.width = Math.round(f * 100) + '%';
  let regel2 = '';
  if (bezig && taakStart && f < 1) {
    const verstreken = (Date.now() - taakStart) / 1000;
    if (f >= 0.005 && verstreken >= 8) {
      // totale duur schatten uit de voortgang tot nu toe, afgevlakt zodat het getal niet springt
      const nieuw = verstreken / f;
      totaalGeschat = totaalGeschat ? totaalGeschat * 0.8 + nieuw * 0.2 : nieuw;
      const rest = Math.max(0, totaalGeschat - verstreken);
      const klaar = new Date(Date.now() + rest * 1000).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
      regel2 = `\nNog ongeveer ${fmtRest(rest)} (klaar rond ${klaar})`;
    } else {
      regel2 = '\nResterende tijd wordt berekend…';
    }
  }
  $('dlgInfo').textContent = `${Math.round(f * 100)}% · ${d.tekst}${regel2}`;
});

// ---------- opstart ----------
(async () => {
  toonVersies();
  inst = await window.api.instellingen();
  keuze.doel = inst.doel;
  const s = await window.api.status();
  aiAanwezig = s.ai;
  gpuInfo = s.gpu;
  keuze.methode = (aiAanwezig && gpuOk()) ? 'ai' : 'snel';
  update();
  toonVersies();
})();

/* ======================= Instellingen ======================= */

function toonInstellingen() {
  if (!inst) return;
  document.querySelectorAll('#setDoel .btn').forEach((b) => b.classList.toggle('on', b.dataset.v === inst.doel));
  document.querySelectorAll('input[name="opslag"]').forEach((r) => { r.checked = r.value === inst.opslag; });
  $('dlPad').textContent = inst.downloadsMap ? '(' + inst.downloadsMap + ')' : '';
  $('mapPad').textContent = inst.opslag === 'map'
    ? (inst.opslagMap || 'Nog geen map gekozen')
    : (inst.opslagMap ? 'Gekozen map: ' + inst.opslagMap : '');
  $('btnKiesMap').classList.toggle('hidden', inst.opslag !== 'map');
  $('btnOpenMap').classList.toggle('hidden', !(inst.opslag === 'map' && inst.opslagMap));
  $('autoUpdate').checked = !!inst.autoUpdate;
}
async function bewaar(deel) {
  inst = await window.api.bewaarInstellingen(deel);
  toonInstellingen();
  update();
}
// pagina: 'inst' (instellingen), 'info' (info en juridisch) of null (terug naar het hoofdscherm)
function toonPagina(naam) {
  const app = $('app');
  app.classList.remove('inst', 'info');
  $('settings').classList.add('hidden');
  $('info').classList.add('hidden');
  if (naam === 'inst') { app.classList.add('inst'); $('settings').classList.remove('hidden'); toonInstellingen(); toonVersies(); }
  if (naam === 'info') { app.classList.add('info'); $('info').classList.remove('hidden'); $('info').scrollTop = 0; toonVersies(); }
  update();
}
function huidigePagina() {
  return $('app').classList.contains('inst') ? 'inst' : ($('app').classList.contains('info') ? 'info' : null);
}
$('btnSettings').addEventListener('click', () => { if (bezig) return; toonPagina(huidigePagina() === 'inst' ? null : 'inst'); });
$('btnInfo').addEventListener('click', () => { if (bezig) return; toonPagina(huidigePagina() === 'info' ? null : 'info'); });
$('btnBack').addEventListener('click', () => toonPagina(null));
$('btnInfoTerug').addEventListener('click', () => toonPagina(null));
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' && huidigePagina()) toonPagina(null); });

// links en licentiebestanden op de infopagina
document.querySelectorAll('#info [data-url]').forEach((b) => b.addEventListener('click', () => window.api.openUrl(b.dataset.url)));
document.querySelectorAll('#info [data-lic]').forEach((b) => b.addEventListener('click', () => window.api.openLicenties(b.dataset.lic)));

document.querySelectorAll('#setDoel .btn').forEach((b) => b.addEventListener('click', async () => {
  await bewaar({ doel: b.dataset.v });
  if (!bezig) { keuze.doel = b.dataset.v; update(); }
}));
document.querySelectorAll('input[name="opslag"]').forEach((r) => r.addEventListener('change', async () => {
  if (r.value === 'map' && !inst.opslagMap) {
    const p = await window.api.kiesMap();
    if (!p) { toonInstellingen(); return; }
    await bewaar({ opslag: 'map', opslagMap: p });
  } else {
    await bewaar({ opslag: r.value });
  }
}));
$('btnKiesMap').addEventListener('click', async () => {
  const p = await window.api.kiesMap();
  if (p) await bewaar({ opslag: 'map', opslagMap: p });
});
$('btnOpenMap').addEventListener('click', () => { if (inst && inst.opslagMap) window.api.openMap(inst.opslagMap); });
$('autoUpdate').addEventListener('change', () => bewaar({ autoUpdate: $('autoUpdate').checked }));

/* ======================= Updates ======================= */

const updBar = $('updateBar'), updText = $('updateText'), updAction = $('updAction');
let updHideTimer = null;

function toonBalk(tekst, actie, blijft) {
  clearTimeout(updHideTimer);
  updText.textContent = tekst;
  if (actie) {
    updAction.textContent = actie.label;
    updAction.onclick = actie.run;
    updAction.classList.remove('hidden');
  } else {
    updAction.classList.add('hidden');
  }
  updBar.classList.remove('hidden');
  if (!blijft) updHideTimer = setTimeout(() => updBar.classList.add('hidden'), 10000);
}
$('updClose').addEventListener('click', () => updBar.classList.add('hidden'));

async function toonVersies() {
  try {
    const v = await window.api.versions();
    $('buildBadge').textContent = 'V.' + v.app;
    $('buildBadge').title = `Buildnummer ${v.app} (programma ${v.shell})`;
    $('versieInfo').textContent = `Programma ${v.shell} · onderdelen ${v.app} · videoverwerking (ffmpeg) ${v.ffmpeg}`;
    $('infoVersie').textContent = `Versie ${v.shell} (onderdelen ${v.app})`;
  } catch (e) { /* negeren */ }
}

// blauw bolletje bij Instellingen en Nu controleren als er een update klaarstaat
let wachtOpHerstart = null;
function zetUpdateBolletje(aan, titel) {
  wachtOpHerstart = aan ? titel : null;
  for (const id of ['btnSettings', 'btnUpdate']) {
    $(id).classList.toggle('melding', aan);
  }
  $('btnSettings').title = aan ? titel : 'Instellingen';
}

window.api.op('update-event', (ev) => {
  if (ev.bijgewerkt) {
    const tekst = 'Upscaler4K is bijgewerkt naar V.' + ev.bijgewerkt + '.';
    toonBalk('✓ ' + tekst, null, false);
    $('updStatus').textContent = tekst;
    toonVersies();
    return;
  }
  const herstart = ev.installed.find((i) => i.restart);
  let status;
  if (herstart) {
    zetUpdateBolletje(true, 'Er staat een update klaar (' + herstart.version + '). Herstart om te vernieuwen.');
    status = 'Update ' + herstart.version + ' is gedownload.';
    toonBalk('Update ' + herstart.version + ' is gedownload. Herstart Upscaler4K om te vernieuwen.', {
      label: 'Nu herstarten',
      run: async () => {
        const ok = await window.api.restartNow();
        if (ok === false) alert('Wacht tot het opschalen klaar is en probeer het dan opnieuw.');
      }
    }, true);
  } else if (ev.installed.length) {
    status = 'Videoverwerking (ffmpeg) is bijgewerkt naar ' + ev.installed[0].version + '.';
    toonBalk(status, null, false);
  } else if (ev.shell) {
    zetUpdateBolletje(true, 'Er is een nieuwe programmaversie beschikbaar.');
    status = 'Nieuwe programmaversie ' + ev.shell.version + ' is beschikbaar.';
    toonBalk(status, { label: 'Downloaden', run: () => window.api.openUrl(ev.shell.url) }, true);
  } else if (ev.manual) {
    status = ev.error ? 'Updates controleren mislukt: ' + ev.error
      : (wachtOpHerstart || 'Je gebruikt de nieuwste versie.');
    toonBalk(status, null, false);
  }
  if (status) $('updStatus').textContent = status;
  toonVersies();
});

$('btnUpdate').addEventListener('click', () => {
  $('updStatus').textContent = 'Controleren op updates…';
  window.api.checkUpdates();
});

$('btnLog').addEventListener('click', () => window.api.openLogboek());
