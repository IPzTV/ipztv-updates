const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  pathForFile: (file) => webUtils.getPathForFile(file),
  kiesBestand: () => ipcRenderer.invoke('kies-bestand'),
  info: (pad) => ipcRenderer.invoke('video-info', pad),
  status: () => ipcRenderer.invoke('engine-status'),
  installeerAi: () => ipcRenderer.invoke('installeer-ai'),
  start: (opties) => ipcRenderer.invoke('start-upscale', opties),
  voorbeeld: (opties) => ipcRenderer.invoke('start-voorbeeld', opties),
  open: (pad) => ipcRenderer.invoke('open-bestand', pad),
  stop: () => ipcRenderer.invoke('stop-upscale'),
  instellingen: () => ipcRenderer.invoke('instellingen-get'),
  bewaarInstellingen: (deel) => ipcRenderer.invoke('instellingen-set', deel),
  kiesMap: () => ipcRenderer.invoke('kies-map'),
  openResultaatMap: (invoer) => ipcRenderer.invoke('open-resultaatmap', invoer),
  openMap: (pad) => ipcRenderer.invoke('open-map', pad),
  openLogboek: () => ipcRenderer.invoke('open-logboek'),
  openLicenties: (welke) => ipcRenderer.invoke('open-licenties', welke),
  versions: () => ipcRenderer.invoke('versions'),
  checkUpdates: () => ipcRenderer.invoke('update-check'),
  restartNow: () => ipcRenderer.invoke('update-restart'),
  openUrl: (u) => ipcRenderer.invoke('open-url', u),
  toon: (pad) => ipcRenderer.invoke('toon-in-map', pad),
  op: (kanaal, fn) => {
    const h = (_e, data) => fn(data);
    ipcRenderer.on(kanaal, h);
    return () => ipcRenderer.removeListener(kanaal, h);
  }
});
