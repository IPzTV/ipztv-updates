'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  init: () => ipcRenderer.invoke('init'),
  browser: () => ipcRenderer.invoke('browser'),
  checkUpdate: () => ipcRenderer.invoke('checkUpdate'),
  restart: () => ipcRenderer.invoke('restart'),
  analyze: (o) => ipcRenderer.invoke('analyze', o),
  download: (o) => ipcRenderer.invoke('download', o),
  cancel: (id) => ipcRenderer.invoke('cancel', id),
  stopLive: (id) => ipcRenderer.invoke('stopLive', id),
  pickDir: () => ipcRenderer.invoke('pickDir'),
  openDir: (d) => ipcRenderer.invoke('openDir', d),
  showFile: (f) => ipcRenderer.invoke('showFile', f),
  on: (cb) => ipcRenderer.on('evt', (_e, m) => cb(m)),
});
