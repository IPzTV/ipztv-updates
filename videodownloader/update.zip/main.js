'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');

if (!app.requestSingleInstanceLock()) app.quit();

const BIN = path.join(app.getPath('userData'), 'bin');
const YTDLP = path.join(BIN, 'yt-dlp.exe');
const FFMPEG = path.join(BIN, 'ffmpeg.exe');
const STAMP = path.join(BIN, 'last-update.txt');
const SETTINGS = path.join(app.getPath('userData'), 'settings.json');
const YTDLP_URL = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe';
const FFMPEG_URL = 'https://github.com/yt-dlp/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip';
const TMP_PREFIX = 'VideoDownloader-';
const COOKIE_BROWSERS = new Set(['chrome', 'edge', 'firefox', 'brave', 'opera', 'vivaldi']);
// Electron zelf als "node" laten dienen voor yt-dlp (nodig voor o.a. YouTube-handtekeningen)
const ENV = { ...process.env, ELECTRON_RUN_AS_NODE: '1', PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' };

let win = null;
const jobs = new Map(); // lopende downloads: jobId -> { procs: Set, cancelled }

const send = (m) => { if (win && !win.isDestroyed()) win.webContents.send('evt', m); };
const isDir = (p) => { try { return fs.statSync(p).isDirectory(); } catch { return false; } };
const rmrf = (p) => { try { fs.rmSync(p, { recursive: true, force: true }); } catch { /* negeren */ } };

function readSettings() { try { return JSON.parse(fs.readFileSync(SETTINGS, 'utf8')); } catch { return {}; } }
function saveSettings(s) { try { fs.mkdirSync(path.dirname(SETTINGS), { recursive: true }); fs.writeFileSync(SETTINGS, JSON.stringify(s)); } catch { /* negeren */ } }

function purgeStaleTemp() {
  try {
    for (const n of fs.readdirSync(os.tmpdir())) if (n.startsWith(TMP_PREFIX)) rmrf(path.join(os.tmpdir(), n));
  } catch { /* negeren */ }
}

function killJob(job) {
  for (const p of job.procs) {
    if (p && p.pid) {
      try { spawn('taskkill', ['/pid', String(p.pid), '/T', '/F'], { windowsHide: true }); } catch { /* negeren */ }
    }
  }
}

// ---------- hulpprogramma's ophalen (eenmalig) ----------
function download(url, dest, onProgress) {
  return new Promise((resolve, reject) => {
    const get = (u, hops) => {
      if (hops > 8) return reject(new Error('Te veel doorverwijzingen'));
      https.get(u, { headers: { 'User-Agent': 'VideoDownloader' } }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
          res.resume();
          return get(new URL(res.headers.location, u).toString(), hops + 1);
        }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('Download mislukt (HTTP ' + res.statusCode + ')')); }
        const total = +res.headers['content-length'] || 0;
        let got = 0;
        const tmp = dest + '.part';
        const f = fs.createWriteStream(tmp);
        res.on('data', (c) => { got += c.length; if (total && onProgress) onProgress(got / total); });
        res.pipe(f);
        f.on('finish', () => f.close(() => { try { fs.renameSync(tmp, dest); resolve(); } catch (e) { reject(e); } }));
        f.on('error', (e) => { rmrf(tmp); reject(e); });
        res.on('error', (e) => { rmrf(tmp); reject(e); });
      }).on('error', reject);
    };
    get(url, 0);
  });
}

function runSimple(cmd, args, timeout) {
  return new Promise((resolve) => {
    let p;
    try { p = spawn(cmd, args, { windowsHide: true, env: ENV }); } catch { return resolve(-1); }
    const t = timeout ? setTimeout(() => { try { p.kill(); } catch { /* negeren */ } }, timeout) : null;
    p.on('error', () => { if (t) clearTimeout(t); resolve(-1); });
    p.on('close', (c) => { if (t) clearTimeout(t); resolve(c); });
    p.stdout.resume(); p.stderr.resume();
  });
}

async function installFfmpeg() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), TMP_PREFIX + 'ff-'));
  try {
    const zip = path.join(tmp, 'ff.zip');
    await download(FFMPEG_URL, zip, (p) => send({ t: 'setup', text: 'ffmpeg downloaden (eenmalig)…', pct: p }));
    send({ t: 'setup', text: 'ffmpeg uitpakken…' });
    const code = await runSimple('tar', ['-xf', zip, '-C', tmp], 180000);
    if (code !== 0) throw new Error('Uitpakken van ffmpeg is mislukt');
    let found = null;
    for (const d of fs.readdirSync(tmp)) {
      const c = path.join(tmp, d, 'bin', 'ffmpeg.exe');
      if (fs.existsSync(c)) { found = c; break; }
    }
    if (!found) throw new Error('ffmpeg.exe niet gevonden in download');
    fs.copyFileSync(found, FFMPEG);
  } finally {
    rmrf(tmp);
  }
}

async function ensureTools() {
  fs.mkdirSync(BIN, { recursive: true });
  if (!fs.existsSync(YTDLP)) {
    await download(YTDLP_URL, YTDLP, (p) => send({ t: 'setup', text: 'yt-dlp downloaden (eenmalig)…', pct: p }));
  } else {
    let last = 0;
    try { last = +fs.readFileSync(STAMP, 'utf8') || 0; } catch { /* negeren */ }
    if (Date.now() - last > 2 * 24 * 3600 * 1000) {
      send({ t: 'setup', text: 'yt-dlp bijwerken…' });
      await runSimple(YTDLP, ['-U'], 60000);
      try { fs.writeFileSync(STAMP, String(Date.now())); } catch { /* negeren */ }
    }
  }
  if (!fs.existsSync(FFMPEG)) await installFfmpeg();
}

// ---------- yt-dlp aanroepen ----------
function baseArgs(cookies, referer) {
  const a = ['--ignore-config', '--no-cache-dir', '--no-warnings', '--js-runtimes', 'node:' + process.execPath];
  if (COOKIE_BROWSERS.has(cookies)) a.push('--cookies-from-browser', cookies);
  if (referer) { try { a.push('--referer', cleanUrl(referer)); } catch { /* negeren */ } }
  return a;
}

function cleanUrl(u) {
  let s = String(u || '').trim();
  if (!s) throw new Error('Geen link ingevuld');
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = 'https://' + s;
  const x = new URL(s);
  if (x.protocol !== 'http:' && x.protocol !== 'https:') throw new Error('Alleen http(s)-links worden ondersteund');
  return x.href;
}

function lastError(stderr) {
  const lines = String(stderr).split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const errs = lines.filter((l) => l.startsWith('ERROR:'));
  let m = (errs.length ? errs[errs.length - 1] : lines[lines.length - 1] || 'Onbekende fout').replace(/^ERROR:\s*/, '');
  if (/drm/i.test(m)) m = 'Deze video is DRM-beveiligd en kan niet worden gedownload. (' + m + ')';
  return m;
}

function capture(args) {
  return new Promise((resolve, reject) => {
    const p = spawn(YTDLP, args, { windowsHide: true, env: ENV }); // niet in `current`: analyseren mag een lopende download niet raken
    let o = '', e = '';
    p.stdout.setEncoding('utf8'); p.stderr.setEncoding('utf8');
    p.stdout.on('data', (d) => { o += d; });
    p.stderr.on('data', (d) => { e += d; });
    p.on('error', reject);
    p.on('close', (c) => { c === 0 ? resolve(o) : reject(new Error(lastError(e))); });
  });
}

const num = (v) => (typeof v === 'number' && isFinite(v) ? v : null);

const MIN_HEIGHT = 720; // nooit video onder 720p aanbieden

function mapFormat(f, duration) {
  const hasVideo = f.vcodec !== 'none' && !!(f.vcodec || f.height);
  const hasAudio = f.acodec !== 'none'; // alleen een expliciete "none" betekent zeker geen geluid; onbekend (leeg) telt als geluid
  const br = num(f.tbr) || num(f.abr) || 0;
  let size = num(f.filesize) || num(f.filesize_approx);
  let est = !!(size && !num(f.filesize));
  if (!size && br && duration) { size = br * 125 * duration; est = true; } // kbit/s -> bytes/s
  return {
    id: String(f.format_id), ext: f.ext || '', h: num(f.height), w: num(f.width), fps: num(f.fps),
    vc: hasVideo ? String(f.vcodec || '').split('.')[0] : '', ac: hasAudio ? String(f.acodec || '').split('.')[0] : '',
    size, est, total: size, br,
    v: hasVideo, a: hasAudio, drm: f.has_drm === true, note: f.format_note || '', proto: f.protocol || '',
  };
}

ipcMain.handle('init', async () => {
  try { await ensureTools(); } catch (e) { return { error: e.message }; }
  const s = readSettings();
  return {
    version: APP_VERSION, pending: pendingVersion,
    dir: s.dir && isDir(s.dir) ? s.dir : app.getPath('downloads'),
    container: s.container === 'mkv' ? 'mkv' : 'mp4',
    cookies: COOKIE_BROWSERS.has(s.cookies) ? s.cookies : '',
  };
});

// Is dit een live stream? yt-dlp weet het meestal; bij losse m3u8/mpd-links kijken we zelf in het manifest.
async function probeLive(url, referer) {
  const headers = referer ? { Referer: referer } : {};
  try {
    let t = await fetchText(url, headers, 262144);
    if (/<MPD/i.test(t)) return /type\s*=\s*"dynamic"/i.test(t);
    if (/#EXT-X-STREAM-INF/.test(t)) { // hoofdlijst: kijk in de eerste kwaliteit
      const m = t.split(/\r?\n/).find((l) => l && !l.startsWith('#'));
      if (m) t = await fetchText(new URL(m, url).href, headers, 262144);
    }
    return !/#EXT-X-ENDLIST/.test(t) && /#EXTINF/.test(t);
  } catch { return false; }
}

ipcMain.handle('analyze', async (_e, o) => {
  try {
    const url = cleanUrl(o && o.url);
    const referer = o && o.referer ? cleanUrl(o.referer) : '';
    const args = [...baseArgs(o && o.cookies, referer), '-J', '--flat-playlist', o && o.playlist ? '--yes-playlist' : '--no-playlist', '--', url];
    const info = JSON.parse(await capture(args));
    if (info._type === 'playlist' || Array.isArray(info.entries)) {
      const entries = (info.entries || []).filter(Boolean).map((en) => ({
        title: en.title || en.id || 'Naamloos',
        url: en.webpage_url || (/^https?:\/\//i.test(en.url || '') ? en.url : null) || (en.id && info.webpage_url ? null : null),
        duration: num(en.duration),
      })).filter((en) => en.url);
      if (!entries.length) throw new Error('Geen video\'s gevonden in deze lijst');
      return { type: 'playlist', title: info.title || 'Afspeellijst', entries };
    }
    const duration = num(info.duration);
    let live = info.is_live === true || info.live_status === 'is_live';
    if (!live && /\.(m3u8|mpd)(\?|#|$)/i.test(url)) live = await probeLive(url, referer);
    const all = (info.formats || [])
      .filter((f) => f && f.format_id && !(f.vcodec === 'none' && f.acodec === 'none') && f.ext !== 'mhtml')
      .map((f) => mapFormat(f, duration))
      .sort((a, b) => (b.v - a.v) || ((b.h || 0) - (a.h || 0)) || ((b.fps || 0) - (a.fps || 0)) || (b.br - a.br));
    if (!all.length) throw new Error('Geen downloadbare formaten gevonden');
    // video-only formaten krijgen het beste geluid erbij: tel die grootte mee in het totaal
    const bestAudio = all.filter((f) => !f.v && f.a && !f.drm).sort((a, b) => b.br - a.br)[0];
    for (const f of all) {
      if (f.v && !f.a && bestAudio) {
        f.total = f.size != null && bestAudio.size != null ? f.size + bestAudio.size : null;
        f.est = f.est || bestAudio.est;
      }
    }
    // niets onder 720p
    // alleen video aanbieden (geen audio-only opties)
    // alleen kwaliteiten die geluid hebben (zelf of via het beste geluid dat erbij komt), één regel per kwaliteit
    const vids = all.filter((f) => f.v);
    let withSound = vids.filter((f) => f.a || bestAudio);
    const soundUnsure = !withSound.length && vids.length > 0; // geluid niet te bevestigen: toon de video's toch
    if (soundUnsure) withSound = vids;
    if (!withSound.length) throw new Error('Geen video gevonden');
    const uniq = (list) => {
      if (live) return list; // live: alle aangeboden varianten
      const best = new Map();
      for (const f of list) {
        const k = f.h ? f.h + '@' + (f.fps > 30 ? 60 : 30) : 'id' + f.id; // zonder bekende hoogte: niet samenvoegen
        const sc = (x) => (x.drm ? -1e9 : 0) + x.br;
        if (!best.has(k) || sc(f) > sc(best.get(k))) best.set(k, f);
      }
      return [...best.values()].sort((a, b) => ((b.h || 0) - (a.h || 0)) || ((b.fps || 0) - (a.fps || 0)));
    };
    const kept = withSound.filter((f) => !f.h || f.h >= MIN_HEIGHT);
    const lowOnly = !kept.length;
    return {
      type: 'video', title: info.title || 'Naamloos', uploader: info.uploader || info.channel || '',
      live, duration, thumbnail: /^https:\/\//.test(info.thumbnail || '') ? info.thumbnail : '',
      url: info.webpage_url || url, referer, lowOnly, soundUnsure, formats: uniq(lowOnly ? withSound : kept),
    };
  } catch (e) {
    return { error: e.message };
  }
});

function buildSpec(it) {
  if (it.kind === 'format') {
    if (!/^[A-Za-z0-9._\-+=]+$/.test(String(it.id))) throw new Error('Ongeldig formaat');
    return { f: it.videoOnly ? `${it.id}+ba/${it.id}` : String(it.id), audio: !!it.audioOnly };
  }
  const p = it.preset;
  if (p === 'audio') return { f: 'ba/b', audio: true };
  if (p === 'best') return { f: 'bv*+ba/b', audio: false };
  const h = parseInt(p, 10);
  if (!(h >= 100 && h <= 8640)) throw new Error('Ongeldige kwaliteit');
  return { f: `bv*[height<=${h}]+ba/b[height<=${h}]`, audio: false };
}

const PROG_TPL = 'download:PROG|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s|%(progress.fragment_index)s|%(progress.fragment_count)s|%(progress.status)s';
const n = (s) => { const v = parseFloat(s); return isFinite(v) ? v : null; };

function downloadOne(it, opt, onProgress, job) {
  return new Promise((resolve) => {
    let spec, url;
    try { spec = buildSpec(it); url = cleanUrl(it.url); } catch (e) { return resolve({ error: e.message }); }
    const live = it.live === true;
    const liveId = Date.now();
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), TMP_PREFIX));
    const args = [
      ...baseArgs(opt.cookies, it.referer), '--no-playlist', '--newline', '--progress', '--progress-template', PROG_TPL,
      '--print', 'after_move:DONE|%(filepath)s', '--ffmpeg-location', FFMPEG,
      '--paths', 'home:' + opt.dir, ...(live ? [] : ['--paths', 'temp:' + tmp]), // live: direct in de doelmap, zodat een gestopte opname bewaard blijft
      '-o', live ? `%(title).120B [live-${liveId}].%(ext)s` : '%(title).150B [%(resolution)s].%(ext)s', '--windows-filenames',
      '--retries', '10', '--fragment-retries', '10', '--concurrent-fragments', live ? '4' : '8',
      ...(live ? [] : ['--http-chunk-size', '10M']), // blokken omzeilen afremmen van één lange verbinding
      '-f', spec.f,
    ];
    if (spec.audio && opt.audioMp3) args.push('-x', '--audio-format', 'mp3');
    if (!spec.audio) args.push('--merge-output-format', opt.container === 'mkv' ? 'mkv' : 'mp4/mkv');
    if (live) args.push('--no-part', '--hls-use-mpegts', '--no-live-from-start');
    args.push('--', url);

    const p = spawn(YTDLP, args, { windowsHide: true, env: ENV });
    job.procs.add(p);
    let file = '', err = '', buf = '';
    p.stdout.setEncoding('utf8'); p.stderr.setEncoding('utf8');
    p.stdout.on('data', (d) => {
      buf += d;
      const lines = buf.split(/\r?\n/);
      buf = lines.pop();
      for (const l of lines) {
        if (l.startsWith('PROG|')) {
          const x = l.split('|');
          const dl = n(x[1]), tot = n(x[2]) || n(x[3]);
          let pct = dl != null && tot ? dl / tot : null;
          if (pct == null && n(x[6]) && n(x[7])) pct = n(x[6]) / n(x[7]);
          onProgress({ pct, speed: n(x[4]), eta: n(x[5]), dl, tot, finishing: x[8] === 'finished' });
        } else if (l.startsWith('DONE|')) file = l.slice(5);
      }
    });
    p.stderr.on('data', (d) => { err += d; });
    p.on('error', (e) => { job.procs.delete(p); rmrf(tmp); resolve({ error: e.message }); });
    p.on('close', (code) => {
      job.procs.delete(p);
      rmrf(tmp);
      if (live) { finishLive(opt.dir, liveId, opt.container, err).then(resolve); return; } // stoppen = opname bewaren
      if (job.cancelled) return resolve({ cancelled: true });
      if (code !== 0) return resolve({ error: lastError(err) });
      let size = null;
      try { size = fs.statSync(file).size; } catch { /* negeren */ }
      resolve({ file, size });
    });
  });
}

const pad2 = (n) => String(n).padStart(2, '0');
function runFfmpeg(args) {
  return new Promise((resolve) => {
    let p;
    try { p = spawn(FFMPEG, args, { windowsHide: true }); } catch { return resolve(-1); }
    p.stdout.resume(); p.stderr.resume();
    p.on('error', () => resolve(-1));
    p.on('close', (c) => resolve(c));
  });
}

// Na een live-opname (gestopt of vanzelf afgelopen): losse delen samenvoegen tot één mp4/mkv, rest opruimen.
async function finishLive(dir, id, container, errText) {
  const mark = `[live-${id}]`;
  let names = [];
  try { names = fs.readdirSync(dir).filter((n) => n.includes(mark)); } catch { /* negeren */ }
  const junk = (n) => /\.(ytdl|part|temp|json|jpg|jpeg|png|webp|vtt|srt|ass|description)$/i.test(n);
  const sizeOf = (p) => { try { return fs.statSync(p).size; } catch { return 0; } };
  const media = names.filter((n) => !junk(n)).map((n) => path.join(dir, n)).filter((p) => sizeOf(p) > 0);
  const cleanup = (keep) => { for (const n of names) { const p = path.join(dir, n); if (p !== keep) rmrf(p); } };
  if (!media.length) { cleanup(null); return { error: errText ? lastError(errText) : 'Er is niets opgenomen' }; }
  const first = path.basename(media[0]);
  const prefix = first.slice(0, first.indexOf(mark)).trim() || 'Live';
  const d = new Date(id);
  const base = `${prefix} - live ${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}-${pad2(d.getMinutes())}`;
  const inputs = media.flatMap((p) => ['-i', p]);
  const maps = media.length > 1 ? media.flatMap((_, i) => ['-map', String(i)]) : [];
  for (const ext of container === 'mkv' ? ['mkv'] : ['mp4', 'mkv']) {
    const out = path.join(dir, `${base}.${ext}`);
    rmrf(out);
    const code = await runFfmpeg(['-y', '-hide_banner', '-loglevel', 'error', ...inputs, ...maps, '-c', 'copy', out]);
    if (code === 0 && sizeOf(out) > 0) { cleanup(out); return { file: out, size: sizeOf(out) }; }
    rmrf(out);
  }
  cleanup(media[0]); // omzetten lukt niet: bewaar de ruwe opname, er gaat niets verloren
  return { file: media[0], size: sizeOf(media[0]) };
}

// Meerdere downloads tegelijk: elke klik op Downloaden is een eigen taak (jobId van het scherm) met eigen voortgang en stopknop.
ipcMain.handle('download', async (_e, job) => {
  const jobId = String((job && job.jobId) || '');
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(jobId) || jobs.has(jobId)) return { error: 'Ongeldige download' };
  const dir = String((job && job.dir) || '');
  if (!path.isAbsolute(dir) || !isDir(dir)) return { error: 'Ongeldige doelmap' };
  const opt = {
    dir, cookies: COOKIE_BROWSERS.has(job.cookies) ? job.cookies : '',
    container: job.container === 'mkv' ? 'mkv' : 'mp4', audioMp3: !!job.audioMp3,
  };
  saveSettings({ dir: opt.dir, container: opt.container, cookies: opt.cookies });
  const items = Array.isArray(job.items) ? job.items.slice(0, 500) : [];
  const J = { procs: new Set(), cancelled: false };
  jobs.set(jobId, J);
  let ok = 0, fail = 0;
  try {
    for (let i = 0; i < items.length; i++) {
      if (J.cancelled) { send({ t: 'item', job: jobId, i, state: 'cancelled' }); continue; }
      send({ t: 'item', job: jobId, i, state: 'start' });
      const r = await downloadOne(items[i], opt, (p) => send({ t: 'item', job: jobId, i, state: 'progress', ...p }), J);
      if (r.cancelled) send({ t: 'item', job: jobId, i, state: 'cancelled' });
      else if (r.error) { fail++; send({ t: 'item', job: jobId, i, state: 'error', text: r.error }); }
      else { ok++; send({ t: 'item', job: jobId, i, state: 'done', file: r.file, size: r.size }); }
    }
  } finally {
    jobs.delete(jobId); // alleen de eigen tijdelijke map is al opgeruimd; die van andere downloads blijft ongemoeid
  }
  send({ t: 'all', job: jobId, ok, fail, cancelled: J.cancelled });
  return { ok, fail };
});

ipcMain.handle('cancel', (_e, id) => { const J = jobs.get(String(id)); if (J) { J.cancelled = true; killJob(J); } });
ipcMain.handle('stopLive', (_e, id) => { const J = jobs.get(String(id)); if (J) killJob(J); }); // live-opname stoppen en bewaren
ipcMain.handle('pickDir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('openDir', (_e, d) => { if (typeof d === 'string' && isDir(d)) shell.openPath(d); });
ipcMain.handle('showFile', (_e, f) => { if (typeof f === 'string' && fs.existsSync(f)) shell.showItemInFolder(f); });

// ---------- updates van de app-code (zonder nieuwe build) ----------
// boot.js laadt de nieuwste code. Hier wordt een nieuwere versie van GitHub opgehaald, gecontroleerd
// (sha256) en klaargezet in app-next; bij de volgende start activeert boot.js die.
const UPDATE_BASE = 'https://raw.githubusercontent.com/IPzTV/ipztv-updates/main/videodownloader';
const NEXT_DIR = path.join(app.getPath('userData'), 'app-next');
const UPDATE_FILES = new Set(['main.js', 'preload.js', 'index.html', 'renderer.js', 'version.json', '.complete']);
const SHELL = parseInt(process.env.VD_SHELL || '1', 10);
let APP_VERSION = '0.0.0';
try { APP_VERSION = JSON.parse(fs.readFileSync(path.join(__dirname, 'version.json'), 'utf8')).version; } catch { /* negeren */ }
let pendingVersion = null;
let updating = false;

const cmpVer = (a, b) => {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); }
  return 0;
};

function fetchText(url, headers, max) {
  const limit = max || 65536;
  return new Promise((resolve, reject) => {
    const get = (u, hops) => {
      if (hops > 5) return reject(new Error('Te veel doorverwijzingen'));
      (u.startsWith('http:') ? http : https).get(u, { headers: Object.assign({ 'User-Agent': 'VideoDownloader', 'Cache-Control': 'no-cache' }, headers || {}) }, (res) => {
        if ([301, 302, 307, 308].includes(res.statusCode) && res.headers.location) { res.resume(); return get(new URL(res.headers.location, u).toString(), hops + 1); }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
        let b = '';
        res.setEncoding('utf8');
        res.on('data', (d) => { b += d; if (b.length > limit) res.destroy(new Error('Antwoord te groot')); });
        res.on('end', () => resolve(b));
        res.on('error', reject);
      }).on('error', reject);
    };
    get(url, 0);
  });
}

async function checkUpdate() {
  if (updating) return { state: 'busy' };
  updating = true;
  let tmp = null;
  try {
    const v = JSON.parse(await fetchText(UPDATE_BASE + '/version.json?t=' + Date.now()));
    if (!/^\d+\.\d+\.\d+$/.test(String(v.version)) || !/^[a-f0-9]{64}$/.test(String(v.sha256))) throw new Error('Ongeldige update-informatie');
    if (cmpVer(v.version, APP_VERSION) <= 0) return { state: 'none', version: APP_VERSION };
    if (pendingVersion && cmpVer(v.version, pendingVersion) <= 0) return { state: 'ready', version: pendingVersion };
    if ((parseInt(v.shell, 10) || 1) > SHELL) return { state: 'needs-full', version: v.version };

    tmp = fs.mkdtempSync(path.join(os.tmpdir(), TMP_PREFIX + 'upd-'));
    const zip = path.join(tmp, 'u.zip');
    await download(UPDATE_BASE + '/update.zip?t=' + Date.now(), zip);
    const hash = crypto.createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
    if (hash !== v.sha256) throw new Error('Update is beschadigd (controlesom klopt niet)');

    rmrf(NEXT_DIR);
    fs.mkdirSync(NEXT_DIR, { recursive: true });
    if ((await runSimple('tar', ['-xf', zip, '-C', NEXT_DIR], 60000)) !== 0) throw new Error('Uitpakken van de update is mislukt');
    const names = fs.readdirSync(NEXT_DIR);
    if (names.some((n) => !UPDATE_FILES.has(n)) || !['main.js', 'preload.js', 'index.html', 'renderer.js', 'version.json'].every((n) => names.includes(n))) throw new Error('Update bevat onverwachte bestanden');
    if (JSON.parse(fs.readFileSync(path.join(NEXT_DIR, 'version.json'), 'utf8')).version !== v.version) throw new Error('Versienummer in update klopt niet');
    fs.writeFileSync(path.join(NEXT_DIR, '.complete'), '1');
    pendingVersion = v.version;
    const r = { state: 'ready', version: v.version, notes: String(v.notes || '').slice(0, 200) };
    send({ t: 'update', ...r });
    return r;
  } catch (e) {
    rmrf(NEXT_DIR);
    return { state: 'error', error: e.message };
  } finally {
    if (tmp) rmrf(tmp);
    updating = false;
  }
}

ipcMain.handle('checkUpdate', () => checkUpdate());
ipcMain.handle('restart', () => { if (jobs.size) return false; app.relaunch(); app.exit(0); return true; });

// ---------- brug naar de browser-extensie ----------
// De extensie stuurt de actieve pagina (en gevonden streams) naar 127.0.0.1. Alleen verzoeken
// met een extensie-Origin en het juiste Host-adres worden geaccepteerd (webpagina's kunnen dat niet nabootsen).
const BRIDGE_PORT = 47653;
let browserState = null;
let lastPing = 0;

const okHttpUrl = (u) => {
  try {
    const x = new URL(String(u));
    if (x.protocol !== 'http:' && x.protocol !== 'https:') return null;
    if (x.hostname === '127.0.0.1' || x.hostname === 'localhost') return null;
    return x.href.length <= 4096 ? x.href : null;
  } catch { return null; }
};

function handleBrowser(m) {
  lastPing = Date.now();
  const url = okHttpUrl(m && m.url);
  const media = (Array.isArray(m && m.media) ? m.media : []).slice(0, 10).map((x) => ({
    url: okHttpUrl(x && x.url), type: String((x && x.type) || '').slice(0, 60), size: num(x && x.size),
  })).filter((x) => x.url);
  browserState = { url, title: String((m && m.title) || '').slice(0, 200), media };
  send({ t: 'browser', ...browserState });
}

function startBridge() {
  const srv = http.createServer((req, res) => {
    const reply = (code) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end('{}'); };
    const origin = req.headers.origin || '';
    if (req.headers.host !== '127.0.0.1:' + BRIDGE_PORT || !/^(chrome|moz)-extension:\/\//.test(origin) || req.method !== 'POST' || req.url !== '/tab') return reply(403);
    let b = '', size = 0;
    req.on('data', (d) => { size += d.length; if (size > 65536) { req.destroy(); return; } b += d; });
    req.on('end', () => { try { handleBrowser(JSON.parse(b)); reply(200); } catch { reply(400); } });
  });
  srv.on('error', () => { /* poort bezet: extensie-koppeling uit */ });
  srv.listen(BRIDGE_PORT, '127.0.0.1');
}

ipcMain.handle('browser', () => ({ state: browserState, lastPing }));

function createWindow() {
  win = new BrowserWindow({
    width: 980, height: 760, minWidth: 760, minHeight: 560, backgroundColor: '#111214',
    title: 'Video Downloader', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.setMenuBarVisibility(false);
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => {
  purgeStaleTemp(); startBridge(); createWindow();
  setTimeout(checkUpdate, 5000);
  setInterval(checkUpdate, 6 * 3600 * 1000);
});
app.on('before-quit', () => { for (const J of jobs.values()) { J.cancelled = true; killJob(J); } });
app.on('window-all-closed', () => { purgeStaleTemp(); app.quit(); });
