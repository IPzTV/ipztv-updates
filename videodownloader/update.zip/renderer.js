'use strict';
const $ = (s) => document.querySelector(s);
const el = (tag, props, ...kids) => {
  const e = document.createElement(tag);
  if (props) Object.assign(e, props);
  for (const k of kids.flat()) if (k != null) e.append(k);
  return e;
};

let info = null;
let dir = '';
let sel = new Set();      // gekozen formaat-id's (enkele video)
let plChecks = [];        // checkboxes (afspeellijst)
let plQuality = null;
const dls = new Map();    // alle downloads: sleutel "job:nummer"

const fmtSize = (b) => (b ? (b >= 1e9 ? (b / 1e9).toFixed(2) + ' GB' : (b / 1e6).toFixed(b >= 1e8 ? 0 : 1) + ' MB') : '—');
const fmtDur = (s) => {
  if (!s) return '';
  s = Math.round(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
};
const fmtSpeed = (b) => (b ? (b / 1e6).toFixed(1) + ' MB/s' : '');
const sizeText = (f) => (info && info.live ? 'live' : f.total ? (f.est ? '~' : '') + fmtSize(f.total) : 'onbekend');
let curReferer = '';
// ---------- downloads: meerdere tegelijk, elk met een eigen balk en stopknop ----------
let liveTimer = null;
const activeCount = () => [...dls.values()].filter((d) => d.state === 'wait' || d.state === 'run').length;
const isFinished = (d) => d.state === 'done' || d.state === 'error' || d.state === 'cancelled';
function updateRestart() { const rs = $('#restart'); if (rs) rs.disabled = activeCount() > 0; }

function setBar(d, frac, text, cls) {
  d.bar.classList.remove('idle', 'done', 'fail');
  if (cls) d.bar.classList.add(cls);
  d.bar.firstChild.style.width = Math.round(Math.max(0, Math.min(1, frac)) * 100) + '%';
  d.bar.lastChild.textContent = text;
  d.frac = frac;
  updateTotal();
}

function updateTotal() {
  const list = [...dls.values()].filter((d) => !d.live);
  $('#total').classList.toggle('hidden', list.length < 2);
  if (list.length < 2) return;
  const done = list.filter((d) => d.state === 'done').length;
  const frac = list.reduce((a, d) => a + (isFinished(d) ? 1 : Math.min(1, d.frac)), 0) / list.length;
  $('#totalText').textContent = `Totaal: ${done} van ${list.length} klaar`;
  const bar = $('#totalBar');
  bar.firstChild.style.width = Math.round(frac * 100) + '%';
  bar.lastChild.textContent = Math.round(frac * 100) + '%';
  bar.classList.toggle('done', list.every(isFinished));
}

function makeRow(it, jobId) {
  const d = { live: !!it.live, state: 'wait', frac: 0, phase: 0, last: 0, phases: it.videoOnly ? 2 : 1, bytes: 0, start: Date.now() }; // video + geluid = 2 stappen
  d.status = el('span', { className: 'dim', textContent: 'Wachten…' });
  d.bar = el('div', { className: 'pbar' }, el('i'), el('b', { textContent: '0%' }));
  d.stop = el('button', {
    className: 'ghost small', textContent: d.live ? 'Stop opname' : 'Stop', title: d.live ? 'Opname stoppen en opslaan' : 'Download stoppen',
    onclick: () => { d.stop.disabled = true; if (d.live) window.api.stopLive(jobId); else window.api.cancel(jobId); },
  });
  d.row = el('div', { className: 'qi', title: it.label }, el('b', { textContent: it.label }), d.bar, d.status, d.stop);
  return d;
}

// live-opname: verstreken tijd en grootte bijhouden
function tickRow(d) {
  const t = fmtDur(Math.floor((Date.now() - d.start) / 1000)) || '0:00';
  d.status.textContent = `● Opnemen ${t}${d.bytes ? ' · ' + fmtSize(d.bytes) : ''}`;
  setBar(d, 0, '● ' + t, 'idle');
}
function ensureLiveTimer() {
  if (liveTimer) return;
  liveTimer = setInterval(() => {
    const live = [...dls.values()].filter((d) => d.live && (d.state === 'run' || d.state === 'wait'));
    live.filter((d) => d.state === 'run').forEach(tickRow);
    if (!live.length) { clearInterval(liveTimer); liveTimer = null; }
  }, 1000);
}

function removeDl(d) {
  d.row.remove();
  dls.delete(d.key);
  updateTotal();
  if (!dls.size) $('#qlist').replaceChildren(el('div', { className: 'dim', id: 'qempty', textContent: 'Geen download bezig' }));
}

function endRow(d, state, text, cls) {
  d.state = state;
  d.status.textContent = text;
  d.status.className = cls === 'done' ? 'st-done' : cls === 'fail' ? 'st-error' : 'dim';
  d.stop.disabled = false; d.stop.textContent = 'Wis'; d.stop.title = 'Uit de lijst halen'; // klaar: de stopknop wordt een wisknop
  d.stop.onclick = () => removeDl(d);
  setBar(d, state === 'done' ? 1 : d.frac, state === 'done' ? '100%' : state === 'error' ? 'Mislukt' : 'Gestopt', cls);
  updateRestart();
}

function showUpdate(m) {
  const b = $('#upd');
  b.replaceChildren(el('div', { style: 'display:flex;gap:10px;align-items:center;justify-content:space-between' },
    el('span', { textContent: `Update ${m.version} is klaar.${m.notes ? ' ' + m.notes : ''}` }),
    el('button', { id: 'restart', textContent: 'Nu herstarten', disabled: activeCount() > 0, onclick: () => window.api.restart() })));
  b.classList.remove('hidden');
}
const qLabel = (f) => (f.v ? `${f.h ? f.h + 'p' : (f.w ? f.w + 'px' : 'video')}${f.fps > 30 ? Math.round(f.fps) : ''}` : `${Math.round(f.br) || '?'} kbps`);

function setError(m) { $('#err').textContent = m || ''; }

function updateDlButton() {
  let n = 0;
  if (info) n = info.type === 'video' ? sel.size : plChecks.filter((c) => c.checked).length;
  $('#dl').disabled = n === 0;
  $('#dl').textContent = info && info.live ? 'Opname starten' : n > 1 ? `Downloaden (${n})` : 'Downloaden';
  let sum = '';
  if (info && info.type === 'video' && !info.live && sel.size) {
    const fs_ = info.formats.filter((f) => sel.has(f.id));
    const known = fs_.filter((f) => f.total);
    const tot = known.reduce((a, f) => a + f.total, 0);
    if (known.length) sum = 'Totaal: ' + (known.some((f) => f.est) ? '~' : '') + fmtSize(tot) + (known.length < fs_.length ? ' + onbekend' : '');
  }
  $('#sum').textContent = sum;
}

// ---------- weergave van analyse ----------
function renderVideo() {
  const box = $('#result');
  box.replaceChildren();
  const head = el('div', { className: 'head' });
  if (info.thumbnail) head.append(el('img', { src: info.thumbnail, alt: '' }));
  head.append(el('div', null,
    el('div', { className: 't' }, info.live ? el('span', { className: 'livebadge', textContent: '● LIVE' }) : null, info.title),
    el('div', { className: 'dim', textContent: [info.uploader, fmtDur(info.duration)].filter(Boolean).join(' · ') })));
  const card = el('div', { className: 'card' }, head);

  const tools = el('div', { className: 'tools' },
    el('button', { className: 'ghost small', textContent: 'Beste', onclick: () => pick('best') }),
    info.live ? null : el('button', { className: 'ghost small', textContent: 'Alle kwaliteiten', title: 'De beste variant van elke resolutie', onclick: () => pick('all') }),
    el('button', { className: 'ghost small', textContent: 'Niets', onclick: () => pick('none') }));
  card.append(el('div', { style: 'height:10px' }), tools);
  if (info.live) card.append(el('div', { className: 'livenote', textContent: 'Live stream: je neemt op vanaf nu tot je op Stoppen klikt. Kies één kwaliteit.' }));
  if (info.soundUnsure) card.append(el('div', { className: 'dim', style: 'font-size:12px', textContent: 'Let op: bij deze video kon niet worden bevestigd dat er geluid in zit.' }));
  if (info.lowOnly) card.append(el('div', { className: 'st-error', textContent: 'Deze video heeft geen 720p of hoger; alleen lagere kwaliteiten beschikbaar.' }));
  else card.append(el('div', { className: 'dim', style: 'font-size:12px', textContent: 'Alleen kwaliteiten met geluid, vanaf 720p. Grootte met ~ is een schatting; het geluid is meegeteld.' }));

  const vids = info.formats.filter((f) => f.v);
  const mk = (list, video) => {
    const t = el('table', null, el('tr', null, ...['', 'Kwaliteit', 'Type', 'Codec', 'Geluid', 'Grootte'].map((h) => el('th', { textContent: h }))));
    for (const f of list) {
      const cb = el('input', { type: 'checkbox', disabled: f.drm });
      cb.dataset.id = f.id;
      cb.onchange = () => { if (info.live && cb.checked) sel = new Set(); cb.checked ? sel.add(f.id) : sel.delete(f.id); if (info.live) { syncRows(); return; } tr.className = (cb.checked ? 'sel ' : '') + (f.drm ? 'drm' : ''); updateDlButton(); };
      const sound = f.drm ? 'DRM – niet mogelijk' : 'ja';
      const tr = el('tr', { className: f.drm ? 'drm' : '' },
        el('td', null, cb), el('td', { textContent: qLabel(f) + (f.note && video && !f.h ? ' ' + f.note : '') }),
        el('td', { textContent: f.ext }), el('td', { textContent: video ? f.vc : f.ac }),
        el('td', { textContent: sound }), el('td', { textContent: sizeText(f), title: video && !f.a ? 'Inclusief het beste geluid' : '' }));
      tr.onclick = (e) => { if (e.target !== cb && !cb.disabled) { cb.checked = !cb.checked; cb.onchange(); } };
      tr.dataset.id = f.id;
      t.append(tr);
    }
    return t;
  };
  if (vids.length) card.append(el('div', { className: 'sect', textContent: 'Video' }), mk(vids, true));
  box.append(card);
  box.classList.remove('hidden');
  pick('best');
}

function syncRows() {
  document.querySelectorAll('#result tr[data-id]').forEach((tr) => {
    const cb = tr.querySelector('input');
    cb.checked = sel.has(cb.dataset.id);
    tr.className = (cb.checked ? 'sel ' : '') + (cb.disabled ? 'drm' : '');
  });
  updateDlButton();
}

function pick(mode) {
  sel = new Set();
  const ok = info.formats.filter((f) => !f.drm);
  const vids = ok.filter((f) => f.v);
  const score = (f) => (f.h || 0) * 1e6 + (f.fps || 0) * 1e3 + f.br;
  if (mode === 'best' && vids.length) {
    const pool = info.live && vids.some((f) => f.a) ? vids.filter((f) => f.a) : vids; // live: liefst met geluid erin
    sel.add(pool.reduce((a, b) => (score(b) > score(a) ? b : a)).id);
  } else if (mode === 'all') {
    const best = new Map();
    for (const f of vids) {
      const k = (f.h || 0) + '@' + (f.fps > 30 ? 60 : 30);
      if (!best.has(k) || score(f) > score(best.get(k))) best.set(k, f);
    }
    best.forEach((f) => sel.add(f.id));
  }
  syncRows();
}

function renderPlaylist() {
  const box = $('#result');
  box.replaceChildren();
  plChecks = [];
  plQuality = el('select', null,
    ...[['best', 'Beste kwaliteit'], ['2160', 'Max 4K (2160p)'], ['1440', 'Max 1440p'], ['1080', 'Max 1080p'], ['720', 'Max 720p']]
      .map(([v, t]) => el('option', { value: v, textContent: t })));
  const all = el('input', { type: 'checkbox', checked: true });
  all.onchange = () => { plChecks.forEach((c) => { c.checked = all.checked; }); updateDlButton(); };
  const card = el('div', { className: 'card' },
    el('div', { className: 't', style: 'font-weight:600', textContent: info.title }),
    el('div', { className: 'dim', textContent: info.entries.length + ' video\'s' }),
    el('div', { className: 'tools', style: 'margin-top:10px' }, el('label', { className: 'chk' }, all, 'Alles'), el('span', { className: 'dim', textContent: 'Kwaliteit:' }), plQuality));
  const t = el('table');
  info.entries.forEach((en) => {
    const cb = el('input', { type: 'checkbox', checked: true });
    cb.onchange = updateDlButton;
    plChecks.push(cb);
    t.append(el('tr', null, el('td', null, cb), el('td', { textContent: en.title }), el('td', { className: 'dim', textContent: fmtDur(en.duration) })));
  });
  card.append(t);
  box.append(card);
  box.classList.remove('hidden');
  updateDlButton();
}

// ---------- acties ----------
let analysisId = 0;

// quiet = automatisch zoeken: fouten niet als rode melding tonen
async function analyze(urlOverride, referer, quiet) {
  if (typeof urlOverride === 'string') $('#url').value = urlOverride;
  const url = $('#url').value.trim();
  if (!url) return { error: 'Geen link' };
  curReferer = typeof referer === 'string' ? referer : '';
  const id = ++analysisId;
  setError('');
  info = null; sel = new Set(); plChecks = [];
  $('#result').classList.add('hidden');
  $('#dl').disabled = true;
  $('#go').disabled = true;
  $('#go').textContent = 'Bezig…';
  const r = await window.api.analyze({ url, cookies: $('#cookies').value, playlist: $('#pl').checked, referer: curReferer });
  if (id !== analysisId) return { stale: true }; // inmiddels een nieuwere zoekopdracht
  $('#go').textContent = 'Analyseren';
  $('#go').disabled = false;
  if (r.error) { if (!quiet) setError(r.error); return r; }
  info = r;
  r.type === 'video' ? renderVideo() : renderPlaylist();
  return r;
}

function buildItems() {
  if (info.type === 'video') {
    return info.formats.filter((f) => sel.has(f.id)).map((f) => ({
      url: info.url, referer: info.referer || '', live: !!info.live, kind: 'format', id: f.id, videoOnly: f.v && !f.a, audioOnly: !f.v && f.a,
      label: `${info.live ? '● LIVE · ' : ''}${info.title} — ${qLabel(f)} ${f.ext}`,
    }));
  }
  return info.entries.filter((_, i) => plChecks[i].checked).map((en) => ({ url: en.url, kind: 'preset', preset: plQuality.value, label: en.title }));
}

async function startDownload() {
  const its = buildItems();
  if (!its.length) return;
  const jobId = 'j' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const list = $('#qlist');
  const empty = $('#qempty');
  if (empty) empty.remove();
  its.forEach((it, i) => { const d = makeRow(it, jobId); d.key = jobId + ':' + i; dls.set(d.key, d); list.append(d.row); });
  $('#queue').scrollTop = $('#queue').scrollHeight;
  updateTotal();
  setError('');
  if (its.some((it) => it.live)) ensureLiveTimer();
  $('#dl').disabled = true; setTimeout(updateDlButton, 1200); // geen dubbele klik
  await window.api.download({ jobId, items: its, dir, cookies: $('#cookies').value, container: $('#container').value });
}

window.api.on((m) => {
  if (m.t === 'setup') {
    $('#setupText').textContent = m.text;
    if (m.pct != null) $('#setupBar').style.width = Math.round(m.pct * 100) + '%';
  } else if (m.t === 'item') {
    const d = dls.get(m.job + ':' + m.i);
    if (!d) return;
    if (m.state === 'start') {
      d.state = 'run'; d.start = Date.now(); d.status.textContent = 'Starten…'; d.bar.classList.add('idle');
      if (d.live) ensureLiveTimer();
    } else if (m.state === 'progress') {
      if (d.live) { if (m.dl) d.bytes = m.dl; tickRow(d); return; }
      if (m.finishing) setBar(d, 0.99, '99%');
      else if (m.pct != null) {
        if (m.pct < d.last - 0.3) d.phase++; // tweede stroom (geluid) begint opnieuw bij 0
        d.last = m.pct;
        const f = Math.max(d.frac, Math.min(0.99, (Math.min(d.phase, d.phases - 1) + m.pct) / d.phases));
        setBar(d, f, Math.round(f * 100) + '%');
      } else d.bar.classList.add('idle');
      const bytes = m.dl ? fmtSize(m.dl) + (m.tot ? ' / ' + fmtSize(m.tot) : '') : '';
      d.status.textContent = m.finishing ? 'Verwerken…' : [m.pct != null ? Math.round(m.pct * 100) + '%' : '', bytes, fmtSpeed(m.speed), m.eta ? fmtDur(m.eta) : ''].filter(Boolean).join(' · ');
    } else if (m.state === 'done') {
      endRow(d, 'done', 'Klaar' + (m.size ? ' · ' + fmtSize(m.size) : ''), 'done');
      if (m.file) { d.status.style.cursor = 'pointer'; d.status.title = 'Tonen in map'; d.status.onclick = () => window.api.showFile(m.file); }
    } else if (m.state === 'error') endRow(d, 'error', m.text || 'Mislukt', 'fail');
    else if (m.state === 'cancelled') endRow(d, 'cancelled', 'Gestopt', '');
  } else if (m.t === 'browser') {
    onBrowser(m);
  } else if (m.t === 'update') {
    showUpdate(m);
  }
});

$('#chk').onclick = async () => {
  const msg = $('#chkmsg');
  msg.textContent = 'Controleren…';
  const r = await window.api.checkUpdate();
  if (r.state === 'none') msg.textContent = 'Je hebt de nieuwste versie';
  else if (r.state === 'ready') { msg.textContent = ''; showUpdate(r); }
  else if (r.state === 'needs-full') msg.textContent = `Versie ${r.version} vraagt een nieuwe volledige build (bouw.bat)`;
  else if (r.state === 'busy') msg.textContent = 'Bezig met controleren…';
  else msg.textContent = 'Controleren mislukt: ' + (r.error || 'onbekend');
  setTimeout(() => { if (msg.textContent !== '') msg.textContent = ''; }, 8000);
};

// ---------- voorstel vanuit de browser ----------
let lastBrowserAt = 0;
let lastSugUrl = '';
const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; } };

function onBrowser(m) {
  lastBrowserAt = Date.now();
  $('#ext').textContent = 'Browser-extensie: verbonden';
  const box = $('#sug');
  if (!m || !m.url) { box.classList.add('hidden'); return; }
  const key = m.url + '|' + m.media.map((x) => x.url).join(',');
  if (key === lastSugUrl) return;
  lastSugUrl = key;
  box.replaceChildren(
    el('span', { textContent: 'Open in je browser: ' }),
    el('b', { style: 'color:var(--txt);font-weight:500', textContent: m.title || hostOf(m.url) }),
    el('span', { id: 'sugnote', style: 'margin-left:8px' }),
    autoOn ? null : el('button', { className: 'ghost small', style: 'margin-left:10px', textContent: 'Video zoeken', onclick: () => { userTyped = false; autoAnalyze(m, true); } }));
  box.classList.remove('hidden');
  lastM = m;
  scheduleAuto(m);
}

// ---------- automatisch video's zoeken op de open pagina ----------
let autoOn = true;
try { autoOn = localStorage.getItem('auto') !== '0'; } catch { /* negeren */ }
let userTyped = false;      // zelf een link ingevoerd: automatisch zoeken laat dat met rust
let lastM = null;
let autoTimer = null;
const tried = new Map();    // pagina-url -> { ok, media }

// bruikbare streams, beste eerst: hoofdlijsten (master/playlist) vooraan, losse stukjes en piepkleine bestanden niet; bij gelijkspel de nieuwste
function usableStreams(media) {
  const score = (u) => (/master|playlist|manifest/i.test(u) ? 2 : 0) - (/chunk|segment|media_|variant|\/\d{3,4}p?[/_.]/i.test(u) ? 2 : 0);
  return media.filter((x) => x.size == null || x.size >= 3e6)
    .map((x, i) => ({ x, s: score(x.url) * 100 + i })).sort((a, b) => b.s - a.s).map((o) => o.x);
}

function setNote(t) { const n = $('#sugnote'); if (n) n.textContent = t; }

function scheduleAuto(m) {
  clearTimeout(autoTimer);
  if (!autoOn || userTyped) return;
  const t = tried.get(m.url);
  if (t && (t.ok || m.media.length <= t.media)) return; // al gelukt, of niets nieuws gevonden
  setNote('· video zoeken…');
  autoTimer = setTimeout(() => autoAnalyze(m), 1200); // even wachten: snel wisselen tussen tabs kost niets
}

async function autoAnalyze(m, force) {
  if (userTyped && !force) return;
  let r = await analyze(m.url, '', true);
  if (r.stale) return;
  if (r.error) { // pagina zelf niet ondersteund: probeer de gevonden streams, de beste eerst
    for (const st of usableStreams(m.media).slice(0, 3)) {
      r = await analyze(st.url, m.url, true);
      if (r.stale) return;
      if (!r.error) break;
    }
  }
  tried.set(m.url, { ok: !r.error, media: m.media.length });
  setNote(r.error ? '· geen video gevonden' : '');
}

$('#auto').checked = autoOn;
$('#auto').onchange = () => {
  autoOn = $('#auto').checked;
  try { localStorage.setItem('auto', autoOn ? '1' : '0'); } catch { /* negeren */ }
  if (autoOn && lastM) { tried.delete(lastM.url); scheduleAuto(lastM); }
};

setInterval(() => {
  if (lastBrowserAt && Date.now() - lastBrowserAt > 100000) $('#ext').textContent = 'Browser-extensie: geen verbinding';
}, 10000);

async function init() {
  const r = await window.api.init();
  if (r.error) {
    $('#setupText').textContent = 'Starten mislukt: ' + r.error + ' — controleer je internetverbinding en start de app opnieuw.';
    return;
  }
  dir = r.dir;
  $('#ver').textContent = 'v' + r.version;
  if (r.pending) showUpdate({ version: r.pending });
  $('#dir').textContent = dir; $('#dir').title = dir;
  $('#container').value = r.container;
  $('#cookies').value = r.cookies;
  $('#setup').classList.add('hidden');
  $('#foot').classList.remove('hidden');
  $('#go').disabled = false;
  const b = await window.api.browser();
  if (b && b.state) onBrowser(b.state);
}

$('#go').onclick = () => analyze();
$('#url').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !$('#go').disabled) analyze(); });
$('#url').addEventListener('input', () => { curReferer = ''; userTyped = $('#url').value.trim() !== ''; });
$('#dl').onclick = startDownload;
$('#pick').onclick = async () => { const d = await window.api.pickDir(); if (d) { dir = d; $('#dir').textContent = d; $('#dir').title = d; } };
$('#open').onclick = () => window.api.openDir(dir);
init();
